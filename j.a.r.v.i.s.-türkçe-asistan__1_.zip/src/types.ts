export type Priority = 'Yüksek' | 'Orta' | 'Düşük';

export interface TaskItem {
  id: string;
  title: string;
  category: string;
  priority: Priority;
  status: 'Bekliyor' | 'Devam Ediyor' | 'Tamamlandı';
  dueDate?: string;
  createdAt: string;
}

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  category: string;
  pinned: boolean;
  updatedAt: string;
}

export interface CalendarAppointment {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  location?: string;
  description?: string;
  reminderMinutes: number;
  notified?: boolean;
}

export interface BehavioralInsight {
  id: string;
  category: 'SAĞLIK' | 'VERİMLİLİK' | 'OYUN' | 'GÜVENLİK';
  title: string;
  message: string;
  priority: 'YÜKSEK' | 'NORMAL';
}

export interface UserHabits {
  activeHours: string[];
  totalVoiceCommands: number;
  favoriteCommands: Record<string, number>;
  gamingSessionsCount: number;
  lastActive: string;
  preferredTone: string;
}

export interface ControlledApp {
  id: string;
  name: string;
  category: 'Oyun' | 'Müzik & Medya' | 'İletişim & Sosyal' | 'Araç & Tarayıcı' | 'Sistem & Geliştirici';
  voiceTriggers: string[]; // e.g. ["spotify aç", "müzik çal", "spotify"]
  closeTriggers?: string[]; // e.g. ["spotify kapat", "müziği durdur"]
  launchType: 'web' | 'protocol' | 'custom';
  launchTarget: string; // url or protocol link like "spotify:", "steam://run/730"
  iconName?: string;
  status: 'Açık' | 'Kapalı';
  isDefault?: boolean;
}

export interface ScreenAnalysisResult {
  verdict: 'DOĞRU' | 'YANLIŞ' | 'DİKKAT' | 'STRATEJİK TAVSİYE' | 'ÇEVİRİ TAMAMLANDI' | 'HIZLI CEVAP';
  tacticalTip: string;
  translatedText?: string;
  sourceLanguage?: string;
  screenElements: string[];
  confidenceScore: number;
  timestamp: string;
  mode?: 'tactical' | 'translate' | 'instant_qa';
  detectedGame?: string;
  gameGenre?: string;
  currentScene?: string;
}

export interface PCMetric {
  cpuUsage: number;
  ramUsage: number;
  gpuTemp: number;
  networkLatency: number;
  activeApps: string[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'jarvis' | 'system';
  text: string;
  timestamp: string;
  tacticalVerdict?: 'DOĞRU' | 'YANLIŞ' | 'DİKKAT' | 'STRATEJİK TAVSİYE';
  actionTaken?: string;
}
