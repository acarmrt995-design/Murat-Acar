import React, { useState, useEffect } from 'react';
import { Calendar as CalendarIcon, Clock, Bell, Plus, Trash2, Shield, AlertCircle, Check } from 'lucide-react';
import { CalendarAppointment } from '../types';
import { JarvisAudioFX, speakTurkish } from '../services/voice';

interface CalendarManagerProps {
  appointments: CalendarAppointment[];
  onAddAppointment: (app: Omit<CalendarAppointment, 'id'>) => void;
  onDeleteAppointment: (id: string) => void;
}

export const CalendarManager: React.FC<CalendarManagerProps> = ({
  appointments,
  onAddAppointment,
  onDeleteAppointment,
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState('14:00');
  const [location, setLocation] = useState('');
  const [reminderMinutes, setReminderMinutes] = useState(15);
  const [activeAlert, setActiveAlert] = useState<string | null>(null);

  // Periodic Reminder Checker
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const currentYear = now.getFullYear();
      const currentMonth = String(now.getMonth() + 1).padStart(2, '0');
      const currentDay = String(now.getDate()).padStart(2, '0');
      const todayStr = `${currentYear}-${currentMonth}-${currentDay}`;

      const currentHours = String(now.getHours()).padStart(2, '0');
      const currentMinutes = String(now.getMinutes()).padStart(2, '0');
      const currentTimeStr = `${currentHours}:${currentMinutes}`;

      appointments.forEach((app) => {
        if (app.date === todayStr && app.time === currentTimeStr && !app.notified) {
          JarvisAudioFX.playTacticalAlert();
          speakTurkish(`Efendim, planlanan randevu vaktiniz geldi: ${app.title}.`);
          setActiveAlert(`HATIRLATICI: ${app.title} - Saat ${app.time}`);
          app.notified = true;
        }
      });
    }, 20000);

    return () => clearInterval(interval);
  }, [appointments]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onAddAppointment({
      title: title.trim(),
      date,
      time,
      location: location.trim() || undefined,
      reminderMinutes,
      notified: false,
    });

    JarvisAudioFX.playAcknowledge();
    speakTurkish(`Randevu planlandı efendim: ${title.trim()} saat ${time}.`);
    setTitle('');
    setLocation('');
    setIsAdding(false);
  };

  return (
    <div id="jarvis-calendar-manager" className="flex flex-col gap-4 p-5 rounded-2xl bg-[#090d16]/90 border border-cyan-500/20 backdrop-blur-xl">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-cyan-500/15 pb-3">
        <div className="flex items-center gap-2">
          <CalendarIcon className="w-5 h-5 text-cyan-400" />
          <div>
            <h2 className="font-orbitron font-bold text-base text-cyan-200 tracking-wide flex items-center gap-2">
              ZAMAN ÇİZELGESİ & RANDEVULAR
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <Shield className="w-2.5 h-2.5" /> ŞİFRELİ
              </span>
            </h2>
            <p className="text-xs text-cyan-400/60">
              Takvim entegrasyonu, zamanlayıcılar ve proaktif sesli hatırlatmalar.
            </p>
          </div>
        </div>

        <button
          id="new-appointment-btn"
          onClick={() => setIsAdding(!isAdding)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs tracking-wider transition-all cursor-pointer shadow-md"
        >
          <Plus className="w-3.5 h-3.5" />
          {isAdding ? 'KAPAT' : 'RANDEVU PLANLA'}
        </button>
      </div>

      {/* Active Alarm Banner */}
      {activeAlert && (
        <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/50 text-amber-200 flex items-center justify-between animate-pulse">
          <div className="flex items-center gap-2 text-xs font-mono">
            <Bell className="w-4 h-4 text-amber-400" />
            <span>{activeAlert}</span>
          </div>
          <button
            onClick={() => setActiveAlert(null)}
            className="text-xs underline text-amber-300 hover:text-white cursor-pointer"
          >
            Tamam
          </button>
        </div>
      )}

      {/* Add Appointment Form */}
      {isAdding && (
        <form onSubmit={handleSubmit} className="p-4 rounded-xl bg-black/60 border border-cyan-500/40 flex flex-col gap-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Randevu Başlığı (Örn: Tony ile Proje Toplantısı)"
              className="col-span-full px-3 py-2 rounded-lg bg-black/70 border border-cyan-500/30 text-xs text-cyan-100 placeholder:text-cyan-700 focus:outline-none focus:border-cyan-400"
            />
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="px-3 py-2 rounded-lg bg-black/70 border border-cyan-500/30 text-xs text-cyan-200 focus:outline-none focus:border-cyan-400"
            />
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="px-3 py-2 rounded-lg bg-black/70 border border-cyan-500/30 text-xs text-cyan-200 focus:outline-none focus:border-cyan-400"
            />
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Konum veya Platform (Opsiyonel)"
              className="px-3 py-2 rounded-lg bg-black/70 border border-cyan-500/30 text-xs text-cyan-100 placeholder:text-cyan-700 focus:outline-none focus:border-cyan-400"
            />
            <select
              value={reminderMinutes}
              onChange={(e) => setReminderMinutes(Number(e.target.value))}
              className="px-3 py-2 rounded-lg bg-black/70 border border-cyan-500/30 text-xs text-cyan-200 focus:outline-none focus:border-cyan-400"
            >
              <option value={5}>5 Dakika Önce Hatırlat</option>
              <option value={15}>15 Dakika Önce Hatırlat</option>
              <option value={30}>30 Dakika Önce Hatırlat</option>
              <option value={60}>1 Saat Önce Hatırlat</option>
            </select>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-3 py-1.5 rounded-lg text-xs text-cyan-400/80 hover:text-cyan-200 cursor-pointer"
            >
              İptal
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs transition-all cursor-pointer"
            >
              KAYDET VE ALARM KUR
            </button>
          </div>
        </form>
      )}

      {/* Appointments List */}
      <div className="flex flex-col gap-2 max-h-80 overflow-y-auto pr-1">
        {appointments.length === 0 ? (
          <div className="py-8 text-center text-cyan-500/40 text-xs">
            Planlanmış randevu bulunmuyor efendim.
          </div>
        ) : (
          appointments.map((item) => (
            <div
              key={item.id}
              className="flex items-center justify-between p-3.5 rounded-xl bg-black/50 border border-cyan-500/20 hover:border-cyan-500/40 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-cyan-950/60 border border-cyan-500/30 text-cyan-400">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-orbitron font-semibold text-xs text-cyan-200">
                    {item.title}
                  </h4>
                  <div className="flex items-center gap-3 text-[11px] text-cyan-400/70 font-mono mt-0.5">
                    <span>{item.date} • Saat {item.time}</span>
                    {item.location && <span className="opacity-80">@{item.location}</span>}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-900/40 text-cyan-300 border border-cyan-500/30 flex items-center gap-1">
                  <Bell className="w-3 h-3 text-amber-400" />
                  {item.reminderMinutes} dk
                </span>
                <button
                  onClick={() => {
                    onDeleteAppointment(item.id);
                    JarvisAudioFX.playAcknowledge();
                  }}
                  className="p-1 rounded-lg text-cyan-500/40 hover:text-red-400 hover:bg-red-950/40 transition-colors cursor-pointer"
                  title="Randevuyu Sil"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
