import React, { useRef, useEffect } from 'react';
import { Bot, User, Volume2, ShieldCheck, Terminal } from 'lucide-react';
import { ChatMessage } from '../types';
import { speakTurkish } from '../services/voice';

interface ConversationFeedProps {
  messages: ChatMessage[];
  onRepeatVoice: (text: string) => void;
  isProcessing: boolean;
}

export const ConversationFeed: React.FC<ConversationFeedProps> = ({
  messages,
  onRepeatVoice,
  isProcessing,
}) => {
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isProcessing]);

  return (
    <div id="jarvis-chat-feed" className="flex flex-col gap-3 p-4 rounded-2xl bg-[#090d16]/80 border border-cyan-500/20 backdrop-blur-xl h-[420px] overflow-y-auto">
      <div className="flex items-center justify-between text-xs font-mono text-cyan-400/70 border-b border-cyan-500/10 pb-2">
        <span className="flex items-center gap-1.5">
          <Terminal className="w-3.5 h-3.5 text-cyan-400" />
          JARVIS DİYALOG & PROTOKOL AKIŞI
        </span>
        <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
          <ShieldCheck className="w-3 h-3" /> ŞİFRELİ OTURUM
        </span>
      </div>

      <div className="flex flex-col gap-3.5 my-auto">
        {messages.map((msg) => {
          const isJarvis = msg.sender === 'jarvis';
          const isSystem = msg.sender === 'system';

          if (isSystem) {
            return (
              <div
                key={msg.id}
                className="text-center font-mono text-[11px] text-cyan-500/60 py-1 border-y border-cyan-500/10"
              >
                {msg.text}
              </div>
            );
          }

          return (
            <div
              key={msg.id}
              className={`flex items-start gap-2.5 ${
                isJarvis ? 'justify-start' : 'justify-end'
              }`}
            >
              {isJarvis && (
                <div className="w-7 h-7 rounded-lg bg-cyan-950/80 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[82%] p-3.5 rounded-2xl text-xs leading-relaxed transition-all ${
                  isJarvis
                    ? 'bg-cyan-950/40 border border-cyan-500/30 text-cyan-100 rounded-tl-sm'
                    : 'bg-cyan-600 text-black font-medium rounded-tr-sm shadow-md shadow-cyan-600/20'
                }`}
              >
                <div className="flex items-center justify-between gap-4 mb-1">
                  <span
                    className={`font-orbitron font-bold text-[10px] tracking-wider ${
                      isJarvis ? 'text-cyan-400' : 'text-cyan-950'
                    }`}
                  >
                    {isJarvis ? 'J.A.R.V.I.S.' : 'EFENDİM'}
                  </span>
                  <span
                    className={`text-[9px] font-mono ${
                      isJarvis ? 'text-cyan-500/70' : 'text-cyan-950/70'
                    }`}
                  >
                    {msg.timestamp}
                  </span>
                </div>

                <p className="whitespace-pre-wrap font-sans text-xs sm:text-[13px]">
                  {msg.text}
                </p>

                {msg.actionTaken && (
                  <div className="mt-2 pt-1.5 border-t border-cyan-400/20 text-[11px] font-mono text-cyan-300 flex items-center gap-1">
                    <span>⚡ Gerçekleşen Eylem:</span>
                    <span className="font-semibold text-emerald-300">{msg.actionTaken}</span>
                  </div>
                )}

                {isJarvis && (
                  <div className="flex justify-end mt-1">
                    <button
                      onClick={() => onRepeatVoice(msg.text)}
                      className="text-cyan-400/60 hover:text-cyan-300 p-1 cursor-pointer transition-colors"
                      title="Seslendir"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {!isJarvis && (
                <div className="w-7 h-7 rounded-lg bg-cyan-600/30 border border-cyan-500/40 flex items-center justify-center text-cyan-200 shrink-0 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {isProcessing && (
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400/80 p-2">
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span>Jarvis analiz ediyor ve düşünüyor...</span>
          </div>
        )}

        <div ref={bottomRef} />
      </div>
    </div>
  );
};
