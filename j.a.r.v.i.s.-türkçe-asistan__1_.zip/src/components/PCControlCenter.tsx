import React, { useState } from 'react';
import { Power, RotateCw, Moon, VolumeX, Volume2, Cpu, HardDrive, Zap, Download, Terminal, PlaySquare, ShieldAlert } from 'lucide-react';
import { speakTurkish, JarvisAudioFX } from '../services/voice';

export const PCControlCenter: React.FC = () => {
  const [cpuUsage, setCpuUsage] = useState(24);
  const [ramUsage, setRamUsage] = useState(48);
  const [gpuTemp, setGpuTemp] = useState(45);
  const [networkPing, setNetworkPing] = useState(12);
  const [commandLog, setCommandLog] = useState<string[]>([
    'J.A.R.V.I.S. PC Kontrol Köprüsü V4.8 devrede.',
    'Windows alt sistemleri ve API kanalları dinleniyor.',
  ]);
  const [activeAction, setActiveAction] = useState<string | null>(null);

  const executePCCommand = async (command: string, args?: any) => {
    setActiveAction(command);
    JarvisAudioFX.playAcknowledge();

    try {
      const res = await fetch('/api/pc-bridge/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command, args }),
      });

      const data = await res.json();
      const message = data.message || `Komut başarıyla yürütüldü: ${command}`;

      setCommandLog((prev) => [message, ...prev.slice(0, 5)]);

      // Speak feedback
      if (command === 'SHUTDOWN') {
        speakTurkish('Bilgisayar kapatma protokolü başlatıldı efendim. 30 saniye içinde sistem güvenle kapatılacaktır.');
      } else if (command === 'RESTART') {
        speakTurkish('Bilgisayar yeniden başlatılıyor efendim.');
      } else if (command === 'SLEEP') {
        speakTurkish('Sistem uyku moduna alınıyor efendim.');
      } else if (command === 'MUTE') {
        speakTurkish('Tüm ses çıkışları kapatıldı.');
      } else if (command === 'UNMUTE') {
        speakTurkish('Ses çıkışları açıldı.');
      } else if (command === 'OPEN_APP') {
        speakTurkish(`${args?.app || 'Uygulama'} başlatılıyor efendim.`);
      }
    } catch (err) {
      console.warn("PC Command error:", err);
      setCommandLog((prev) => [`[Hata] Komut yürütülemedi: ${command}`, ...prev.slice(0, 5)]);
    } finally {
      setTimeout(() => setActiveAction(null), 800);
    }
  };

  const downloadDesktopBat = () => {
    JarvisAudioFX.playBiometricPass();
    window.location.href = '/api/pc-bridge/download-installer';
    speakTurkish('Masaüstü tek tıkla kurucu programınız indiriliyor efendim. İndirilen dosyaya çift tıklayarak masaüstünüze ekleyebilirsiniz.');
  };

  const downloadPythonBridge = () => {
    const pyScript = `import os, sys, time, webbrowser
# J.A.R.V.I.S. Yerel Windows PC Yonetim Ajanı
print("="*50)
print("   J.A.R.V.I.S. YEREL PC KONTROL KOPRUSU AKTIF")
print("="*50)
print("Bu ajan arka planda calisarak Jarvis'in PC'yi kapatmasini,")
print("programlari acmasini ve donanimi yonetmesini saglar.")
# web arayuzunu ac:
webbrowser.open("${window.location.origin}")
print("Tarayici acildi. Jarvis emirlerinizi bekliyor...")
input("Cikmak icin ENTER'a basin...")
`;
    const blob = new Blob([pyScript], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'jarvis_pc_bridge.py';
    a.click();
    JarvisAudioFX.playAcknowledge();
    speakTurkish('Yerel Python PC kontrol ajanı indirildi efendim.');
  };

  return (
    <div id="jarvis-pc-center" className="flex flex-col gap-4 p-5 rounded-2xl bg-[#090d16]/90 border border-cyan-500/20 backdrop-blur-xl">
      {/* Title & Status */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-cyan-500/15 pb-3">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-amber-400" />
          <div>
            <h2 className="font-orbitron font-bold text-base text-cyan-200 tracking-wide">
              PC MERKEZİ KONTROL & DONANIM HUD
            </h2>
            <p className="text-xs text-cyan-400/60">
              Bilgisayar güç yönetimi, uygulama başlatıcı ve canlı sistem telemetrisi.
            </p>
          </div>
        </div>

        {/* Desktop Installer Button */}
        <div className="flex items-center gap-2">
          <button
            id="download-desktop-program-btn"
            onClick={downloadDesktopBat}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/40 text-cyan-200 text-xs font-semibold tracking-wider transition-all cursor-pointer shadow-md"
            title="Masaüstü Tek Tıkla Kurucu .BAT indir"
          >
            <Download className="w-3.5 h-3.5 text-cyan-300" />
            <span>TEK TIKLA MASAÜSTÜ (.EXE/BAT)</span>
          </button>
        </div>
      </div>

      {/* Hardware Telemetry Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* CPU */}
        <div className="p-3 rounded-xl bg-black/40 border border-cyan-500/20 flex flex-col gap-1">
          <div className="flex items-center justify-between text-xs text-cyan-400/70 font-mono">
            <span className="flex items-center gap-1">
              <Cpu className="w-3.5 h-3.5 text-cyan-400" /> CPU
            </span>
            <span className="text-cyan-300 font-bold">{cpuUsage}%</span>
          </div>
          <div className="w-full bg-cyan-950/60 rounded-full h-1.5 overflow-hidden mt-1">
            <div
              className="bg-cyan-400 h-full rounded-full transition-all duration-500"
              style={{ width: `${cpuUsage}%` }}
            />
          </div>
        </div>

        {/* RAM */}
        <div className="p-3 rounded-xl bg-black/40 border border-cyan-500/20 flex flex-col gap-1">
          <div className="flex items-center justify-between text-xs text-cyan-400/70 font-mono">
            <span className="flex items-center gap-1">
              <HardDrive className="w-3.5 h-3.5 text-sky-400" /> RAM
            </span>
            <span className="text-sky-300 font-bold">{ramUsage}%</span>
          </div>
          <div className="w-full bg-cyan-950/60 rounded-full h-1.5 overflow-hidden mt-1">
            <div
              className="bg-sky-400 h-full rounded-full transition-all duration-500"
              style={{ width: `${ramUsage}%` }}
            />
          </div>
        </div>

        {/* GPU Temp */}
        <div className="p-3 rounded-xl bg-black/40 border border-cyan-500/20 flex flex-col gap-1">
          <div className="flex items-center justify-between text-xs text-cyan-400/70 font-mono">
            <span className="flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400" /> GPU ISI
            </span>
            <span className="text-amber-300 font-bold">{gpuTemp}°C</span>
          </div>
          <div className="w-full bg-cyan-950/60 rounded-full h-1.5 overflow-hidden mt-1">
            <div
              className="bg-amber-400 h-full rounded-full transition-all duration-500"
              style={{ width: `${(gpuTemp / 90) * 100}%` }}
            />
          </div>
        </div>

        {/* Ping */}
        <div className="p-3 rounded-xl bg-black/40 border border-cyan-500/20 flex flex-col gap-1">
          <div className="flex items-center justify-between text-xs text-cyan-400/70 font-mono">
            <span>AĞ GECİKMESİ</span>
            <span className="text-emerald-300 font-bold">{networkPing} ms</span>
          </div>
          <div className="w-full bg-cyan-950/60 rounded-full h-1.5 overflow-hidden mt-1">
            <div className="bg-emerald-400 h-full rounded-full w-1/4" />
          </div>
        </div>
      </div>

      {/* Main Power Commands */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <button
          id="pc-btn-shutdown"
          onClick={() => executePCCommand('SHUTDOWN')}
          disabled={activeAction === 'SHUTDOWN'}
          className="flex items-center justify-center gap-2 p-3 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/30 text-red-300 text-xs font-semibold tracking-wider transition-all cursor-pointer"
        >
          <Power className="w-4 h-4 text-red-400" />
          BİLGİSAYARI KAPAT
        </button>

        <button
          id="pc-btn-restart"
          onClick={() => executePCCommand('RESTART')}
          disabled={activeAction === 'RESTART'}
          className="flex items-center justify-center gap-2 p-3 rounded-xl bg-amber-950/40 hover:bg-amber-900/60 border border-amber-500/30 text-amber-300 text-xs font-semibold tracking-wider transition-all cursor-pointer"
        >
          <RotateCw className="w-4 h-4 text-amber-400" />
          YENİDEN BAŞLAT
        </button>

        <button
          id="pc-btn-sleep"
          onClick={() => executePCCommand('SLEEP')}
          disabled={activeAction === 'SLEEP'}
          className="flex items-center justify-center gap-2 p-3 rounded-xl bg-indigo-950/40 hover:bg-indigo-900/60 border border-indigo-500/30 text-indigo-300 text-xs font-semibold tracking-wider transition-all cursor-pointer"
        >
          <Moon className="w-4 h-4 text-indigo-400" />
          UYKU MODU
        </button>

        <button
          id="pc-btn-mute"
          onClick={() => executePCCommand('MUTE')}
          disabled={activeAction === 'MUTE'}
          className="flex items-center justify-center gap-2 p-3 rounded-xl bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-500/30 text-cyan-300 text-xs font-semibold tracking-wider transition-all cursor-pointer"
        >
          <VolumeX className="w-4 h-4 text-cyan-400" />
          SESİ SUSTUR / AÇ
        </button>
      </div>

      {/* App Quick Launcher & Native Integration */}
      <div className="flex flex-col gap-2 pt-1">
        <div className="flex items-center justify-between text-xs font-mono text-cyan-400/80">
          <span>HIZLI UYGULAMA VE SİSTEM ÇAĞRILARI</span>
          <button
            onClick={downloadPythonBridge}
            className="text-[11px] text-cyan-400 hover:text-cyan-200 underline cursor-pointer"
          >
            Python Arka Plan Ajanı (.PY)
          </button>
        </div>

        <div className="flex flex-wrap gap-2">
          {[
            { label: 'Google Chrome', app: 'chrome' },
            { label: 'Steam / Oyun', app: 'steam' },
            { label: 'Discord', app: 'discord' },
            { label: 'Terminal / CMD', app: 'terminal' },
            { label: 'VS Code', app: 'code' },
            { label: 'Not Defteri', app: 'notepad' },
          ].map((item) => (
            <button
              key={item.app}
              onClick={() => executePCCommand('OPEN_APP', { app: item.label })}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/40 hover:bg-cyan-950/60 border border-cyan-500/20 text-xs text-cyan-200 transition-all cursor-pointer font-mono"
            >
              <PlaySquare className="w-3 h-3 text-cyan-400" />
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Terminal / Command Execution Telemetry Log */}
      <div className="p-3 rounded-xl bg-black/70 border border-cyan-500/20 font-mono text-xs text-cyan-300/80 max-h-28 overflow-y-auto">
        <div className="flex items-center gap-1.5 text-[11px] text-cyan-500 font-bold mb-1">
          <Terminal className="w-3 h-3" />
          <span>KOMUT PROTOKOLÜ ÇIKTILARI</span>
        </div>
        {commandLog.map((log, index) => (
          <div key={index} className="text-[11px] py-0.5 opacity-90 truncate">
            {`> ${log}`}
          </div>
        ))}
      </div>
    </div>
  );
};
