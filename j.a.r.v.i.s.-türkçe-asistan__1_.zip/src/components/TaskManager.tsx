import React, { useState } from 'react';
import { CheckCircle2, Circle, Clock, Plus, Trash2, Shield, Calendar, Tag, AlertCircle } from 'lucide-react';
import { TaskItem, Priority } from '../types';
import { JarvisAudioFX, speakTurkish } from '../services/voice';

interface TaskManagerProps {
  tasks: TaskItem[];
  onAddTask: (task: Omit<TaskItem, 'id' | 'createdAt'>) => void;
  onToggleStatus: (id: string) => void;
  onDeleteTask: (id: string) => void;
}

export const TaskManager: React.FC<TaskManagerProps> = ({
  tasks,
  onAddTask,
  onToggleStatus,
  onDeleteTask,
}) => {
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState('Genel');
  const [newPriority, setNewPriority] = useState<Priority>('Orta');
  const [newDueDate, setNewDueDate] = useState('');
  const [filter, setFilter] = useState<'Tümü' | 'Bekliyor' | 'Tamamlandı'>('Tümü');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    onAddTask({
      title: newTitle.trim(),
      category: newCategory,
      priority: newPriority,
      status: 'Bekliyor',
      dueDate: newDueDate || undefined,
    });

    JarvisAudioFX.playAcknowledge();
    speakTurkish(`Görev kaydedildi efendim: ${newTitle.trim()}`);
    setNewTitle('');
    setNewDueDate('');
  };

  const filteredTasks = tasks.filter((t) => {
    if (filter === 'Bekliyor') return t.status !== 'Tamamlandı';
    if (filter === 'Tamamlandı') return t.status === 'Tamamlandı';
    return true;
  });

  return (
    <div id="jarvis-task-manager" className="flex flex-col gap-4 p-5 rounded-2xl bg-[#090d16]/90 border border-cyan-500/20 backdrop-blur-xl">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-cyan-500/15 pb-3">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-cyan-400" />
          <div>
            <h2 className="font-orbitron font-bold text-base text-cyan-200 tracking-wide flex items-center gap-2">
              GÖREV PROTOKOLÜ
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <Shield className="w-2.5 h-2.5" /> E2EE ŞİFRELİ
              </span>
            </h2>
            <p className="text-xs text-cyan-400/60">
              Günlük görev yönetimi, önceliklendirme ve sesli asistan senkronizasyonu.
            </p>
          </div>
        </div>

        {/* Filter Chips */}
        <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-cyan-500/20 text-xs">
          {(['Tümü', 'Bekliyor', 'Tamamlandı'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                filter === f ? 'bg-cyan-500 text-black font-semibold' : 'text-cyan-400/80 hover:text-cyan-200'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Quick Add Form */}
      <form onSubmit={handleCreate} className="flex flex-col sm:flex-row gap-2">
        <input
          type="text"
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          placeholder="Yeni görev yazın veya sesli söyleyin ('Jarvis görev ekle: ...')"
          className="flex-1 px-3.5 py-2.5 rounded-xl bg-black/50 border border-cyan-500/30 text-sm text-cyan-100 placeholder:text-cyan-700 focus:outline-none focus:border-cyan-400"
        />

        <div className="flex items-center gap-2">
          <select
            value={newPriority}
            onChange={(e) => setNewPriority(e.target.value as Priority)}
            className="px-2.5 py-2.5 rounded-xl bg-black/50 border border-cyan-500/30 text-xs text-cyan-200 focus:outline-none focus:border-cyan-400"
          >
            <option value="Yüksek">Öncelik: Yüksek</option>
            <option value="Orta">Öncelik: Orta</option>
            <option value="Düşük">Öncelik: Düşük</option>
          </select>

          <input
            type="date"
            value={newDueDate}
            onChange={(e) => setNewDueDate(e.target.value)}
            className="px-2.5 py-2.5 rounded-xl bg-black/50 border border-cyan-500/30 text-xs text-cyan-200 focus:outline-none focus:border-cyan-400"
          />

          <button
            type="submit"
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs tracking-wider transition-all shadow-md shadow-cyan-500/30 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            EKLE
          </button>
        </div>
      </form>

      {/* Task List */}
      <div className="flex flex-col gap-2 max-h-80 overflow-y-auto pr-1">
        {filteredTasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center text-cyan-500/40">
            <CheckCircle2 className="w-8 h-8 mb-1 opacity-30" />
            <p className="text-xs">Bekleyen görev bulunmuyor efendim.</p>
          </div>
        ) : (
          filteredTasks.map((task) => {
            const isDone = task.status === 'Tamamlandı';
            return (
              <div
                key={task.id}
                className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                  isDone
                    ? 'bg-black/30 border-cyan-900/30 text-cyan-600'
                    : 'bg-black/60 border-cyan-500/25 hover:border-cyan-400/50 text-cyan-100'
                }`}
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <button
                    onClick={() => {
                      onToggleStatus(task.id);
                      JarvisAudioFX.playAcknowledge();
                    }}
                    className="cursor-pointer text-cyan-400 hover:text-cyan-300"
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    ) : (
                      <Circle className="w-5 h-5 opacity-60" />
                    )}
                  </button>

                  <div className="flex flex-col min-w-0">
                    <span
                      className={`text-sm font-medium truncate ${
                        isDone ? 'line-through text-cyan-600' : ''
                      }`}
                    >
                      {task.title}
                    </span>
                    <div className="flex items-center gap-2 text-[11px] text-cyan-400/60 mt-0.5">
                      {task.dueDate && (
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {task.dueDate}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Tag className="w-3 h-3" />
                        {task.category}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded-md border ${
                      task.priority === 'Yüksek'
                        ? 'bg-red-500/20 text-red-400 border-red-500/30'
                        : task.priority === 'Orta'
                        ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                        : 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
                    }`}
                  >
                    {task.priority}
                  </span>

                  <button
                    onClick={() => {
                      onDeleteTask(task.id);
                      JarvisAudioFX.playAcknowledge();
                    }}
                    className="p-1 rounded-lg text-cyan-500/40 hover:text-red-400 hover:bg-red-950/40 transition-colors cursor-pointer"
                    title="Görevi Sil"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
