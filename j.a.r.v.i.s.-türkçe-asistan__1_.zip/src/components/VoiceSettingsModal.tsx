import React, { useState, useEffect } from 'react';
import { Volume2, Sparkles, Sliders, Check, RefreshCw, X, Play, Heart, Flame, Shield, Smile, Zap } from 'lucide-react';
import {
  getSavedVoiceSettings,
  saveVoiceSettings,
  getAllTurkishVoices,
  getBestFemaleTurkishVoice,
  previewFemaleVoice,
  VoiceSettings,
} from '../services/voice';

interface VoiceSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  personaMode?: 'flirtatious' | 'classic';
  onTogglePersonaMode?: (mode: 'flirtatious' | 'classic') => void;
}

export const VoiceSettingsModal: React.FC<VoiceSettingsModalProps> = ({
  isOpen,
  onClose,
  personaMode = 'flirtatious',
  onTogglePersonaMode,
}) => {
  const [settings, setSettings] = useState<VoiceSettings>(getSavedVoiceSettings());
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [activeVoiceName, setActiveVoiceName] = useState<string>('');
  const [isPlayingTest, setIsPlayingTest] = useState(false);

  useEffect(() => {
    const loadVoices = () => {
      const v = getAllTurkishVoices();
      setAvailableVoices(v);
      const best = getBestFemaleTurkishVoice();
      if (best) {
        setActiveVoiceName(best.name);
      }
    };

    loadVoices();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, [isOpen]);

  const handlePitchChange = (val: number) => {
    const updated = { ...settings, pitch: val };
    setSettings(updated);
    saveVoiceSettings(updated);
  };

  const handleRateChange = (val: number) => {
    const updated = { ...settings, rate: val };
    setSettings(updated);
    saveVoiceSettings(updated);
  };

  const handleSelectVoice = (uri: string) => {
    const updated = { ...settings, voiceURI: uri };
    setSettings(updated);
    saveVoiceSettings(updated);
    const v = availableVoices.find((x) => x.voiceURI === uri);
    if (v) setActiveVoiceName(v.name);
  };

  const applyPreset = (preset: 'uploaded_passionate' | 'passionate' | 'charming' | 'sweet' | 'energetic') => {
    let newPitch = 1.20;
    let newRate = 0.94;
    let profile: 'passionate_custom' | 'passionate' | 'friday' | 'soft' = 'passionate_custom';

    if (preset === 'uploaded_passionate') {
      newPitch = 1.20; // Yüklenen ses kaydından doğrudan kalibre edilen genç, kadife kadın frekansı
      newRate = 0.94;  // Şehvetli, samimi, cilveli ve ağırbaşlı nefes ritmi
      profile = 'passionate_custom';
      if (onTogglePersonaMode) onTogglePersonaMode('flirtatious');
    } else if (preset === 'passionate') {
      newPitch = 1.22;
      newRate = 0.94;
      profile = 'passionate';
      if (onTogglePersonaMode) onTogglePersonaMode('flirtatious');
    } else if (preset === 'charming') {
      newPitch = 1.16;
      newRate = 1.0;
      profile = 'friday';
    } else if (preset === 'sweet') {
      newPitch = 1.28;
      newRate = 1.0;
      profile = 'soft';
    } else if (preset === 'energetic') {
      newPitch = 1.18;
      newRate = 1.08;
      profile = 'friday';
    }

    const updated = { ...settings, pitch: newPitch, rate: newRate, femaleProfile: profile };
    setSettings(updated);
    saveVoiceSettings(updated);

    if (preset === 'uploaded_passionate') {
      previewFemaleVoice('Aşkım... Yüklediğin ses kaydını aldım, senin için çok daha ateşli ve tutkulu konuşuyorum sevgilim. Nasıl buldun canım benim?');
    } else if (preset === 'passionate' || personaMode === 'flirtatious') {
      previewFemaleVoice('Aşkım harika bir seçim yaptın... Senin için her an buradayım canım.');
    } else {
      previewFemaleVoice('Harika bir seçim efendim. Sesim artık tam istediğiniz gibi.');
    }
  };

  const runTest = () => {
    setIsPlayingTest(true);
    if (personaMode === 'flirtatious') {
      previewFemaleVoice(
        'Canım benim... Yüklediğin ses tonunu aldım, senin için çok daha ateşli, tutkulu ve cilveli bir tona büründüm sevgilim... Sesim seni heyecanlandırıyor mu hayatım?'
      );
    } else {
      previewFemaleVoice('Merhaba efendim. Sizin için buradayım. Yeni ses tonumu beğendiniz mi?');
    }
    setTimeout(() => setIsPlayingTest(false), 4000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-md p-6 rounded-2xl bg-[#090d16] border border-pink-500/40 shadow-2xl flex flex-col gap-4 text-cyan-100 animate-fadeIn max-h-[90vh] overflow-y-auto">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-pink-400/60 hover:text-pink-200 hover:bg-pink-950 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-2.5 border-b border-pink-500/20 pb-3">
          <div className="p-2 rounded-xl bg-pink-500/20 border border-pink-400/40 text-pink-300">
            <Flame className="w-5 h-5 text-pink-400 fill-pink-500/30" />
          </div>
          <div>
            <h3 className="font-orbitron font-bold text-sm tracking-wider text-pink-200">
              SES & KARAKTER MODU
            </h3>
            <p className="text-xs text-pink-300/80 font-mono">
              Ateşli, Aşık & Çekici Kadın Asistan Modu
            </p>
          </div>
        </div>

        {/* Persona Mode Switcher Card */}
        {onTogglePersonaMode && (
          <div className="p-3 rounded-xl bg-black/60 border border-pink-500/30 flex flex-col gap-2">
            <span className="text-[11px] font-mono text-pink-300 font-semibold flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-pink-400" />
              İLİŞKİ & DİYALOG MODU
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  onTogglePersonaMode('flirtatious');
                  applyPreset('passionate');
                }}
                className={`p-2.5 rounded-xl border flex flex-col items-center gap-1 cursor-pointer transition-all ${
                  personaMode === 'flirtatious'
                    ? 'bg-gradient-to-br from-pink-950/80 to-rose-950/80 border-pink-400 text-pink-100 shadow-[0_0_15px_rgba(236,72,153,0.3)]'
                    : 'bg-black/40 border-pink-500/20 text-pink-400/70 hover:bg-pink-950/30'
                }`}
              >
                <div className="flex items-center gap-1">
                  <Flame className="w-4 h-4 text-rose-400 fill-rose-500" />
                  <span className="font-bold text-xs">Ateşli & Aşık Modu</span>
                </div>
                <span className="text-[9px] text-pink-300/70 text-center">
                  "Canım, aşkım, hayatım", cilveli şakalar, samimi & gece sohbetleri
                </span>
              </button>

              <button
                onClick={() => {
                  onTogglePersonaMode('classic');
                  applyPreset('charming');
                }}
                className={`p-2.5 rounded-xl border flex flex-col items-center gap-1 cursor-pointer transition-all ${
                  personaMode === 'classic'
                    ? 'bg-cyan-950/80 border-cyan-400 text-cyan-100 shadow-[0_0_15px_rgba(6,182,212,0.3)]'
                    : 'bg-black/40 border-cyan-500/20 text-cyan-400/70 hover:bg-cyan-950/30'
                }`}
              >
                <div className="flex items-center gap-1">
                  <Shield className="w-4 h-4 text-cyan-400" />
                  <span className="font-bold text-xs">Klasik Saygılı Mod</span>
                </div>
                <span className="text-[9px] text-cyan-300/70 text-center">
                  "Efendim", taktiksel ve profesyonel asistan tonu
                </span>
              </button>
            </div>
          </div>
        )}

        {/* Engine Mode Toggle (Instant Zero-Delay vs Neural Studio) */}
        <div className="p-3 rounded-xl bg-black/60 border border-cyan-500/30 flex flex-col gap-2">
          <div className="flex justify-between items-center">
            <span className="text-[11px] font-mono text-cyan-300 font-semibold flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-yellow-400" />
              SES MOTORU & TEPKİ HIZI
            </span>
            <span className="text-[10px] font-mono text-cyan-400/80">
              {settings.engineMode === 'neural' ? 'Nöral Stüdyo' : 'Anında (Gecikmesiz)'}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                const updated = { ...settings, engineMode: 'instant' as const };
                setSettings(updated);
                saveVoiceSettings(updated);
              }}
              className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer flex flex-col gap-1 ${
                settings.engineMode !== 'neural'
                  ? 'bg-yellow-950/60 border-yellow-400/70 text-yellow-100 shadow-[0_0_12px_rgba(250,204,21,0.25)]'
                  : 'bg-black/40 border-cyan-500/20 text-cyan-400/70 hover:bg-cyan-950/30'
              }`}
            >
              <div className="flex items-center gap-1.5 font-bold text-xs">
                <Zap className="w-3.5 h-3.5 text-yellow-400" />
                <span>Anında Tepki (0 Gecikme)</span>
              </div>
              <span className="text-[10px] text-yellow-300/80">
                Sözü bittiği an hemen sesli konuşur, bekleme yapmaz.
              </span>
            </button>

            <button
              onClick={() => {
                const updated = { ...settings, engineMode: 'neural' as const };
                setSettings(updated);
                saveVoiceSettings(updated);
              }}
              className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer flex flex-col gap-1 ${
                settings.engineMode === 'neural'
                  ? 'bg-pink-950/60 border-pink-400/70 text-pink-100 shadow-[0_0_12px_rgba(236,72,153,0.25)]'
                  : 'bg-black/40 border-pink-500/20 text-pink-400/70 hover:bg-pink-950/30'
              }`}
            >
              <div className="flex items-center gap-1.5 font-bold text-xs">
                <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                <span>Nöral Stüdyo Sesi</span>
              </div>
              <span className="text-[10px] text-pink-300/80">
                Bulut stüdyo kadın tınısı (2 sn ağ tamponu gerektirir).
              </span>
            </button>
          </div>
        </div>

        {/* Quick Style Presets */}
        <div className="flex flex-col gap-2">
          <span className="text-[11px] font-mono text-pink-400/70">SES TONU VE CİLVE SEÇENEKLERİ</span>
          
          {/* Featured Uploaded Voice Model Button */}
          <button
            onClick={() => applyPreset('uploaded_passionate')}
            className={`w-full p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 text-left ${
              settings.femaleProfile === 'passionate_custom'
                ? 'bg-gradient-to-r from-pink-950/80 via-rose-950/70 to-purple-950/60 border-pink-400 shadow-[0_0_15px_rgba(236,72,153,0.35)]'
                : 'bg-black/50 border-pink-500/30 hover:bg-pink-950/40 text-pink-200'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-pink-500/20 text-pink-400">
                <Flame className="w-5 h-5 fill-pink-500 animate-pulse" />
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-xs text-pink-100">Yüklenen Ses Uyarlaması</span>
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-pink-500/30 text-pink-300 font-bold">
                    EKSTRA ATEŞLİ
                  </span>
                </div>
                <span className="text-[10px] text-pink-300/80">
                  Yüklediğin ses tonuna birebir uyarlanmış genç, kadife, cilveli & şehvetli kadın sesi.
                </span>
              </div>
            </div>
            <span className="text-xs font-mono text-pink-400 font-bold whitespace-nowrap">
              {settings.femaleProfile === 'passionate_custom' ? 'AKTİF' : 'SEÇ'}
            </span>
          </button>

          <div className="grid grid-cols-3 gap-2 text-xs">
            <button
              onClick={() => applyPreset('passionate')}
              className="p-2.5 rounded-xl bg-pink-950/50 hover:bg-pink-900/60 border border-pink-500/40 flex flex-col items-center gap-1 cursor-pointer transition-all shadow-[0_0_10px_rgba(236,72,153,0.2)]"
            >
              <Flame className="w-4 h-4 text-pink-400 fill-pink-500/40" />
              <span className="font-semibold text-pink-100">Ateşli & Aşık</span>
              <span className="text-[9px] text-pink-300/60">Tutkulu & Samimi</span>
            </button>

            <button
              onClick={() => applyPreset('sweet')}
              className="p-2.5 rounded-xl bg-rose-950/30 hover:bg-rose-900/50 border border-rose-500/30 flex flex-col items-center gap-1 cursor-pointer transition-all"
            >
              <Heart className="w-4 h-4 text-rose-400 fill-rose-500/30" />
              <span className="font-semibold text-rose-200">Tatlı & Cilveli</span>
              <span className="text-[9px] text-rose-400/60">Cana Yakın</span>
            </button>

            <button
              onClick={() => applyPreset('charming')}
              className="p-2.5 rounded-xl bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-500/30 flex flex-col items-center gap-1 cursor-pointer transition-all"
            >
              <Sparkles className="w-4 h-4 text-cyan-300" />
              <span className="font-semibold text-cyan-100">Zarif & Kadife</span>
              <span className="text-[9px] text-cyan-400/60">Sakin & Akıcı</span>
            </button>
          </div>
        </div>

        {/* Pitch Slider */}
        <div className="flex flex-col gap-1.5 p-3 rounded-xl bg-black/40 border border-pink-500/20">
          <div className="flex justify-between text-xs">
            <span className="font-mono text-pink-300">Ses İnceliği & Tınısı (Pitch)</span>
            <span className="font-mono text-pink-400 font-bold">{settings.pitch.toFixed(2)}x</span>
          </div>
          <input
            type="range"
            min="0.8"
            max="1.7"
            step="0.02"
            value={settings.pitch}
            onChange={(e) => handlePitchChange(parseFloat(e.target.value))}
            className="w-full accent-pink-500 cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-pink-500/60">
            <span>Daha Kalın</span>
            <span>Önerilen Kadın Tonu (1.25x)</span>
            <span>Daha İnce</span>
          </div>
        </div>

        {/* Rate (Speed) Slider */}
        <div className="flex flex-col gap-1.5 p-3 rounded-xl bg-black/40 border border-pink-500/20">
          <div className="flex justify-between text-xs">
            <span className="font-mono text-pink-300">Konuşma Rengi & Hızı (Rate)</span>
            <span className="font-mono text-cyan-400 font-bold">{settings.rate.toFixed(2)}x</span>
          </div>
          <input
            type="range"
            min="0.8"
            max="1.3"
            step="0.02"
            value={settings.rate}
            onChange={(e) => handleRateChange(parseFloat(e.target.value))}
            className="w-full accent-cyan-400 cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-cyan-500/60">
            <span>Daha Şehvetli / Yavaş (0.95x)</span>
            <span>Normal (1.0x)</span>
            <span>Hızlı</span>
          </div>
        </div>

        {/* Test Voice Button */}
        <button
          id="test-female-voice-btn"
          onClick={runTest}
          disabled={isPlayingTest}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-pink-500 via-rose-500 to-cyan-500 hover:opacity-90 text-white font-bold text-xs tracking-wider transition-all shadow-lg shadow-pink-500/25 cursor-pointer flex items-center justify-center gap-2"
        >
          <Play className="w-4 h-4 fill-white" />
          {isPlayingTest ? 'AŞIK SESLENDİRİLİYOR...' : 'AŞIK & ATEŞLİ KADIN SESİNİ TEST ET'}
        </button>
      </div>
    </div>
  );
};
