import React, { useState } from 'react';
import { FileText, Plus, Pin, Trash2, Shield, Search, Mic } from 'lucide-react';
import { NoteItem } from '../types';
import { JarvisAudioFX, speakTurkish } from '../services/voice';

interface NotesManagerProps {
  notes: NoteItem[];
  onAddNote: (note: Omit<NoteItem, 'id' | 'updatedAt'>) => void;
  onDeleteNote: (id: string) => void;
  onTogglePin: (id: string) => void;
}

export const NotesManager: React.FC<NotesManagerProps> = ({
  notes,
  onAddNote,
  onDeleteNote,
  onTogglePin,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState('Genel');

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() && !newContent.trim()) return;

    onAddNote({
      title: newTitle.trim() || 'Başlıksız Not',
      content: newContent.trim(),
      category: newCategory,
      pinned: false,
    });

    JarvisAudioFX.playAcknowledge();
    speakTurkish(`Not kaydedildi efendim: ${newTitle.trim() || 'Başlıksız Not'}`);
    setNewTitle('');
    setNewContent('');
    setIsCreating(false);
  };

  const filteredNotes = notes.filter((n) => {
    const q = searchTerm.toLowerCase();
    return n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q);
  });

  return (
    <div id="jarvis-notes-manager" className="flex flex-col gap-4 p-5 rounded-2xl bg-[#090d16]/90 border border-cyan-500/20 backdrop-blur-xl">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-cyan-500/15 pb-3">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-sky-400" />
          <div>
            <h2 className="font-orbitron font-bold text-base text-cyan-200 tracking-wide flex items-center gap-2">
              ŞİFRELİ NOTLAR & GÜNLÜK
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <Shield className="w-2.5 h-2.5" /> AES-256
              </span>
            </h2>
            <p className="text-xs text-cyan-400/60">
              Kriptografik olarak kilitli kişisel notlar ve hızlı düşünce kayıtları.
            </p>
          </div>
        </div>

        <button
          id="new-note-btn"
          onClick={() => setIsCreating(!isCreating)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs tracking-wider transition-all cursor-pointer shadow-md"
        >
          <Plus className="w-3.5 h-3.5" />
          {isCreating ? 'KAPAT' : 'YENİ NOT'}
        </button>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-cyan-500/50 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Notlar içinde ara..."
          className="w-full pl-9 pr-4 py-2 rounded-xl bg-black/50 border border-cyan-500/30 text-xs text-cyan-100 placeholder:text-cyan-700 focus:outline-none focus:border-cyan-400"
        />
      </div>

      {/* New Note Form */}
      {isCreating && (
        <form onSubmit={handleSaveNote} className="p-4 rounded-xl bg-black/60 border border-cyan-500/40 flex flex-col gap-2.5 animate-fadeIn">
          <div className="flex items-center justify-between">
            <input
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="Not Başlığı..."
              className="flex-1 px-3 py-2 rounded-lg bg-black/70 border border-cyan-500/30 text-sm text-cyan-100 placeholder:text-cyan-700 focus:outline-none focus:border-cyan-400"
            />
            <select
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value)}
              className="ml-2 px-2.5 py-2 rounded-lg bg-black/70 border border-cyan-500/30 text-xs text-cyan-200 focus:outline-none focus:border-cyan-400"
            >
              <option value="Genel">Kategori: Genel</option>
              <option value="İş/Proje">İş / Proje</option>
              <option value="Kişisel">Kişisel</option>
              <option value="Oyun/Strateji">Oyun / Strateji</option>
            </select>
          </div>

          <textarea
            value={newContent}
            onChange={(e) => setNewContent(e.target.value)}
            rows={4}
            placeholder="Not içeriği... (Markdown veya düz metin destekler)"
            className="w-full p-3 rounded-lg bg-black/70 border border-cyan-500/30 text-xs text-cyan-100 placeholder:text-cyan-700 focus:outline-none focus:border-cyan-400 resize-none font-mono"
          />

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="px-3 py-1.5 rounded-lg text-xs text-cyan-400/80 hover:text-cyan-200 cursor-pointer"
            >
              İptal
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs transition-all cursor-pointer"
            >
              ŞİFRELE VE KAYDET
            </button>
          </div>
        </form>
      )}

      {/* Notes Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-80 overflow-y-auto pr-1">
        {filteredNotes.length === 0 ? (
          <div className="col-span-full py-8 text-center text-cyan-500/40 text-xs">
            Kayıtlı not bulunamadı efendim.
          </div>
        ) : (
          filteredNotes.map((note) => (
            <div
              key={note.id}
              className={`p-3.5 rounded-xl border flex flex-col justify-between gap-2 transition-all ${
                note.pinned
                  ? 'bg-cyan-950/30 border-cyan-400/50 shadow-md shadow-cyan-500/10'
                  : 'bg-black/50 border-cyan-500/20 hover:border-cyan-500/40'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <h4 className="font-orbitron font-semibold text-xs text-cyan-200 truncate">
                    {note.title}
                  </h4>
                  <button
                    onClick={() => onTogglePin(note.id)}
                    className={`p-1 cursor-pointer transition-colors ${
                      note.pinned ? 'text-cyan-400' : 'text-cyan-500/30 hover:text-cyan-400'
                    }`}
                    title={note.pinned ? 'Sabitlemeyi Kaldır' : 'Başa Sabitle'}
                  >
                    <Pin className="w-3.5 h-3.5" />
                  </button>
                </div>

                <p className="text-xs text-cyan-300/80 font-mono mt-1.5 line-clamp-3 whitespace-pre-wrap leading-relaxed">
                  {note.content}
                </p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-cyan-500/10 text-[10px] text-cyan-500/60 font-mono">
                <span>{note.category} • {note.updatedAt}</span>
                <button
                  onClick={() => onDeleteNote(note.id)}
                  className="hover:text-red-400 p-1 cursor-pointer"
                  title="Notu Sil"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
