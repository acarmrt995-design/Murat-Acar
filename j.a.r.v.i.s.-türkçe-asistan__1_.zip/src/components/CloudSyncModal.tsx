import React, { useState } from 'react';
import { Cloud, Upload, Download, Copy, Check, Shield, X, RefreshCw } from 'lucide-react';
import { encryptData, decryptData } from '../services/crypto';
import { JarvisAudioFX, speakTurkish } from '../services/voice';

interface CloudSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  fullAppState: any;
  onRestoreState: (state: any) => void;
}

export const CloudSyncModal: React.FC<CloudSyncModalProps> = ({
  isOpen,
  onClose,
  fullAppState,
  onRestoreState,
}) => {
  const [copied, setCopied] = useState(false);
  const [encryptedPayload, setEncryptedPayload] = useState<string>('');
  const [importPayload, setImportPayload] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [message, setMessage] = useState<string>('');

  const generateEncryptedBackup = async () => {
    setIsGenerating(true);
    try {
      const encrypted = await encryptData(fullAppState);
      setEncryptedPayload(encrypted);
      setMessage("Şifreli veri paketi başarıyla üretildi (AES-GCM 256-bit).");
      JarvisAudioFX.playAcknowledge();
    } catch (e) {
      setMessage("Yedekleme oluşturulamadı.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    if (!encryptedPayload) return;
    navigator.clipboard.writeText(encryptedPayload);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    JarvisAudioFX.playAcknowledge();
  };

  const downloadJSONBackup = async () => {
    try {
      const encrypted = encryptedPayload || (await encryptData(fullAppState));
      const blob = new Blob([encrypted], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `JARVIS_E2EE_Vault_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      JarvisAudioFX.playBiometricPass();
      speakTurkish('Şifreli bulut yedekleme dosyanız indirildi efendim.');
    } catch (e) {
      console.warn("Download error:", e);
    }
  };

  const handleRestore = async () => {
    if (!importPayload.trim()) return;
    setIsRestoring(true);
    try {
      const decrypted = await decryptData(importPayload.trim());
      if (decrypted && (decrypted.tasks || decrypted.notes || decrypted.calendar)) {
        onRestoreState(decrypted);
        setMessage("Tüm verileriniz şifreli kasadan başarıyla senkronize edildi.");
        JarvisAudioFX.playBiometricPass();
        speakTurkish('Bulut verileriniz çözüldü ve sisteme senkronize edildi efendim.');
        setTimeout(() => {
          onClose();
        }, 1200);
      } else {
        setMessage("Geçersiz veya bozuk şifreli veri paketi.");
      }
    } catch (e) {
      setMessage("Şifre çözme işlemi başarısız oldu.");
    } finally {
      setIsRestoring(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        setImportPayload(text);
      }
    };
    reader.readAsText(file);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg p-6 rounded-2xl bg-[#090d16] border border-cyan-500/40 shadow-2xl flex flex-col gap-4 text-cyan-100 animate-fadeIn">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-cyan-400/60 hover:text-cyan-200 hover:bg-cyan-950 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-2.5 border-b border-cyan-500/20 pb-3">
          <Cloud className="w-6 h-6 text-cyan-400" />
          <div>
            <h3 className="font-orbitron font-bold text-sm tracking-wider text-cyan-200">
              UÇTAN UCA ŞİFRELİ BULUT SENKRONİZASYONU
            </h3>
            <p className="text-xs text-cyan-400/60 font-mono">
              Cihazlar arası veri transferi ve kriptografik kilitli yedekleme
            </p>
          </div>
        </div>

        {/* Section 1: Export */}
        <div className="p-4 rounded-xl bg-black/40 border border-cyan-500/20 flex flex-col gap-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-orbitron font-semibold text-cyan-300 flex items-center gap-1.5">
              <Download className="w-4 h-4 text-cyan-400" />
              1. CİHAZDAN ŞİFRELİ DIŞA AKTAR
            </span>
            <button
              onClick={generateEncryptedBackup}
              disabled={isGenerating}
              className="px-3 py-1 rounded-lg bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/30 text-xs text-cyan-300 transition-colors cursor-pointer"
            >
              Paket Oluştur
            </button>
          </div>

          {encryptedPayload && (
            <div className="flex flex-col gap-2 mt-1">
              <textarea
                readOnly
                value={encryptedPayload}
                rows={3}
                className="w-full p-2.5 rounded-lg bg-black/70 border border-cyan-500/30 text-[11px] font-mono text-cyan-300 resize-none"
              />
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopy}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-black font-bold text-xs cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'KOPYALANDI' : 'ŞİFRELİ METNİ KOPYALA'}
                </button>
                <button
                  onClick={downloadJSONBackup}
                  className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-black/60 hover:bg-black/90 border border-cyan-500/40 text-cyan-200 text-xs font-semibold cursor-pointer"
                >
                  .JSON İNDİR
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Section 2: Import */}
        <div className="p-4 rounded-xl bg-black/40 border border-cyan-500/20 flex flex-col gap-2.5">
          <span className="text-xs font-orbitron font-semibold text-cyan-300 flex items-center gap-1.5">
            <Upload className="w-4 h-4 text-sky-400" />
            2. DİĞER CİHAZA İÇE AKTAR (SENKRONİZE ET)
          </span>

          <textarea
            value={importPayload}
            onChange={(e) => setImportPayload(e.target.value)}
            placeholder="Başka bir cihazdan aldığınız AES-GCM şifreli veri paketini buraya yapıştırın..."
            rows={3}
            className="w-full p-2.5 rounded-lg bg-black/70 border border-cyan-500/30 text-[11px] font-mono text-cyan-300 resize-none placeholder:text-cyan-700"
          />

          <div className="flex items-center justify-between gap-2">
            <label className="text-[11px] text-cyan-400 hover:text-cyan-200 cursor-pointer underline">
              <span>.JSON Dosyası Seç</span>
              <input
                type="file"
                accept=".json"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>

            <button
              onClick={handleRestore}
              disabled={isRestoring || !importPayload.trim()}
              className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-black font-bold text-xs cursor-pointer flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRestoring ? 'animate-spin' : ''}`} />
              ŞİFREYİ ÇÖZ & SENKRONİZE ET
            </button>
          </div>
        </div>

        {/* Status Message */}
        {message && (
          <div className="text-center text-xs font-mono text-cyan-300 py-1">
            {message}
          </div>
        )}
      </div>
    </div>
  );
};
