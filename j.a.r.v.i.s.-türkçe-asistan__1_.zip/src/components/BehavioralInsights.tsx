import React, { useState } from 'react';
import { Brain, Sparkles, TrendingUp, Award, Clock, RefreshCw, Volume2 } from 'lucide-react';
import { BehavioralInsight, UserHabits } from '../types';
import { speakTurkish, JarvisAudioFX } from '../services/voice';

interface BehavioralInsightsProps {
  habits: UserHabits;
  insights: BehavioralInsight[];
  onRefreshInsights: () => void;
  isRefreshing: boolean;
}

export const BehavioralInsights: React.FC<BehavioralInsightsProps> = ({
  habits,
  insights,
  onRefreshInsights,
  isRefreshing,
}) => {
  return (
    <div id="jarvis-behavioral-insights" className="flex flex-col gap-4 p-5 rounded-2xl bg-[#090d16]/90 border border-cyan-500/20 backdrop-blur-xl">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-cyan-500/15 pb-3">
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-indigo-400" />
          <div>
            <h2 className="font-orbitron font-bold text-base text-cyan-200 tracking-wide flex items-center gap-2">
              DAVRANIŞSAL ÖĞRENME & PROAKTİF TAVSİYELER
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                KİŞİSEL ALGORİTMA
              </span>
            </h2>
            <p className="text-xs text-cyan-400/60">
              Jarvis alışkanlıklarınızı analiz eder ve size özel proaktif optimizasyon önerileri sunar.
            </p>
          </div>
        </div>

        <button
          onClick={onRefreshInsights}
          disabled={isRefreshing}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-400/40 text-indigo-200 text-xs font-semibold tracking-wider transition-all cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
          YENİDEN ANALİZ ET
        </button>
      </div>

      {/* Habit Telemetry Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 rounded-xl bg-black/40 border border-cyan-500/20">
          <div className="text-[11px] font-mono text-cyan-400/70">SESLİ ETKİLEŞİM</div>
          <div className="text-lg font-orbitron font-bold text-cyan-200 mt-1">
            {habits.totalVoiceCommands}
          </div>
          <div className="text-[10px] text-cyan-500/50 mt-0.5">Komut Kaydedildi</div>
        </div>

        <div className="p-3 rounded-xl bg-black/40 border border-cyan-500/20">
          <div className="text-[11px] font-mono text-red-400/70">OYUN & EKRAN ANALİZİ</div>
          <div className="text-lg font-orbitron font-bold text-red-300 mt-1">
            {habits.gamingSessionsCount}
          </div>
          <div className="text-[10px] text-red-500/50 mt-0.5">Taktik İstendi</div>
        </div>

        <div className="p-3 rounded-xl bg-black/40 border border-cyan-500/20">
          <div className="text-[11px] font-mono text-emerald-400/70">VERİMLİLİK SKORU</div>
          <div className="text-lg font-orbitron font-bold text-emerald-300 mt-1">
            %94.8
          </div>
          <div className="text-[10px] text-emerald-500/50 mt-0.5">Optimum Ritim</div>
        </div>

        <div className="p-3 rounded-xl bg-black/40 border border-cyan-500/20">
          <div className="text-[11px] font-mono text-amber-400/70">AKTİF ZAMAN DİLİMİ</div>
          <div className="text-lg font-orbitron font-bold text-amber-300 mt-1">
            14:00 - 23:00
          </div>
          <div className="text-[10px] text-amber-500/50 mt-0.5">Tespit Edilen Aralık</div>
        </div>
      </div>

      {/* Personalized AI Suggestions */}
      <div className="flex flex-col gap-2.5">
        <div className="text-xs font-mono text-cyan-400/80 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>JARVIS PROAKTİF TAVSİYE LİSTESİ</span>
        </div>

        {insights.map((item) => (
          <div
            key={item.id}
            className="p-3.5 rounded-xl bg-black/50 border border-cyan-500/20 hover:border-cyan-500/40 transition-all flex items-start justify-between gap-3"
          >
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-2">
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-md border ${
                    item.category === 'OYUN'
                      ? 'bg-red-500/20 text-red-400 border-red-500/30'
                      : item.category === 'SAĞLIK'
                      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                      : 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
                  }`}
                >
                  {item.category}
                </span>
                <h4 className="font-orbitron font-semibold text-xs text-cyan-200">
                  {item.title}
                </h4>
              </div>
              <p className="text-xs text-cyan-300/80 font-mono mt-0.5 leading-relaxed">
                {item.message}
              </p>
            </div>

            <button
              onClick={() => {
                JarvisAudioFX.playAcknowledge();
                speakTurkish(item.message);
              }}
              className="p-2 rounded-lg bg-cyan-950/60 hover:bg-cyan-900 border border-cyan-500/30 text-cyan-300 cursor-pointer"
              title="Jarvis'ten Dinle"
            >
              <Volume2 className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
