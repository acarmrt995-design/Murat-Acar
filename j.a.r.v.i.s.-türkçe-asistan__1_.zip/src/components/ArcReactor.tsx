import React from 'react';
import { Mic, MicOff, Radio, Cpu, Volume2, ShieldCheck, Wifi, WifiOff, Sparkles, Flame, Heart } from 'lucide-react';

interface ArcReactorProps {
  isListening: boolean;
  isSpeaking: boolean;
  isProcessing: boolean;
  isGamingMode: boolean;
  isOffline: boolean;
  onToggleMic: () => void;
  statusText: string;
  onOpenVoiceSettings?: () => void;
  personaMode?: 'flirtatious' | 'classic';
  micVolume?: number;
}

export const ArcReactor: React.FC<ArcReactorProps> = ({
  isListening,
  isSpeaking,
  isProcessing,
  isGamingMode,
  isOffline,
  onToggleMic,
  statusText,
  onOpenVoiceSettings,
  personaMode = 'flirtatious',
  micVolume = 0,
}) => {
  // Determine primary color tone based on mode
  const glowColor = isGamingMode
    ? 'rgba(239, 68, 68, 0.8)' // Crimson red for gaming tactical mode
    : isProcessing
    ? 'rgba(234, 179, 8, 0.8)' // Amber for processing
    : isListening
    ? 'rgba(6, 182, 212, 1)' // Cyan electric for listening
    : 'rgba(56, 189, 248, 0.7)'; // Calm blue for idle

  const ringBorderColor = isGamingMode
    ? 'border-red-500/50'
    : isProcessing
    ? 'border-amber-400/50'
    : isListening
    ? 'border-cyan-400 shadow-[0_0_30px_rgba(6,182,212,0.6)]'
    : 'border-cyan-500/30';

  return (
    <div id="jarvis-arc-reactor-card" className="relative flex flex-col items-center justify-center p-6 rounded-2xl bg-[#090d16]/80 border border-cyan-500/20 backdrop-blur-xl shadow-2xl overflow-hidden">
      {/* Background radial gradient glow */}
      <div
        className="absolute w-80 h-80 rounded-full blur-3xl pointer-events-none transition-all duration-700 -z-10"
        style={{
          background: `radial-gradient(circle, ${glowColor} 0%, rgba(0,0,0,0) 70%)`,
          opacity: isListening || isSpeaking ? 0.45 : 0.15,
        }}
      />

      {/* Top telemetry bar */}
      <div className="w-full flex items-center justify-between mb-4 px-2 text-xs font-mono text-cyan-400/80 border-b border-cyan-500/10 pb-2">
        <div className="flex items-center gap-2">
          <Cpu className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
          <span className="tracking-widest">J.A.R.V.I.S. V4.8</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-emerald-400">AES-256</span>
          </span>
          <span className="flex items-center gap-1">
            {isOffline ? (
              <>
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-amber-400">ÇEVRİMDIŞI</span>
              </>
            ) : (
              <>
                <Wifi className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-cyan-400">ÇEVRİMİÇİ</span>
              </>
            )}
          </span>
        </div>
      </div>

      {/* Center Interactive Arc Reactor Visual */}
      <div className="relative w-56 h-56 flex items-center justify-center my-2">
        {/* Outer Ring 1 - slow rotation */}
        <div
          className={`absolute inset-0 rounded-full border border-dashed ${ringBorderColor} animate-spin-slow transition-colors duration-500`}
        />

        {/* Outer Ring 2 - reverse rotation with tick marks */}
        <div
          className={`absolute inset-3 rounded-full border border-cyan-500/20 animate-spin-reverse`}
          style={{ borderTopColor: isGamingMode ? '#ef4444' : '#06b6d4' }}
        />

        {/* Ring 3 - segmented arcs */}
        <svg className="absolute inset-4 w-[calc(100%-2rem)] h-[calc(100%-2rem)] animate-spin-slow opacity-60">
          <circle
            cx="50%"
            cy="50%"
            r="44%"
            fill="none"
            stroke={isGamingMode ? '#f87171' : '#38bdf8'}
            strokeWidth="2"
            strokeDasharray="16 28"
          />
        </svg>

        {/* Pulsing Core container */}
        <div
          className={`relative w-36 h-36 rounded-full flex flex-col items-center justify-center transition-all duration-300 ${
            isListening ? 'scale-105 shadow-[0_0_50px_rgba(6,182,212,0.8)]' : isSpeaking ? 'scale-100 shadow-[0_0_35px_rgba(56,189,248,0.6)]' : 'scale-95'
          }`}
          style={{
            background: 'radial-gradient(circle, #0c1829 0%, #030712 100%)',
            border: `2px solid ${isGamingMode ? '#ef4444' : '#06b6d4'}`,
          }}
        >
          {/* Inner holographic grid & power coils */}
          <div className="absolute inset-2 rounded-full border border-cyan-400/30 flex items-center justify-center pointer-events-none">
            <div className="w-20 h-20 rounded-full border border-cyan-300/40 animate-ping opacity-25" />
          </div>

          {/* Interactive Mic / State Button */}
          <button
            id="jarvis-toggle-voice-btn"
            onClick={onToggleMic}
            className={`relative z-10 w-16 h-16 rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer ${
              isListening
                ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/50 scale-110'
                : isGamingMode
                ? 'bg-red-600/80 hover:bg-red-500 text-white'
                : 'bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-400/50 text-cyan-300'
            }`}
            title={isListening ? 'Dinlemeyi Durdur' : 'Sesli Komutu Başlat (Jarvis)'}
          >
            {isListening ? (
              <Mic className="w-8 h-8 animate-pulse text-black" />
            ) : (
              <MicOff className="w-7 h-7 text-cyan-300" />
            )}
          </button>

          {/* Real-time sound wave bars underneath */}
          <div className="flex items-center gap-1 mt-2 h-4">
            {[0.4, 0.8, 1.2, 0.9, 0.5, 0.3].map((delay, idx) => (
              <span
                key={idx}
                className={`w-1 rounded-full transition-all duration-100 ${
                  isGamingMode ? 'bg-red-400' : 'bg-cyan-400'
                }`}
                style={{
                  height: isListening
                    ? `${Math.max(4, Math.min(22, (micVolume / 100) * 22 * (0.6 + Math.sin(idx * 1.5) * 0.4)))}px`
                    : isSpeaking
                    ? `${Math.max(4, Math.sin(Date.now() / 200 + idx) * 16)}px`
                    : '3px',
                }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Dynamic Status Text */}
      <div className="mt-3 text-center">
        <div className="flex items-center justify-center gap-2 font-orbitron text-sm font-semibold tracking-wider">
          {isListening && <Radio className="w-4 h-4 text-cyan-400 animate-ping" />}
          {isSpeaking && <Volume2 className="w-4 h-4 text-sky-400 animate-bounce" />}
          <span
            className={`${
              isGamingMode
                ? 'text-red-400'
                : isListening
                ? 'text-cyan-400'
                : isSpeaking
                ? 'text-sky-300'
                : 'text-cyan-200/80'
            }`}
          >
            {isListening
              ? micVolume > 10
                ? `SES ALGILANIYOR (%${micVolume})`
                : 'SESLİ DİNLENİYOR... ("JARVIS" VEYA KONUŞUN)'
              : isProcessing
              ? 'İŞLENİYOR & ANALİZ EDİLİYOR...'
              : isSpeaking
              ? (personaMode === 'flirtatious' ? 'AŞKIN KONUŞUYOR...' : 'JARVIS YANITLIYOR...')
              : isGamingMode
              ? 'CANLI OYUN KOÇU AKTİF'
              : (personaMode === 'flirtatious' ? 'SENİN İÇİN BURADAYIM AŞKIM' : 'SİSTEM HAZIR - EFENDİM')}
          </span>
        </div>
        <p className="text-xs text-cyan-400/60 font-mono mt-1 max-w-sm truncate px-2">
          {statusText || (personaMode === 'flirtatious' ? 'Aşkım, sesini duymak için sabırsızlanıyorum...' : 'Sesli komut için ortadaki çekirdeğe tıklayın veya mikrofonu açın.')}
        </p>

        {onOpenVoiceSettings && (
          <button
            onClick={onOpenVoiceSettings}
            className={`mt-2.5 inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-[11px] font-mono transition-all cursor-pointer hover:scale-105 ${
              personaMode === 'flirtatious'
                ? 'bg-rose-950/50 hover:bg-rose-900/70 border-rose-500/50 text-rose-300 shadow-[0_0_12px_rgba(244,63,94,0.25)]'
                : 'bg-pink-950/40 hover:bg-pink-900/60 border border-pink-500/40 text-pink-300 shadow-[0_0_10px_rgba(236,72,153,0.15)]'
            }`}
            title="Kadın sesi ve ilişki modunu ayarla"
          >
            {personaMode === 'flirtatious' ? (
              <>
                <Flame className="w-3 h-3 text-rose-400 animate-pulse fill-rose-500" />
                <span>Mod: Ateşli & Aşık Sevgili</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3 h-3 text-pink-400 animate-pulse" />
                <span>Ses Modu: Zarif & Çekici Kadın Sesi</span>
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
};
