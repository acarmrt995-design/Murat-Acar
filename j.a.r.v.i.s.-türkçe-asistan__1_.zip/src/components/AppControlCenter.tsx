import React, { useState } from 'react';
import {
  Gamepad2,
  Music,
  MessageSquare,
  Globe,
  Cpu,
  Plus,
  Trash2,
  Play,
  Square,
  ExternalLink,
  Search,
  Sparkles,
  CheckCircle2,
  Mic,
  Zap,
  Layers,
  X,
  RefreshCw,
  Terminal,
} from 'lucide-react';
import { ControlledApp } from '../types';
import { JarvisAudioFX, speakTurkish } from '../services/voice';

// Default built-in popular apps and games
export const DEFAULT_CONTROLLED_APPS: ControlledApp[] = [
  {
    id: 'app-spotify',
    name: 'Spotify',
    category: 'Müzik & Medya',
    voiceTriggers: ['spotify aç', 'spotify başlat', 'şarkı aç', 'müzik çal', 'şarkı çal'],
    closeTriggers: ['spotify kapat', 'müziği durdur', 'şarkıyı kapat'],
    launchType: 'protocol',
    launchTarget: 'spotify:',
    status: 'Kapalı',
    isDefault: true,
  },
  {
    id: 'app-discord',
    name: 'Discord',
    category: 'İletişim & Sosyal',
    voiceTriggers: ['discord aç', 'discord başlat', 'sohbete gir'],
    closeTriggers: ['discord kapat', 'discorddan çık'],
    launchType: 'web',
    launchTarget: 'https://discord.com/app',
    status: 'Kapalı',
    isDefault: true,
  },
  {
    id: 'app-steam',
    name: 'Steam',
    category: 'Oyun',
    voiceTriggers: ['steam aç', 'steam başlat', 'oyun kütüphanesini aç'],
    closeTriggers: ['steam kapat', 'steami kapat'],
    launchType: 'protocol',
    launchTarget: 'steam://open/main',
    status: 'Kapalı',
    isDefault: true,
  },
  {
    id: 'app-valorant',
    name: 'Valorant',
    category: 'Oyun',
    voiceTriggers: ['valorant aç', 'valorant başlat', 'valoyu aç', 'valoranta gir'],
    closeTriggers: ['valorant kapat', 'valoyu kapat', 'oyundan çık'],
    launchType: 'protocol',
    launchTarget: 'riotclient://',
    status: 'Kapalı',
    isDefault: true,
  },
  {
    id: 'app-cs2',
    name: 'Counter-Strike 2 (CS2)',
    category: 'Oyun',
    voiceTriggers: ['cs2 aç', 'counter strike aç', 'cs aç', 'cs başlat'],
    closeTriggers: ['cs2 kapat', 'counter strike kapat', 'cs kapat'],
    launchType: 'protocol',
    launchTarget: 'steam://run/730',
    status: 'Kapalı',
    isDefault: true,
  },
  {
    id: 'app-lol',
    name: 'League of Legends (LoL)',
    category: 'Oyun',
    voiceTriggers: ['lol aç', 'league of legends aç', 'lolu aç', 'lol başlat'],
    closeTriggers: ['lol kapat', 'lolu kapat', 'league of legends kapat'],
    launchType: 'protocol',
    launchTarget: 'riotclient://',
    status: 'Kapalı',
    isDefault: true,
  },
  {
    id: 'app-gta5',
    name: 'Grand Theft Auto V (GTA 5)',
    category: 'Oyun',
    voiceTriggers: ['gta aç', 'gta 5 aç', 'gta başlat', 'gta beş aç'],
    closeTriggers: ['gta kapat', 'gta 5 kapat', 'gta beş kapat'],
    launchType: 'protocol',
    launchTarget: 'steam://run/271590',
    status: 'Kapalı',
    isDefault: true,
  },
  {
    id: 'app-youtube',
    name: 'YouTube',
    category: 'Müzik & Medya',
    voiceTriggers: ['youtube aç', 'videoları aç', 'video aç'],
    closeTriggers: ['youtube kapat', 'videoyu kapat'],
    launchType: 'web',
    launchTarget: 'https://youtube.com',
    status: 'Kapalı',
    isDefault: true,
  },
  {
    id: 'app-chrome',
    name: 'Google Chrome',
    category: 'Araç & Tarayıcı',
    voiceTriggers: ['chrome aç', 'tarayıcıyı aç', 'interneti aç', 'tarayıcı aç'],
    closeTriggers: ['chrome kapat', 'tarayıcıyı kapat'],
    launchType: 'web',
    launchTarget: 'https://google.com',
    status: 'Kapalı',
    isDefault: true,
  },
  {
    id: 'app-calc',
    name: 'Hesap Makinesi',
    category: 'Araç & Tarayıcı',
    voiceTriggers: ['hesap makinesi aç', 'hesap makinesini aç', 'hesap yap'],
    closeTriggers: ['hesap makinesini kapat', 'hesap makinesi kapat'],
    launchType: 'protocol',
    launchTarget: 'calculator:',
    status: 'Kapalı',
    isDefault: true,
  },
  {
    id: 'app-vscode',
    name: 'Visual Studio Code',
    category: 'Sistem & Geliştirici',
    voiceTriggers: ['vs code aç', 'kodu aç', 'kod editörünü aç', 'vscode aç'],
    closeTriggers: ['vs code kapat', 'vscode kapat', 'kodu kapat'],
    launchType: 'protocol',
    launchTarget: 'vscode://',
    status: 'Kapalı',
    isDefault: true,
  },
  {
    id: 'app-notepad',
    name: 'Not Defteri',
    category: 'Araç & Tarayıcı',
    voiceTriggers: ['not defteri aç', 'not defterini aç', 'metin belgesi aç'],
    closeTriggers: ['not defteri kapat', 'not defterini kapat'],
    launchType: 'protocol',
    launchTarget: 'notepad:',
    status: 'Kapalı',
    isDefault: true,
  },
];

interface AppControlCenterProps {
  apps: ControlledApp[];
  onUpdateApps: (apps: ControlledApp[]) => void;
  onLaunchApp: (app: ControlledApp) => void;
  onCloseApp: (app: ControlledApp) => void;
  personaMode: 'flirtatious' | 'classic';
}

export const AppControlCenter: React.FC<AppControlCenterProps> = ({
  apps,
  onUpdateApps,
  onLaunchApp,
  onCloseApp,
  personaMode,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('Tümü');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  // New App Form State
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState<ControlledApp['category']>('Oyun');
  const [newTriggers, setNewTriggers] = useState('');
  const [newCloseTriggers, setNewCloseTriggers] = useState('');
  const [newLaunchType, setNewLaunchType] = useState<ControlledApp['launchType']>('protocol');
  const [newLaunchTarget, setNewLaunchTarget] = useState('');

  const categories: string[] = [
    'Tümü',
    'Oyun',
    'Müzik & Medya',
    'İletişim & Sosyal',
    'Araç & Tarayıcı',
    'Sistem & Geliştirici',
  ];

  const filteredApps = apps.filter((app) => {
    const matchesCat = activeCategory === 'Tümü' || app.category === activeCategory;
    const matchesSearch =
      app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.voiceTriggers.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  const getCategoryIcon = (category: ControlledApp['category']) => {
    switch (category) {
      case 'Oyun':
        return <Gamepad2 className="w-5 h-5 text-emerald-400" />;
      case 'Müzik & Medya':
        return <Music className="w-5 h-5 text-purple-400" />;
      case 'İletişim & Sosyal':
        return <MessageSquare className="w-5 h-5 text-blue-400" />;
      case 'Araç & Tarayıcı':
        return <Globe className="w-5 h-5 text-amber-400" />;
      case 'Sistem & Geliştirici':
        return <Cpu className="w-5 h-5 text-cyan-400" />;
      default:
        return <Layers className="w-5 h-5 text-gray-400" />;
    }
  };

  const handleAddNewApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const triggerArray = newTriggers
      .split(',')
      .map((t) => t.trim().toLowerCase())
      .filter(Boolean);

    if (triggerArray.length === 0) {
      triggerArray.push(`${newName.toLowerCase()} aç`, newName.toLowerCase());
    }

    const closeArray = newCloseTriggers
      .split(',')
      .map((t) => t.trim().toLowerCase())
      .filter(Boolean);

    if (closeArray.length === 0) {
      closeArray.push(`${newName.toLowerCase()} kapat`);
    }

    const newAppItem: ControlledApp = {
      id: `app-${Date.now()}`,
      name: newName.trim(),
      category: newCategory,
      voiceTriggers: triggerArray,
      closeTriggers: closeArray,
      launchType: newLaunchType,
      launchTarget: newLaunchTarget.trim() || `${newName.toLowerCase()}:`,
      status: 'Kapalı',
    };

    const updated = [newAppItem, ...apps];
    onUpdateApps(updated);
    JarvisAudioFX.playBiometricPass();

    const msg =
      personaMode === 'flirtatious'
        ? `'${newAppItem.name}' uygulamasını zihnime ve kontrol merkezine kaydettim canım. Artık bana '${triggerArray[0]}' dediğinde hemen açarım sevgilim.`
        : `Efendim, '${newAppItem.name}' kontrol listenize eklendi. Sesli komutunuzla derhal başlatılacaktır.`;

    speakTurkish(msg);
    setSuccessNotice(`"${newAppItem.name}" başarıyla eklendi!`);
    setTimeout(() => setSuccessNotice(null), 4000);

    // Reset Form
    setNewName('');
    setNewTriggers('');
    setNewCloseTriggers('');
    setNewLaunchTarget('');
    setIsAddModalOpen(false);
  };

  const handleDeleteApp = (id: string, name: string) => {
    const updated = apps.filter((a) => a.id !== id);
    onUpdateApps(updated);
    JarvisAudioFX.playAcknowledge();
    setSuccessNotice(`"${name}" uygulaması kaldırıldı.`);
    setTimeout(() => setSuccessNotice(null), 3000);
  };

  const handleResetDefaults = () => {
    onUpdateApps(DEFAULT_CONTROLLED_APPS);
    JarvisAudioFX.playAcknowledge();
    setSuccessNotice('Popüler oyun ve uygulama listesi varsayılana sıfırlandı.');
    setTimeout(() => setSuccessNotice(null), 3000);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Top Banner & Statistics */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-cyan-950/60 via-slate-900/80 to-blue-950/60 border border-cyan-500/30 backdrop-blur-md shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <Gamepad2 className="w-8 h-8 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-orbitron text-lg font-bold text-cyan-100 tracking-wider">
                UYGULAMA & OYUN KONTROL MERKEZİ
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 border border-cyan-400/40 text-[11px] font-mono text-cyan-300">
                SESLİ TETİKLEME AKTİF
              </span>
            </div>
            <p className="text-xs text-cyan-300/80 mt-1 max-w-2xl leading-relaxed">
              J.A.R.V.I.S.'ın sesinizle veya tek tıkla açıp kapatabileceği tüm oyunlar ve programlar burada. İstediğiniz tüm oyunları ve yazılımları ekleyin; mikrofonunuza <em>"Valorant aç"</em> veya <em>"Spotify kapat"</em> dediğinizde anında yürütür.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-black font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>+ YENİ UYGULAMA / OYUN EKLE</span>
          </button>
        </div>
      </div>

      {/* Success Notification Alert */}
      {successNotice && (
        <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-200 text-xs font-medium animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successNotice}</span>
        </div>
      )}

      {/* Control Metrics Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-black/40 border border-cyan-500/20 flex flex-col gap-1">
          <span className="text-[11px] font-mono text-cyan-400/70">KAYITLI UYGULAMA / OYUN</span>
          <span className="font-orbitron text-xl font-bold text-cyan-200">{apps.length} Adet</span>
        </div>
        <div className="p-3.5 rounded-xl bg-black/40 border border-emerald-500/20 flex flex-col gap-1">
          <span className="text-[11px] font-mono text-emerald-400/70">AÇIK / AKTİF DURUMDA</span>
          <span className="font-orbitron text-xl font-bold text-emerald-300">
            {apps.filter((a) => a.status === 'Açık').length} Aktif
          </span>
        </div>
        <div className="p-3.5 rounded-xl bg-black/40 border border-purple-500/20 flex flex-col gap-1">
          <span className="text-[11px] font-mono text-purple-400/70">SESLİ TETİKLEYİCİ HAVUZU</span>
          <span className="font-orbitron text-xl font-bold text-purple-200">
            {apps.reduce((acc, a) => acc + a.voiceTriggers.length, 0)} Komut
          </span>
        </div>
        <div className="p-3.5 rounded-xl bg-black/40 border border-amber-500/20 flex flex-col gap-1">
          <span className="text-[11px] font-mono text-amber-400/70">HIZLI SIFIRLAMA</span>
          <button
            onClick={handleResetDefaults}
            className="text-left text-xs font-semibold text-amber-300 hover:text-amber-200 flex items-center gap-1 mt-0.5 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Varsayılanları Geri Yükle</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 bg-black/30 p-2 rounded-xl border border-white/10">
        <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                activeCategory === cat
                  ? 'bg-cyan-500/20 border border-cyan-400/50 text-cyan-200 font-bold'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-white/5 border border-transparent'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-64">
          <Search className="w-4 h-4 text-cyan-400/60 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Uygulama veya ses komutu ara..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-black/60 border border-cyan-500/30 text-xs text-cyan-200 placeholder-cyan-500/40 focus:outline-none focus:border-cyan-400"
          />
        </div>
      </div>

      {/* Controlled Apps Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {filteredApps.map((app) => (
          <div
            key={app.id}
            className={`p-4 rounded-xl border transition-all flex flex-col justify-between gap-3 ${
              app.status === 'Açık'
                ? 'bg-emerald-950/20 border-emerald-500/50 shadow-md shadow-emerald-500/10'
                : 'bg-black/40 border-white/10 hover:border-cyan-500/30'
            }`}
          >
            {/* Header: Icon, Name, Category, Status */}
            <div>
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 rounded-lg bg-black/60 border border-white/10">
                    {getCategoryIcon(app.category)}
                  </div>
                  <div>
                    <h3 className="font-orbitron text-sm font-bold text-white tracking-wide">
                      {app.name}
                    </h3>
                    <span className="text-[11px] text-gray-400 font-mono">
                      {app.category} • {app.launchType.toUpperCase()}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <span
                    className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono ${
                      app.status === 'Açık'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-gray-800 text-gray-400 border border-gray-700'
                    }`}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        app.status === 'Açık' ? 'bg-emerald-400 animate-ping' : 'bg-gray-500'
                      }`}
                    />
                    {app.status}
                  </span>
                  {!app.isDefault && (
                    <button
                      onClick={() => handleDeleteApp(app.id, app.name)}
                      className="p-1 rounded text-gray-500 hover:text-red-400 transition-colors cursor-pointer"
                      title="Uygulamayı Kaldır"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Voice Trigger Badges */}
              <div className="mt-3 flex flex-col gap-1 text-[11px] font-mono">
                <div className="flex items-center gap-1 text-cyan-400/80">
                  <Mic className="w-3 h-3 text-cyan-400" />
                  <span>Ses Komutları:</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {app.voiceTriggers.slice(0, 3).map((trigger, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 text-[10px]"
                    >
                      "{trigger}"
                    </span>
                  ))}
                  {app.voiceTriggers.length > 3 && (
                    <span className="text-[10px] text-gray-500 self-center">
                      +{app.voiceTriggers.length - 3} komut
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Actions: Open / Close Buttons */}
            <div className="pt-2 border-t border-white/10 flex items-center gap-2">
              <button
                onClick={() => onLaunchApp(app)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  app.status === 'Açık'
                    ? 'bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-200'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20'
                }`}
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{app.status === 'Açık' ? 'YENİDEN AÇ / ODAKLAN' : 'AÇ (BAŞLAT)'}</span>
              </button>

              <button
                onClick={() => onCloseApp(app)}
                disabled={app.status === 'Kapalı'}
                className="flex items-center justify-center gap-1 py-2 px-3 rounded-lg bg-red-950/40 hover:bg-red-900/60 border border-red-500/30 text-red-300 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-semibold transition-all cursor-pointer"
                title="Kapatma protokolünü çalıştır"
              >
                <Square className="w-3 h-3 fill-current" />
                <span>KAPAT</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredApps.length === 0 && (
        <div className="p-8 rounded-xl bg-black/40 border border-white/10 text-center flex flex-col items-center justify-center gap-2">
          <Gamepad2 className="w-10 h-10 text-gray-600" />
          <p className="text-sm text-gray-300 font-medium">Bu kategoride uygulama bulunamadı.</p>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="mt-2 text-xs text-cyan-400 underline cursor-pointer"
          >
            Hemen yeni bir uygulama veya oyun ekleyin
          </button>
        </div>
      )}

      {/* Modal: Add New Application / Game */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fadeIn">
          <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-cyan-500/40 shadow-2xl p-6 flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                <h3 className="font-orbitron font-bold text-sm text-cyan-100 tracking-wider">
                  YENİ UYGULAMA / OYUN EKLE
                </h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-lg text-gray-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddNewApp} className="flex flex-col gap-3.5">
              <div>
                <label className="text-[11px] font-mono text-cyan-300 block mb-1">
                  Uygulama veya Oyun Adı *
                </label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="Örn: Roblox, Minecraft, Netflix, WhatsApp, Elden Ring"
                  className="w-full px-3 py-2 rounded-lg bg-black/60 border border-cyan-500/40 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-mono text-cyan-300 block mb-1">
                    Kategori
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg bg-black/60 border border-cyan-500/40 text-xs text-white focus:outline-none focus:border-cyan-400 cursor-pointer"
                  >
                    <option value="Oyun">Oyun</option>
                    <option value="Müzik & Medya">Müzik & Medya</option>
                    <option value="İletişim & Sosyal">İletişim & Sosyal</option>
                    <option value="Araç & Tarayıcı">Araç & Tarayıcı</option>
                    <option value="Sistem & Geliştirici">Sistem & Geliştirici</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-mono text-cyan-300 block mb-1">
                    Başlatma Türü
                  </label>
                  <select
                    value={newLaunchType}
                    onChange={(e) => setNewLaunchType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg bg-black/60 border border-cyan-500/40 text-xs text-white focus:outline-none focus:border-cyan-400 cursor-pointer"
                  >
                    <option value="protocol">Özel Protokol (steam://, spotify: vb.)</option>
                    <option value="web">Web Sitesi / URL (https://...)</option>
                    <option value="custom">Yerel Sistem Komutu (.exe vb.)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-mono text-cyan-300 block mb-1">
                  Başlatma Hedefi / URL veya Protokol
                </label>
                <input
                  type="text"
                  value={newLaunchTarget}
                  onChange={(e) => setNewLaunchTarget(e.target.value)}
                  placeholder={
                    newLaunchType === 'web'
                      ? 'https://web.whatsapp.com veya https://netflix.com'
                      : newLaunchType === 'protocol'
                      ? 'steam://run/12345 veya spotify: veya discord:'
                      : 'calc.exe veya notepad.exe'
                  }
                  className="w-full px-3 py-2 rounded-lg bg-black/60 border border-cyan-500/40 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400 font-mono text-xs"
                />
              </div>

              <div>
                <label className="text-[11px] font-mono text-cyan-300 block mb-1">
                  Sesli Açma Komutları (Virgülle ayırın)
                </label>
                <input
                  type="text"
                  value={newTriggers}
                  onChange={(e) => setNewTriggers(e.target.value)}
                  placeholder="Örn: roblox aç, oyuna gir, roblox başlat"
                  className="w-full px-3 py-2 rounded-lg bg-black/60 border border-cyan-500/40 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400"
                />
                <p className="text-[10px] text-cyan-400/60 mt-1">
                  Mikrofona bu ifadelerden birini söylediğinizde J.A.R.V.I.S. uygulamayı anında açacaktır.
                </p>
              </div>

              <div>
                <label className="text-[11px] font-mono text-cyan-300 block mb-1">
                  Sesli Kapatma Komutları (Virgülle ayırın)
                </label>
                <input
                  type="text"
                  value={newCloseTriggers}
                  onChange={(e) => setNewCloseTriggers(e.target.value)}
                  placeholder="Örn: roblox kapat, oyundan çık"
                  className="w-full px-3 py-2 rounded-lg bg-black/60 border border-cyan-500/40 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-gray-300 hover:text-white cursor-pointer"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs shadow-lg shadow-emerald-500/20 cursor-pointer"
                >
                  KAYDET VE KONTROLE EKLE
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
