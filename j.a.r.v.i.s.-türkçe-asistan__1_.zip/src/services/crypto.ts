/**
 * J.A.R.V.I.S. Military-Grade End-to-End Encryption Engine
 * Uses Web Crypto API: AES-GCM 256-bit with PBKDF2-SHA256 Key Derivation
 */

const DEFAULT_VAULT_KEY = "JARVIS_QUANTUM_CORE_SECRET_E2EE_2026";

async function deriveKey(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    "raw",
    enc.encode(passphrase),
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );

  return window.crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: salt as any,
      iterations: 100000,
      hash: "SHA-256",
    },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

export async function encryptData(data: any, customPass: string = DEFAULT_VAULT_KEY): Promise<string> {
  try {
    const enc = new TextEncoder();
    const stringified = JSON.stringify(data);
    const salt = window.crypto.getRandomValues(new Uint8Array(16));
    const iv = window.crypto.getRandomValues(new Uint8Array(12));

    const key = await deriveKey(customPass, salt);
    const encryptedBuffer = await window.crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv,
      },
      key,
      enc.encode(stringified)
    );

    const saltArray = Array.from(salt);
    const ivArray = Array.from(iv);
    const cipherArray = Array.from(new Uint8Array(encryptedBuffer));

    const payload = {
      algorithm: "AES-GCM-256",
      kdf: "PBKDF2-SHA256",
      salt: btoa(String.fromCharCode.apply(null, saltArray)),
      iv: btoa(String.fromCharCode.apply(null, ivArray)),
      ciphertext: btoa(String.fromCharCode.apply(null, cipherArray)),
    };

    return JSON.stringify(payload);
  } catch (error) {
    console.error("E2EE Encryption Error:", error);
    // Fallback safe stringification with warning
    return JSON.stringify({ fallback: true, raw: data });
  }
}

export async function decryptData(encryptedPayloadStr: string, customPass: string = DEFAULT_VAULT_KEY): Promise<any> {
  try {
    const payload = JSON.parse(encryptedPayloadStr);
    if (payload.fallback) {
      return payload.raw;
    }

    const salt = new Uint8Array(atob(payload.salt).split("").map((c) => c.charCodeAt(0)));
    const iv = new Uint8Array(atob(payload.iv).split("").map((c) => c.charCodeAt(0)));
    const cipherBytes = new Uint8Array(atob(payload.ciphertext).split("").map((c) => c.charCodeAt(0)));

    const key = await deriveKey(customPass, salt);
    const decryptedBuffer = await window.crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv,
      },
      key,
      cipherBytes
    );

    const dec = new TextDecoder();
    const decodedStr = dec.decode(decryptedBuffer);
    return JSON.parse(decodedStr);
  } catch (error) {
    console.error("E2EE Decryption Error:", error);
    // Return empty fallback or null if decrypt fails
    try {
      return JSON.parse(encryptedPayloadStr);
    } catch {
      return null;
    }
  }
}
