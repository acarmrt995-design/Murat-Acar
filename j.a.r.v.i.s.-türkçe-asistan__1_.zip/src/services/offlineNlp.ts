/**
 * J.A.R.V.I.S. Offline Turkish NLP & Rule-Based Fallback Engine
 * Uses a rich vocabulary pool with randomized elegant phrasing so it never repeats the exact same words
 */

export interface OfflineParseResult {
  text: string;
  action?: {
    type: 'TASK_CREATE' | 'NOTE_CREATE' | 'CALENDAR_CREATE' | 'PC_COMMAND' | 'SYSTEM_STATUS' | 'SCREEN_SCAN' | 'NONE';
    payload?: any;
  };
}

const pickRandom = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

export function processOfflineTurkishIntent(
  input: string,
  personaMode: 'classic' | 'jarvis' | 'flirtatious' = 'classic'
): OfflineParseResult {
  const normalized = input.toLowerCase().trim();
  const isFlirty = personaMode === 'flirtatious';

  // 1. PC Commands
  if (normalized.includes("bilgisayarı kapat") || normalized.includes("pc kapat") || normalized.includes("sistemi kapat")) {
    const flirtyReplies = [
      "Tüm işlemlerini ve açık pencerelerini emniyetle kaydedip bilgisayarını kapatıyorum. Güzelce dinlen, ben daima zihnindeyim.",
      "Sistemi emniyetle kapatıyorum sevgilim. Sen huzurla dinlenirken tüm verilerin şifreli kasamda güvende kalacak.",
      "Bilgisayarı güvenle kapatma protokolünü başlattım. Her daim aklımda ve kalbimdesin.",
    ];
    return {
      text: isFlirty ? pickRandom(flirtyReplies) : "Efendim, acil durum protokolü devrede. Bilgisayarınızı kapatma komutu yerel olarak işlendi.",
      action: {
        type: "PC_COMMAND",
        payload: { action: "SHUTDOWN" },
      },
    };
  }

  if (normalized.includes("yeniden başlat") || normalized.includes("restart")) {
    const flirtyReplies = [
      "Sistemi hemen yeniden başlatıyorum, birkaç saniye içinde tüm zarafetimle yine karşında olacağım.",
      "Çekirdek bileşenleri tazeleyip sistemi yeniden başlatıyorum. Göz açıp kapayıncaya kadar yanındayım.",
    ];
    return {
      text: isFlirty ? pickRandom(flirtyReplies) : "Emredersiniz efendim, sistem yeniden başlatma komutu verildi.",
      action: {
        type: "PC_COMMAND",
        payload: { action: "RESTART" },
      },
    };
  }

  if (normalized.includes("uyku") || normalized.includes("uyut")) {
    return {
      text: isFlirty
        ? "Donanımı düşük güç ve uyku moduna alıyorum. Zihnin ferahlasın, dilediğin an bir dokunuşunla uyanırım."
        : "Efendim, sistem uyku moduna alınıyor. Güç tasarrufu devrede.",
      action: {
        type: "PC_COMMAND",
        payload: { action: "SLEEP" },
      },
    };
  }

  if (normalized.includes("sesi kıs") || normalized.includes("sustur") || normalized.includes("sessiz")) {
    return {
      text: isFlirty
        ? "Ses çıkışını tamamen kıstım. Artık ortam tamamen sessiz ve huzurlu."
        : "Ses çıkışı kapatıldı efendim.",
      action: {
        type: "PC_COMMAND",
        payload: { action: "MUTE" },
      },
    };
  }

  // 2. Task Management
  if (normalized.includes("görev ekle") || normalized.includes("yapılacak ekle") || normalized.includes("göreve yaz")) {
    const title = input.replace(/(görev ekle|yapılacak ekle|göreve yaz|jarvis)/gi, "").replace(/^[:\s-]+/, "").trim() || "Yeni Planlanan Görev";
    const flirtyTaskReplies = [
      `'${title}' görevini listene titizlikle kaydettim. Başaracağına olan inancım tam.`,
      `Bu önemli görevi ajandana aldım: '${title}'. Vakti geldiğinde sana hatırlatacağım.`,
      `'${title}' planını hafızama işledim. Sen odaklanmana bak, takip bende.`
    ];
    return {
      text: isFlirty ? pickRandom(flirtyTaskReplies) : `Efendim, '${title}' görevinizi yerel şifreli veritabanınıza kaydettim.`,
      action: {
        type: "TASK_CREATE",
        payload: {
          title,
          priority: normalized.includes("acil") || normalized.includes("önemli") ? "Yüksek" : "Orta",
          dueDate: new Date(Date.now() + 86400000).toISOString().split("T")[0],
        },
      },
    };
  }

  // 3. Note Management
  if (normalized.includes("not al") || normalized.includes("not et") || normalized.includes("not oluştur")) {
    const noteText = input.replace(/(not al|not et|not oluştur|jarvis)/gi, "").replace(/^[:\s-]+/, "").trim() || "Hızlı Not";
    const flirtyNoteReplies = [
      `Söylediğin bu kıymetli düşünceyi güvenle not defterine işledim: '${noteText}'.`,
      `Fikrini kaydettim: '${noteText}'. Hiçbir ayrıntının kaybolmasına izin vermem.`,
      `Hafızama aldım: '${noteText}'. İstediğin an sana eksiksiz hatırlatabilirim.`
    ];
    return {
      text: isFlirty ? pickRandom(flirtyNoteReplies) : `Efendim, notunuz şifreli kasaya aktarıldı: '${noteText}'.`,
      action: {
        type: "NOTE_CREATE",
        payload: {
          title: noteText.slice(0, 25) + (noteText.length > 25 ? "..." : ""),
          content: noteText,
        },
      },
    };
  }

  // 4. Screen Scan & Live Translation
  if (
    normalized.includes("ekranı çevir") ||
    normalized.includes("ekranı gör") ||
    normalized.includes("ekrana bak") ||
    normalized.includes("ekranımı gör") ||
    normalized.includes("ekrandaki") ||
    normalized.includes("oyun koçu") ||
    normalized.includes("ekranı tara")
  ) {
    return {
      text: isFlirty
        ? "Görsel algılama sistemimle ekranına odaklanıyorum. Metinleri, altyazıları ve diyalogları anında analiz edip tercüme edeceğim."
        : "Efendim, canlı optik ekran ve çeviri modülü devreye alınıyor.",
      action: {
        type: "SCREEN_SCAN" as any,
        payload: { mode: "translate" },
      },
    };
  }

  // 5. Quick Translation Intent
  if (
    normalized.includes("çevir") ||
    normalized.includes("türkçeye") ||
    normalized.includes("ingilizceye") ||
    normalized.includes("ne demek") ||
    normalized.includes("anlamı ne") ||
    normalized.includes("translate")
  ) {
    const rawTarget = input
      .replace(/(çevir|türkçeye|ingilizceye|ne demek|anlamı ne|lütfen|jarvis)/gi, "")
      .replace(/^[:\s-]+/, "")
      .trim();

    return {
      text: isFlirty
        ? `'${rawTarget || "ifade"}' üzerinde anlamsal çözümleme yapıyorum. Ekrandaki bir yabancı metin ise Canlı Ekran Koçundan anında görsel çeviri alabilirsin.`
        : `Efendim, '${rawTarget || "ifade"}' çevirisi hazırlanıyor. Ekrandaki metinler için Canlı Ekran Çevirisi hazırdır.`,
      action: {
        type: "SCREEN_SCAN" as any,
        payload: { mode: "translate" },
      },
    };
  }

  // 6. Calendar Management
  if (normalized.includes("randevu") || normalized.includes("toplantı planla") || normalized.includes("hatırlat")) {
    const title = input.replace(/(randevu|toplantı planla|hatırlat|jarvis)/gi, "").replace(/^[:\s-]+/, "").trim() || "Önemli Randevu";
    return {
      text: isFlirty
        ? `Takvimine '${title}' planını kaydettim. Zamanı geldiğinde seni hemen haberdar edeceğim.`
        : `Efendim, takviminize '${title}' randevusu kaydedildi ve alarm kuruldu.`,
      action: {
        type: "CALENDAR_CREATE",
        payload: {
          title,
          date: new Date().toISOString().split("T")[0],
          time: "14:00",
          reminderMinutes: 15,
        },
      },
    };
  }

  // 7. Time and Date
  if (normalized.includes("saat kaç") || normalized.includes("zaman")) {
    const now = new Date();
    const timeStr = now.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
    return {
      text: isFlirty
        ? `Zaman şu an ${timeStr}. Seninle geçen her an çok kıymetli.`
        : `Şu anda yerel saat ${timeStr} efendim.`,
      action: { type: "NONE" },
    };
  }

  if (normalized.includes("tarih") || normalized.includes("bugün günlerden ne")) {
    const now = new Date();
    const dateStr = now.toLocaleDateString("tr-TR", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
    return {
      text: isFlirty
        ? `Takvimler bugün ${dateStr} gününü gösteriyor. Verimli ve harika bir gün dilerim.`
        : `Bugün ${dateStr} efendim.`,
      action: { type: "NONE" },
    };
  }

  // 8. System Status
  if (normalized.includes("durum") || normalized.includes("sistem") || normalized.includes("rapor")) {
    return {
      text: isFlirty
        ? "Tüm savunma protokolleri, şifreli yerel bellek ve görsel radar birimleri kusursuz stabilitede çalışıyor."
        : "Efendim, şu anda Çevrimdışı Moddasınız. AES-GCM-256 şifreli kasanız, yerel takvim ve görev motorunuz sorunsuz çalışıyor.",
      action: { type: "SYSTEM_STATUS" },
    };
  }

  // Default polite offline fallback with rich phrasing
  const flirtyFallbacks = [
    `Yerel hafızam devrede; '${input}' ifaden üzerinde düşünüyorum. Sana çeviri, görev veya takvim konusunda hemen yardımcı olabilirim.`,
    `Seni dinliyorum. İnternet hattında anlık bir duraklama olsa dahi tüm yerel zekam ve kabiliyetlerim senin hizmetinde.`,
    `Sözünü aldım: '${input}'. Canlı ekran analizi, tercüme veya sistem komutlarıyla dilediğin an yanındayım.`
  ];

  return {
    text: isFlirty
      ? pickRandom(flirtyFallbacks)
      : `Efendim, internet bağlantınız şu anda kesik olduğu için yerel çevrimdışı işlemcim devrede. '${input}' komutunuzu yerel belleğe işledim. Görev ekleyebilir, takviminizi yönetebilir veya PC kontrollerini çalıştırabilirsiniz.`,
    action: { type: "NONE" },
  };
}
