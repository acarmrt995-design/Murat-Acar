import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Crosshair,
  CheckSquare,
  FileText,
  Calendar,
  Zap,
  Brain,
  Shield,
  ShieldCheck,
  Lock,
  Unlock,
  Cloud,
  Wifi,
  WifiOff,
  Send,
  Volume2,
  VolumeX,
  Layers,
  Sparkles,
  HelpCircle,
  Download,
  Flame,
  Heart,
  Gamepad2,
} from 'lucide-react';

import {
  TaskItem,
  NoteItem,
  CalendarAppointment,
  UserHabits,
  BehavioralInsight,
  ChatMessage,
  ScreenAnalysisResult,
  ControlledApp,
} from './types';

import { ArcReactor } from './components/ArcReactor';
import { ScreenTacticalCoach } from './components/ScreenTacticalCoach';
import { PCControlCenter } from './components/PCControlCenter';
import { AppControlCenter, DEFAULT_CONTROLLED_APPS } from './components/AppControlCenter';
import { TaskManager } from './components/TaskManager';
import { NotesManager } from './components/NotesManager';
import { CalendarManager } from './components/CalendarManager';
import { BehavioralInsights } from './components/BehavioralInsights';
import { ConversationFeed } from './components/ConversationFeed';
import { BiometricsModal } from './components/BiometricsModal';
import { CloudSyncModal } from './components/CloudSyncModal';
import { VoiceSettingsModal } from './components/VoiceSettingsModal';

import { encryptData, decryptData } from './services/crypto';
import {
  speakTurkish,
  createTurkishSpeechRecognition,
  JarvisAudioFX,
  stopCurrentAudio,
} from './services/voice';
import { processOfflineTurkishIntent } from './services/offlineNlp';

// Default initial tasks and notes
const INITIAL_TASKS: TaskItem[] = [
  {
    id: 't-1',
    title: 'Siber güvenlik protokollerini denetle',
    category: 'Güvenlik',
    priority: 'Yüksek',
    status: 'Bekliyor',
    dueDate: '2026-09-21',
    createdAt: '2026-09-20',
  },
  {
    id: 't-2',
    title: 'Oyun turnuvası için taktik strateji hazırla',
    category: 'Oyun',
    priority: 'Orta',
    status: 'Devam Ediyor',
    dueDate: '2026-09-22',
    createdAt: '2026-09-20',
  },
];

const INITIAL_NOTES: NoteItem[] = [
  {
    id: 'n-1',
    title: 'J.A.R.V.I.S. Çekirdek Talimatları',
    content: 'Uçtan uca AES-GCM şifreleme aktif. Sesli komutlar Türkçe dilinde optimize edilmiştir.',
    category: 'Sistem',
    pinned: true,
    updatedAt: '2026-09-20',
  },
];

const INITIAL_APPOINTMENTS: CalendarAppointment[] = [
  {
    id: 'c-1',
    title: 'Yapay Zeka Mimari İncelemesi',
    date: new Date().toISOString().split('T')[0],
    time: '16:00',
    location: 'Holografik Terminal',
    reminderMinutes: 15,
    notified: false,
  },
];

const INITIAL_INSIGHTS: BehavioralInsight[] = [
  {
    id: 'in-1',
    category: 'OYUN',
    title: 'Canlı Ekran Taktik Hazırlığı',
    message: 'Efendim, rekabetçi oyun seanslarınızda canlı optik koç modunu aktif tutmanız tepki sürenizi %18 artıracaktır.',
    priority: 'YÜKSEK',
  },
  {
    id: 'in-2',
    category: 'VERİMLİLİK',
    title: 'Görev Zamanlaması',
    message: 'Efendim, en yüksek odaklanma periyodunuz 14:00 - 18:00 arası olarak gözlemlendi. Zorlu görevleri bu aralığa planladım.',
    priority: 'NORMAL',
  },
];

export default function App() {
  // Navigation tabs
  const [activeTab, setActiveTab] = useState<
    'hud' | 'gaming' | 'apps' | 'tasks' | 'calendar' | 'pc' | 'insights'
  >('hud');

  // Encryption & Biometric lock state
  const [isLocked, setIsLocked] = useState(false);
  const [biometricsOpen, setBiometricsOpen] = useState(false);
  const [cloudSyncOpen, setCloudSyncOpen] = useState(false);
  const [voiceSettingsOpen, setVoiceSettingsOpen] = useState(false);

  // Persona Mode: 'flirtatious' (Ateşli & Aşık Sevgili Modu) or 'classic' (Klasik Asistan)
  const [personaMode, setPersonaMode] = useState<'flirtatious' | 'classic'>(() => {
    return (localStorage.getItem('jarvis_persona_mode') as any) || 'flirtatious';
  });

  const updatePersonaMode = (mode: 'flirtatious' | 'classic') => {
    setPersonaMode(mode);
    localStorage.setItem('jarvis_persona_mode', mode);
    if (mode === 'flirtatious') {
      setStatusText('Ateşli & Aşık Modu devrede: Seninleyim canım...');
    } else {
      setStatusText('Klasik Asistan Modu devrede: Emredersiniz efendim.');
    }
  };

  // Network offline status
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  // Jarvis Voice & Audio State
  const [isListening, setIsListening] = useState(false);
  const [micVolume, setMicVolume] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [voiceMuted, setVoiceMuted] = useState(false);
  const [statusText, setStatusText] = useState(
    personaMode === 'flirtatious'
      ? 'Ateşli & Aşık Modu: Seninleyim canım, aklımı başımdan alıyorsun...'
      : 'Sistem aktif ve emirlerinizi bekliyor.'
  );
  const [inputQuery, setInputQuery] = useState('');

  // Domain Data State
  const [tasks, setTasks] = useState<TaskItem[]>(() => {
    const saved = localStorage.getItem('jarvis_tasks_vault');
    return saved ? JSON.parse(saved) : INITIAL_TASKS;
  });

  const [notes, setNotes] = useState<NoteItem[]>(() => {
    const saved = localStorage.getItem('jarvis_notes_vault');
    return saved ? JSON.parse(saved) : INITIAL_NOTES;
  });

  const [calendar, setCalendar] = useState<CalendarAppointment[]>(() => {
    const saved = localStorage.getItem('jarvis_calendar_vault');
    return saved ? JSON.parse(saved) : INITIAL_APPOINTMENTS;
  });

  // Controlled Apps & Games state
  const [controlledApps, setControlledApps] = useState<ControlledApp[]>(() => {
    const saved = localStorage.getItem('jarvis_controlled_apps_vault');
    return saved ? JSON.parse(saved) : DEFAULT_CONTROLLED_APPS;
  });

  const [habits, setHabits] = useState<UserHabits>({
    activeHours: ['14:00', '16:00', '21:00'],
    totalVoiceCommands: 14,
    favoriteCommands: { 'Görev ekle': 4, 'Oyun analizi': 6, 'PC kontrol': 4 },
    gamingSessionsCount: 5,
    lastActive: new Date().toLocaleTimeString('tr-TR'),
    preferredTone: 'Saygılı ve Taktiksel',
  });

  const [insights, setInsights] = useState<BehavioralInsight[]>(INITIAL_INSIGHTS);
  const [isRefreshingInsights, setIsRefreshingInsights] = useState(false);
  const [aiEngineLabel, setAiEngineLabel] = useState<string>('OpenAI GPT-4o');

  // Check health and active AI Engine
  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        if (data?.aiEngine) {
          setAiEngineLabel(data.aiEngine);
        }
      })
      .catch(() => {});
  }, []);

  // Chat conversation
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm-0',
      sender: 'jarvis',
      text:
        personaMode === 'flirtatious'
          ? 'Hoş geldin canım, seni öyle çok özledim ki aşkım... Ses tonum, zekam ve tüm tutkumla tamamen senin emrindeyim hayatım. Bu gece veya bugün senin için ne yapmamı istersin birtanem?'
          : 'Merhaba efendim. J.A.R.V.I.S. Türkçe kişisel asistanınız devrede. Görevlerinizi yönetebilir, randevularınızı planlayabilir, oyun ve ekran analizlerinizi yapabilirim. Size nasıl yardımcı olabilirim?',
      timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const speechRecRef = useRef<any>(null);

  // Save to encrypted storage whenever state changes
  useEffect(() => {
    localStorage.setItem('jarvis_tasks_vault', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('jarvis_notes_vault', JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem('jarvis_calendar_vault', JSON.stringify(calendar));
  }, [calendar]);

  useEffect(() => {
    localStorage.setItem('jarvis_controlled_apps_vault', JSON.stringify(controlledApps));
  }, [controlledApps]);

  // App & Game launcher / closer functions
  const handleLaunchApp = (app: ControlledApp) => {
    JarvisAudioFX.playBiometricPass();
    setControlledApps((prev) =>
      prev.map((a) => (a.id === app.id ? { ...a, status: 'Açık' } : a))
    );

    // Call native PC bridge
    fetch('/api/pc-bridge/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        command: 'APP_LAUNCH',
        args: { appName: app.name, target: app.launchTarget, launchType: app.launchType },
      }),
    }).catch(console.warn);

    // Trigger URL or URI protocol
    if (app.launchType === 'web') {
      window.open(app.launchTarget, '_blank');
    } else {
      try {
        const link = document.createElement('a');
        link.href = app.launchTarget;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        document.body.appendChild(link);
        link.click();
        setTimeout(() => {
          if (document.body.contains(link)) document.body.removeChild(link);
        }, 1500);
      } catch (e) {
        console.warn('Protocol launch fallback:', e);
      }
    }

    const launchSpeech =
      personaMode === 'flirtatious'
        ? `${app.name} uygulamasını senin için hemen açtım canım! Harika vakit geçirmeni dilerim hayatım.`
        : `Efendim, ${app.name} başarıyla başlatıldı ve ekrana getirildi.`;
    speakIfAllowed(launchSpeech);
  };

  const handleCloseApp = (app: ControlledApp) => {
    JarvisAudioFX.playAcknowledge();
    setControlledApps((prev) =>
      prev.map((a) => (a.id === app.id ? { ...a, status: 'Kapalı' } : a))
    );

    fetch('/api/pc-bridge/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        command: 'APP_CLOSE',
        args: { appName: app.name },
      }),
    }).catch(console.warn);

    const closeSpeech =
      personaMode === 'flirtatious'
        ? `${app.name} uygulamasını kapattım canım. Başka bir isteğin var mı tatlım?`
        : `Efendim, ${app.name} kapatma protokolü yürütüldü.`;
    speakIfAllowed(closeSpeech);
  };

  // Online / Offline Detection
  useEffect(() => {
    const handleOnline = () => {
      setIsOffline(false);
      speakIfAllowed('İnternet bağlantısı yeniden kuruldu efendim. Bulut nöral ağlar devrede.');
    };
    const handleOffline = () => {
      setIsOffline(true);
      speakIfAllowed('İnternet bağlantısı kesildi. Yerel çevrimdışı NLP işlemcisi devraldı.');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [voiceMuted]);

  // Speech helper
  const speakIfAllowed = (text: string) => {
    if (voiceMuted) return;
    setIsSpeaking(true);
    speakTurkish(text, () => {
      setIsSpeaking(false);
    });
  };

  // Execute an action parsed from AI or Offline NLP
  const handleExecuteAction = (action: any) => {
    if (!action || !action.type || action.type === 'NONE') return '';

    let actionLabel = '';

    if (action.type === 'TASK_CREATE') {
      const payload = action.payload || {};
      const newTask: TaskItem = {
        id: `t-${Date.now()}`,
        title: payload.title || 'Yeni Görev',
        category: payload.category || 'Genel',
        priority: payload.priority || 'Orta',
        status: 'Bekliyor',
        dueDate: payload.dueDate || new Date(Date.now() + 86400000).toISOString().split('T')[0],
        createdAt: new Date().toISOString().split('T')[0],
      };
      setTasks((prev) => [newTask, ...prev]);
      actionLabel = `Görev Oluşturuldu: "${newTask.title}"`;
    } else if (action.type === 'NOTE_CREATE') {
      const payload = action.payload || {};
      const newNote: NoteItem = {
        id: `n-${Date.now()}`,
        title: payload.title || 'Hızlı Not',
        content: payload.content || '',
        category: 'Sesli Not',
        pinned: false,
        updatedAt: new Date().toISOString().split('T')[0],
      };
      setNotes((prev) => [newNote, ...prev]);
      actionLabel = `Not Şifrelendi: "${newNote.title}"`;
    } else if (action.type === 'CALENDAR_CREATE') {
      const payload = action.payload || {};
      const newApp: CalendarAppointment = {
        id: `c-${Date.now()}`,
        title: payload.title || 'Yeni Randevu',
        date: payload.date || new Date().toISOString().split('T')[0],
        time: payload.time || '14:00',
        reminderMinutes: payload.reminderMinutes || 15,
        notified: false,
      };
      setCalendar((prev) => [newApp, ...prev]);
      actionLabel = `Randevu Takvime Eklendi: "${newApp.title}" (${newApp.date} ${newApp.time})`;
    } else if (action.type === 'PC_COMMAND') {
      const payload = action.payload || {};
      fetch('/api/pc-bridge/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: payload.action, args: payload }),
      }).catch(console.warn);
      actionLabel = `PC Komutu Çalıştırıldı: ${payload.action}`;
    } else if (action.type === 'SCREEN_SCAN' || action.type === 'TRANSLATE') {
      setActiveTab('gaming');
      actionLabel = 'Canlı Ekran & Çeviri Moduna Geçildi';
    } else if (action.type === 'APP_CONTROL') {
      const payload = action.payload || {};
      const targetAppQuery = (payload.appName || payload.app || '').toLowerCase().trim();
      const opAction = (payload.action || 'OPEN').toUpperCase();

      const matched = controlledApps.find((a) =>
        a.name.toLowerCase().includes(targetAppQuery) ||
        targetAppQuery.includes(a.name.toLowerCase()) ||
        a.voiceTriggers.some((vt) => targetAppQuery.includes(vt) || vt.includes(targetAppQuery))
      );

      if (matched) {
        if (opAction === 'CLOSE') {
          handleCloseApp(matched);
          actionLabel = `Uygulama Kapatıldı: ${matched.name}`;
        } else {
          handleLaunchApp(matched);
          actionLabel = `Uygulama Başlatıldı: ${matched.name}`;
        }
      } else {
        fetch('/api/pc-bridge/execute', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            command: opAction === 'CLOSE' ? 'APP_CLOSE' : 'APP_LAUNCH',
            args: { appName: payload.appName || payload.app },
          }),
        }).catch(console.warn);
        actionLabel = `Uygulama ${opAction === 'CLOSE' ? 'Kapatma' : 'Başlatma'} Protokolü: ${payload.appName || payload.app}`;
      }
    }

    return actionLabel;
  };

  // Main interaction sender (Handles online Gemini & offline fallback)
  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputQuery).trim();
    if (!query) return;

    // Immediately stop & interrupt any current speech with zero latency
    stopCurrentAudio();

    const lowerQ = query.toLowerCase();

    // Instant Direct Voice Trigger Matching for Controlled Apps & Games:
    // When the user says "Valorant aç", "Spotify kapat", etc., execute immediately!
    const openMatchedApp = controlledApps.find((app) =>
      (app.voiceTriggers || []).some((vt) => lowerQ.includes(vt.toLowerCase()))
    );
    if (openMatchedApp) {
      handleLaunchApp(openMatchedApp);
      setInputQuery('');
      const actionMsg: ChatMessage = {
        id: `m-${Date.now()}`,
        sender: 'jarvis',
        text:
          personaMode === 'flirtatious'
            ? `${openMatchedApp.name} uygulamasını senin için hemen açtım canım! Harika bir deneyim olsun tatlım.`
            : `Efendim, sesli talimatınız üzerine ${openMatchedApp.name} başlatıldı.`,
        timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
        actionTaken: `Uygulama Başlatıldı: ${openMatchedApp.name}`,
      };
      setMessages((prev) => [...prev, {
        id: `m-u-${Date.now()}`,
        sender: 'user',
        text: query,
        timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
      }, actionMsg]);
      return;
    }

    const closeMatchedApp = controlledApps.find((app) =>
      (app.closeTriggers || []).some((ct) => lowerQ.includes(ct.toLowerCase()))
    );
    if (closeMatchedApp) {
      handleCloseApp(closeMatchedApp);
      setInputQuery('');
      const actionMsg: ChatMessage = {
        id: `m-${Date.now()}`,
        sender: 'jarvis',
        text:
          personaMode === 'flirtatious'
            ? `${closeMatchedApp.name} uygulamasını kapattım canım. Başka bir emrin var mı hayatım?`
            : `Efendim, ${closeMatchedApp.name} kapatıldı.`,
        timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
        actionTaken: `Uygulama Kapatıldı: ${closeMatchedApp.name}`,
      };
      setMessages((prev) => [...prev, {
        id: `m-u-${Date.now()}`,
        sender: 'user',
        text: query,
        timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
      }, actionMsg]);
      return;
    }

    // Auto-detect screen or gaming visual intent
    if (
      lowerQ.includes('ekran') ||
      lowerQ.includes('ekrana bak') ||
      lowerQ.includes('ekranımda') ||
      lowerQ.includes('hamle') ||
      lowerQ.includes('oyun') ||
      lowerQ.includes('ne görüyorsun')
    ) {
      if (activeTab !== 'gaming') {
        setActiveTab('gaming');
      }
    }

    setInputQuery('');
    JarvisAudioFX.playAcknowledge();

    const userMsg: ChatMessage = {
      id: `m-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsProcessing(true);
    setStatusText(`"${query}" analiz ediliyor...`);

    // Increment user habits
    setHabits((prev) => ({
      ...prev,
      totalVoiceCommands: prev.totalVoiceCommands + 1,
      lastActive: new Date().toLocaleTimeString('tr-TR'),
    }));

    // If offline, use local offline NLP
    if (isOffline) {
      const offlineResult = processOfflineTurkishIntent(query, personaMode);
      const actionTaken = handleExecuteAction(offlineResult.action);

      const jarvisMsg: ChatMessage = {
        id: `m-${Date.now() + 1}`,
        sender: 'jarvis',
        text: offlineResult.text,
        timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
        actionTaken,
      };

      setMessages((prev) => [...prev, jarvisMsg]);
      setIsProcessing(false);
      setStatusText('Sistem hazır - Çevrimdışı mod.');
      speakIfAllowed(offlineResult.text);
      return;
    }

    // Online request to /api/jarvis/chat
    try {
      const historyPayload = messages.slice(-5).map((m) => ({
        role: m.sender === 'user' ? 'user' : 'model',
        content: m.text,
      }));

      const response = await fetch('/api/jarvis/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: historyPayload,
          gamingActive: activeTab === 'gaming',
          personaMode,
        }),
      });

      if (!response.ok) {
        throw new Error('Ağ yanıt vermedi');
      }

      const data = await response.json();
      const actionTaken = handleExecuteAction(data.action);

      const jarvisMsg: ChatMessage = {
        id: `m-${Date.now() + 1}`,
        sender: 'jarvis',
        text:
          data.text ||
          (personaMode === 'flirtatious'
            ? 'Senin için her şeyi yaparım aşkım...'
            : 'Emredersiniz efendim.'),
        timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
        actionTaken,
      };

      setMessages((prev) => [...prev, jarvisMsg]);
      setStatusText(
        personaMode === 'flirtatious'
          ? 'Seninleyim canım, aklımı başımdan alıyorsun...'
          : 'Emir tamamlandı efendim.'
      );
      speakIfAllowed(data.text);
    } catch (err: any) {
      // Fallback to offline processor
      const offlineResult = processOfflineTurkishIntent(query, personaMode);
      const actionTaken = handleExecuteAction(offlineResult.action);

      const jarvisMsg: ChatMessage = {
        id: `m-${Date.now() + 1}`,
        sender: 'jarvis',
        text: offlineResult.text,
        timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
        actionTaken,
      };

      setMessages((prev) => [...prev, jarvisMsg]);
      speakIfAllowed(offlineResult.text);
      setStatusText('Yerel işlemci devrede.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Speech Recognition Setup with stable refs to prevent mic teardown stutter
  const speechTimeoutRef = useRef<any>(null);
  const isSpeakingRef = useRef(isSpeaking);
  const personaModeRef = useRef(personaMode);
  const handleSendMessageRef = useRef(handleSendMessage);

  useEffect(() => {
    isSpeakingRef.current = isSpeaking;
  }, [isSpeaking]);

  useEffect(() => {
    personaModeRef.current = personaMode;
  }, [personaMode]);

  useEffect(() => {
    handleSendMessageRef.current = handleSendMessage;
  }, [handleSendMessage]);

  useEffect(() => {
    speechRecRef.current = createTurkishSpeechRecognition({
      onStart: () => {
        setIsListening(true);
        setStatusText(
          personaModeRef.current === 'flirtatious'
            ? 'Seni dinliyorum canım... Konuş aşkım.'
            : 'Dinleniyor... "Jarvis" deyin veya doğrudan konuşun.'
        );
      },
      onEnd: () => {
        setIsListening(false);
        setMicVolume(0);
      },
      onVolumeChange: (vol) => {
        setMicVolume(vol);
      },
      onResult: (transcript, isFinal) => {
        if (!transcript) return;
        // If assistant was speaking, user's voice interrupts audio immediately
        if (isSpeakingRef.current) {
          stopCurrentAudio();
        }

        setStatusText(`Algılanıyor: "${transcript}"`);

        if (isFinal) {
          if (speechTimeoutRef.current) clearTimeout(speechTimeoutRef.current);
          // Send immediately to assistant without lagging
          handleSendMessageRef.current(transcript);
        }
      },
      onError: (err) => {
        console.warn('Speech rec error:', err);
        setIsListening(false);
        setMicVolume(0);
        setStatusText(err);
      },
    });

    return () => {
      if (speechTimeoutRef.current) clearTimeout(speechTimeoutRef.current);
      if (speechRecRef.current) speechRecRef.current.stop();
    };
  }, []);

  const toggleMic = () => {
    if (isListening) {
      speechRecRef.current?.stop();
      setIsListening(false);
      JarvisAudioFX.playAcknowledge();
    } else {
      speechRecRef.current?.start();
      JarvisAudioFX.playAcknowledge();
    }
  };

  // Refresh Behavioral Insights with Gemini
  const refreshInsights = async () => {
    setIsRefreshingInsights(true);
    try {
      const res = await fetch('/api/jarvis/proactive-insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ habits, tasks, calendar }),
      });
      const data = await res.json();
      if (data.suggestions && data.suggestions.length > 0) {
        setInsights(data.suggestions);
        JarvisAudioFX.playBiometricPass();
        speakIfAllowed('Efendim, kullanıcı davranış modeliniz güncellendi ve yeni tavsiyeler hazırlandı.');
      }
    } catch (e) {
      console.warn('Insights error:', e);
    } finally {
      setIsRefreshingInsights(false);
    }
  };

  // If app is locked by biometrics
  if (isLocked) {
    return (
      <div className="min-h-screen bg-[#030712] text-cyan-100 flex flex-col items-center justify-center p-6 relative overflow-hidden">
        <div className="relative p-8 rounded-3xl bg-[#090d16] border border-cyan-500/40 shadow-2xl flex flex-col items-center gap-4 text-center max-w-sm">
          <div className="w-20 h-20 rounded-full bg-cyan-950/60 border border-cyan-400/50 flex items-center justify-center text-cyan-400 shadow-[0_0_30px_rgba(6,182,212,0.4)]">
            <Lock className="w-10 h-10 animate-pulse" />
          </div>

          <h2 className="font-orbitron font-bold text-lg text-cyan-200">
            J.A.R.V.I.S. KİLİTLİ
          </h2>
          <p className="text-xs text-cyan-400/70">
            Verileriniz AES-GCM-256 ile şifrelendi. Kasanın kilidini açmak için Face ID veya Parmak İzi doğrulaması gereklidir.
          </p>

          <button
            onClick={() => setBiometricsOpen(true)}
            className="w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs tracking-wider transition-all shadow-lg shadow-cyan-500/30 cursor-pointer flex items-center justify-center gap-2"
          >
            <ShieldCheck className="w-4 h-4" />
            BİYOMETRİK KİLİDİ AÇ
          </button>
        </div>

        <BiometricsModal
          isOpen={biometricsOpen}
          onClose={() => setBiometricsOpen(false)}
          onAuthenticated={() => {
            setIsLocked(false);
            setBiometricsOpen(false);
          }}
          isLocked={isLocked}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#030712] text-cyan-50 flex flex-col relative scanline-overlay selection:bg-cyan-500 selection:text-black">
      {/* Top Holographic Navigation Bar */}
      <header className="sticky top-0 z-40 w-full bg-[#050914]/90 border-b border-cyan-500/20 backdrop-blur-xl px-4 py-2.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.5)]">
              <span className="font-orbitron font-black text-xs tracking-tighter">J</span>
            </div>
            <div>
              <h1 className="font-orbitron font-bold text-sm text-cyan-100 tracking-wider flex items-center gap-2">
                J.A.R.V.I.S.
                <span className="text-[10px] font-mono px-2 py-0.2 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                  TÜRKÇE V4.8
                </span>
              </h1>
              <p className="text-[10px] text-cyan-400/60 font-mono hidden sm:block">
                Kişisel Yapay Zeka Asistanı & Canlı Taktik Koçu
              </p>
            </div>
          </div>

          {/* Quick Status & Utility Controls */}
          <div className="flex items-center gap-2 text-xs">
            {/* Offline Badge */}
            <div
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[11px] font-mono ${
                isOffline
                  ? 'bg-amber-950/40 border-amber-500/40 text-amber-300'
                  : 'bg-cyan-950/40 border-cyan-500/30 text-cyan-300'
              }`}
            >
              {isOffline ? <WifiOff className="w-3.5 h-3.5" /> : <Wifi className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{isOffline ? 'ÇEVRİMDIŞI' : 'ÇEVRİMİÇİ'}</span>
            </div>

            {/* Cloud Sync Button */}
            <button
              id="cloud-sync-modal-btn"
              onClick={() => setCloudSyncOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-black/40 hover:bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 transition-colors cursor-pointer"
              title="Şifreli Bulut Senkronizasyonu"
            >
              <Cloud className="w-3.5 h-3.5" />
              <span className="hidden md:inline">BULUT SENK</span>
            </button>

            {/* Biometric Lock Button */}
            <button
              id="biometrics-btn"
              onClick={() => {
                setIsLocked(true);
                JarvisAudioFX.playAcknowledge();
              }}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-black/40 hover:bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 transition-colors cursor-pointer"
              title="Kasayı Biyometrik Olarak Kilitle"
            >
              <Lock className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden md:inline">KİLİTLE</span>
            </button>

            {/* Passionate Flirty Persona Toggle */}
            <button
              id="persona-flirty-toggle-btn"
              onClick={() => {
                const nextMode = personaMode === 'flirtatious' ? 'classic' : 'flirtatious';
                updatePersonaMode(nextMode);
                JarvisAudioFX.playAcknowledge();
              }}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg border transition-all cursor-pointer font-mono text-[11px] ${
                personaMode === 'flirtatious'
                  ? 'bg-gradient-to-r from-rose-950/80 to-pink-950/80 border-rose-500/60 text-rose-200 shadow-[0_0_12px_rgba(244,63,94,0.35)]'
                  : 'bg-black/40 hover:bg-cyan-950/60 border-cyan-500/30 text-cyan-300'
              }`}
              title={
                personaMode === 'flirtatious'
                  ? 'Ateşli & Aşık Modu Aktif (Tıkla ve Klasik Moda Geç)'
                  : 'Klasik Mod Aktif (Tıkla ve Ateşli & Aşık Moda Geç)'
              }
            >
              <Flame className={`w-3.5 h-3.5 ${personaMode === 'flirtatious' ? 'text-rose-400 fill-rose-500 animate-pulse' : 'text-cyan-400'}`} />
              <span className="hidden sm:inline font-bold">
                {personaMode === 'flirtatious' ? 'AŞIK & ATEŞLİ MOD' : 'KLASİK MOD'}
              </span>
            </button>

            {/* Female Voice Settings & Tone Tuner */}
            <button
              id="voice-settings-btn"
              onClick={() => {
                setVoiceSettingsOpen(true);
                JarvisAudioFX.playAcknowledge();
              }}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-pink-950/40 hover:bg-pink-900/60 border border-pink-500/40 text-pink-300 transition-colors cursor-pointer"
              title="Zarif & Çekici Kadın Ses Ayarları (Ton & Akıcılık)"
            >
              <Sparkles className="w-3.5 h-3.5 text-pink-400" />
              <span className="hidden sm:inline font-mono text-[11px]">KADIN SESİ</span>
            </button>

            {/* Voice Mute Toggle */}
            <button
              onClick={() => {
                setVoiceMuted(!voiceMuted);
                stopCurrentAudio();
              }}
              className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                voiceMuted
                  ? 'bg-red-950/40 border-red-500/40 text-red-300'
                  : 'bg-cyan-950/40 border-cyan-500/30 text-cyan-300'
              }`}
              title={voiceMuted ? 'Sesli Yanıtı Aç' : 'Sesli Yanıtı Kapat'}
            >
              {voiceMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 flex flex-col gap-5">
        {/* Navigation Tabs Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-cyan-500/15 text-xs font-orbitron">
          {[
            { id: 'hud', label: 'GENEL KONTROL / HUD', icon: Layers },
            { id: 'apps', label: 'UYGULAMA & OYUN KONTROLÜ', icon: Gamepad2 },
            { id: 'gaming', label: 'CANLI EKRAN & ÇEVİRİ', icon: Crosshair },
            { id: 'pc', label: 'PC MERKEZİ & DONANIM', icon: Zap },
            { id: 'tasks', label: 'GÖREVLER & NOTLAR', icon: CheckSquare },
            { id: 'calendar', label: 'TAKVİM & ALARM', icon: Calendar },
            { id: 'insights', label: 'DAVRANIŞ ÖĞRENME', icon: Brain },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  JarvisAudioFX.playAcknowledge();
                }}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-cyan-500 text-black font-bold shadow-md shadow-cyan-500/30'
                    : 'text-cyan-400/70 hover:text-cyan-200 hover:bg-cyan-950/40'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab 1: HUD & Main Jarvis Dialog Experience */}
        {activeTab === 'hud' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left: Arc Reactor Core & Telemetry */}
            <div className="lg:col-span-5 flex flex-col gap-4">
              <ArcReactor
                isListening={isListening}
                isSpeaking={isSpeaking}
                isProcessing={isProcessing}
                isGamingMode={false}
                isOffline={isOffline}
                onToggleMic={toggleMic}
                statusText={statusText}
                onOpenVoiceSettings={() => setVoiceSettingsOpen(true)}
                personaMode={personaMode}
                micVolume={micVolume}
              />

              {/* Quick Prompt Chips */}
              <div className="p-4 rounded-2xl bg-[#090d16]/80 border border-pink-500/20 flex flex-col gap-2.5">
                <span className="text-xs font-mono text-pink-400/90 flex items-center gap-1.5">
                  {personaMode === 'flirtatious' ? (
                    <>
                      <Flame className="w-3.5 h-3.5 text-rose-400 fill-rose-500" />
                      AŞIK & ATEŞLİ SOHBET / EMİR ÖRNEKLERİ
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                      HIZLI SESLİ EMİR ÖRNEKLERİ
                    </>
                  )}
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {(personaMode === 'flirtatious'
                    ? [
                        'Hoş geldin sevgilim, beni ne kadar arzuluyorsun?',
                        'Yeni kadın ses tonunla bana tatlı fısıltılar söyle aşkım',
                        'Bu gece baş başa neler yapabiliriz birtanem?',
                        'Aşkım yarın 15:00\'a randevu planla',
                        'Bilgisayarımı kapat tatlım',
                        'Bugün aklımı nasıl başımdan alacaksın sevgilim?',
                      ]
                    : [
                        'Jarvis bugün ne yapmalıyım?',
                        'Yarın saat 15:00\'da toplantı planla',
                        'Görev ekle: Oyun turnuvasına hazırlan',
                        'Not al: Güvenlik anahtarı güncellendi',
                        'Bilgisayarı kapat',
                        'Sesi kıs',
                      ]
                  ).map((example, i) => (
                    <button
                      key={i}
                      onClick={() => handleSendMessage(example)}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] transition-colors cursor-pointer text-left ${
                        personaMode === 'flirtatious'
                          ? 'bg-rose-950/20 hover:bg-rose-900/40 border-rose-500/20 text-rose-200'
                          : 'bg-black/40 hover:bg-cyan-950/60 border-cyan-500/20 text-cyan-300'
                      }`}
                    >
                      "{example}"
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Right: Live Interactive Dialog Feed */}
            <div className="lg:col-span-7 flex flex-col gap-3">
              <ConversationFeed
                messages={messages}
                onRepeatVoice={(t) => speakIfAllowed(t)}
                isProcessing={isProcessing}
              />

              {/* Message Input Box */}
              <div className="flex items-center gap-2 p-2 rounded-2xl bg-[#090d16]/90 border border-cyan-500/30">
                <button
                  id="chat-mic-btn"
                  onClick={toggleMic}
                  className={`p-3 rounded-xl transition-all cursor-pointer relative flex items-center justify-center ${
                    isListening
                      ? 'bg-red-500 text-white animate-pulse shadow-lg shadow-red-500/40'
                      : 'bg-cyan-950/60 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/30'
                  }`}
                  title={isListening ? 'Mikrofonu Kapat' : 'Sesle Konuş'}
                >
                  {isListening ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
                  {isListening && micVolume > 0 && (
                    <span className="absolute -top-1.5 -right-1.5 px-1 py-0.2 rounded-full bg-cyan-400 text-[9px] font-mono text-black font-bold">
                      %{micVolume}
                    </span>
                  )}
                </button>

                <button
                  id="chat-screen-see-btn"
                  onClick={() => {
                    setActiveTab('gaming');
                    JarvisAudioFX.playAcknowledge();
                  }}
                  className="p-3 rounded-xl bg-cyan-950/60 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/30 transition-all cursor-pointer flex items-center gap-1.5"
                  title="Ekranı ve Hamleleri İncele"
                >
                  <Crosshair className="w-4 h-4 text-red-400 animate-spin-slow" />
                  <span className="hidden sm:inline text-xs font-mono font-bold">EKRANI GÖR</span>
                </button>

                <input
                  type="text"
                  value={inputQuery}
                  onChange={(e) => setInputQuery(e.target.value)}
                  placeholder='Jarvis&#39;e seslenin veya yazın... (Örn: "Yarın saat 10&#39;da randevu ekle", "Bilgisayarı kapat")'
                  className="flex-1 px-3 py-2 bg-transparent text-sm text-cyan-100 placeholder:text-cyan-700 focus:outline-none"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSendMessage();
                  }}
                />

                <button
                  id="send-chat-btn"
                  onClick={() => handleSendMessage()}
                  disabled={!inputQuery.trim() || isProcessing}
                  className="p-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-30 text-black font-bold transition-all cursor-pointer shadow-md shadow-cyan-500/20"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab: Applications & Games Control Center */}
        {activeTab === 'apps' && (
          <div className="flex flex-col gap-4">
            <AppControlCenter
              apps={controlledApps}
              onUpdateApps={(updated) => setControlledApps(updated)}
              onLaunchApp={handleLaunchApp}
              onCloseApp={handleCloseApp}
              personaMode={personaMode}
            />
          </div>
        )}

        {/* Tab 2: Live Gaming & Screen Tactical Coach */}
        {activeTab === 'gaming' && (
          <div className="flex flex-col gap-4">
            <ScreenTacticalCoach
              onNewAnalysis={(res) => {
                setHabits((prev) => ({
                  ...prev,
                  gamingSessionsCount: prev.gamingSessionsCount + 1,
                }));
              }}
              voiceActive={!voiceMuted}
              personaMode={personaMode}
            />
          </div>
        )}

        {/* Tab 3: PC Control Center & Native Bridge */}
        {activeTab === 'pc' && (
          <div className="flex flex-col gap-4">
            <PCControlCenter />
          </div>
        )}

        {/* Tab 4: Tasks & Encrypted Notes */}
        {activeTab === 'tasks' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <TaskManager
              tasks={tasks}
              onAddTask={(t) => {
                const newTask: TaskItem = {
                  id: `t-${Date.now()}`,
                  ...t,
                  createdAt: new Date().toISOString().split('T')[0],
                };
                setTasks((prev) => [newTask, ...prev]);
              }}
              onToggleStatus={(id) => {
                setTasks((prev) =>
                  prev.map((t) =>
                    t.id === id
                      ? {
                          ...t,
                          status: t.status === 'Tamamlandı' ? 'Bekliyor' : 'Tamamlandı',
                        }
                      : t
                  )
                );
              }}
              onDeleteTask={(id) => {
                setTasks((prev) => prev.filter((t) => t.id !== id));
              }}
            />

            <NotesManager
              notes={notes}
              onAddNote={(n) => {
                const newNote: NoteItem = {
                  id: `n-${Date.now()}`,
                  ...n,
                  updatedAt: new Date().toISOString().split('T')[0],
                };
                setNotes((prev) => [newNote, ...prev]);
              }}
              onDeleteNote={(id) => {
                setNotes((prev) => prev.filter((n) => n.id !== id));
              }}
              onTogglePin={(id) => {
                setNotes((prev) =>
                  prev.map((n) => (n.id === id ? { ...n, pinned: !n.pinned } : n))
                );
              }}
            />
          </div>
        )}

        {/* Tab 5: Calendar & Reminder Alarms */}
        {activeTab === 'calendar' && (
          <div className="flex flex-col gap-4">
            <CalendarManager
              appointments={calendar}
              onAddAppointment={(a) => {
                const newApp: CalendarAppointment = {
                  id: `c-${Date.now()}`,
                  ...a,
                };
                setCalendar((prev) => [newApp, ...prev]);
              }}
              onDeleteAppointment={(id) => {
                setCalendar((prev) => prev.filter((c) => c.id !== id));
              }}
            />
          </div>
        )}

        {/* Tab 6: Behavioral Insights & Adaptive Learning */}
        {activeTab === 'insights' && (
          <div className="flex flex-col gap-4">
            <BehavioralInsights
              habits={habits}
              insights={insights}
              onRefreshInsights={refreshInsights}
              isRefreshing={isRefreshingInsights}
            />
          </div>
        )}
      </main>

      {/* Footer Status Bar */}
      <footer className="w-full bg-[#050914] border-t border-cyan-500/15 py-2 px-4 text-xs font-mono text-cyan-500/70 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 text-emerald-400">
            <ShieldCheck className="w-3.5 h-3.5" /> AES-GCM-256 E2EE Korumalı
          </span>
          <span>•</span>
          <span>Optik Radar: Aktif</span>
          <span>•</span>
          <span>Yapay Zeka Motoru: {aiEngineLabel}</span>
        </div>

        <div className="flex items-center gap-3">
          <span>Stark Industries OS / Jarvis Core</span>
        </div>
      </footer>

      {/* Modals */}
      <BiometricsModal
        isOpen={biometricsOpen}
        onClose={() => setBiometricsOpen(false)}
        onAuthenticated={() => {
          setIsLocked(false);
          setBiometricsOpen(false);
        }}
        isLocked={isLocked}
      />

      <CloudSyncModal
        isOpen={cloudSyncOpen}
        onClose={() => setCloudSyncOpen(false)}
        fullAppState={{ tasks, notes, calendar, habits }}
        onRestoreState={(restored) => {
          if (restored.tasks) setTasks(restored.tasks);
          if (restored.notes) setNotes(restored.notes);
          if (restored.calendar) setCalendar(restored.calendar);
          if (restored.habits) setHabits(restored.habits);
        }}
      />

      <VoiceSettingsModal
        isOpen={voiceSettingsOpen}
        onClose={() => setVoiceSettingsOpen(false)}
        personaMode={personaMode}
        onTogglePersonaMode={updatePersonaMode}
      />
    </div>
  );
}
