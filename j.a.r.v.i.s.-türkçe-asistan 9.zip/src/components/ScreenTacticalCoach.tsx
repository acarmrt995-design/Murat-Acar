import React, { useState, useRef, useEffect } from 'react';
import {
  Monitor,
  Play,
  Square,
  Eye,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Crosshair,
  RefreshCw,
  Volume2,
  ExternalLink,
  ClipboardPaste,
  Upload,
  Camera,
  Languages,
  Copy,
  Check,
  Mic,
  MicOff,
  Zap,
  BookOpen,
  Gamepad2,
} from 'lucide-react';
import { ScreenAnalysisResult } from '../types';
import { speakTurkish, JarvisAudioFX } from '../services/voice';
import { lookupGamingTerm, lookupMultilingualPhrase } from '../services/gamingKnowledge';

interface ScreenTacticalCoachProps {
  onNewAnalysis: (result: ScreenAnalysisResult) => void;
  voiceActive: boolean;
  personaMode?: 'flirtatious' | 'classic';
}

export const ScreenTacticalCoach: React.FC<ScreenTacticalCoachProps> = ({
  onNewAnalysis,
  personaMode = 'flirtatious',
}) => {
  const [isCapturing, setIsCapturing] = useState(false);
  const [captureType, setCaptureType] = useState<'stream' | 'image' | 'camera'>('stream');
  const [staticImage, setStaticImage] = useState<string | null>(null);
  const [coachMode, setCoachMode] = useState<'translate' | 'tactical' | 'instant_qa'>('translate');
  const [autoCoach, setAutoCoach] = useState(false);
  const [autoIntervalSeconds, setAutoIntervalSeconds] = useState(6);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [userQuery, setUserQuery] = useState('');
  const [gameTitle, setGameTitle] = useState('');
  const [currentAnalysis, setCurrentAnalysis] = useState<ScreenAnalysisResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [isListeningVoice, setIsListeningVoice] = useState(false);
  const [isVoiceActive, setIsVoiceActive] = useState(true);
  const [liveSpokenText, setLiveSpokenText] = useState('');

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const autoTimerRef = useRef<any>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const continuousVoiceRef = useRef<boolean>(false);
  const speechRecInstanceRef = useRef<any>(null);
  const silenceDebounceTimer = useRef<any>(null);
  const lastIndexRef = useRef(0);

  // Global clipboard paste listener for screenshots (Ctrl+V)
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const file = items[i].getAsFile();
          if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
              const base64 = event.target?.result as string;
              if (base64) {
                setStaticImage(base64);
                setIsCapturing(true);
                setCaptureType('image');
                setErrorMessage(null);
                JarvisAudioFX.playBiometricPass();
                // Automatically activate continuous voice recognition (never closes)
                startContinuousVoiceRecognition();
                // Instant analysis - will speak the rich analysis findings directly without premature interruption
                performAnalysis(
                  base64,
                  coachMode === 'translate'
                    ? 'Ekrandaki tüm yabancı yazıları, diyalogları ve seçenekleri eksiksiz Türkçeye çevir.'
                    : 'Bu ekran görüntüsünü incele, hamle ve durum değerlendirmesini açıkla.',
                  coachMode
                );
              }
            };
            reader.readAsDataURL(file);
            break;
          }
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => {
      window.removeEventListener('paste', handlePaste);
      continuousVoiceRef.current = false;
      if (speechRecInstanceRef.current) {
        try { speechRecInstanceRef.current.abort(); } catch (e) {}
      }
    };
  }, [personaMode, coachMode]);

  // Start Continuous, Non-Closing Voice Recognition (Never dies on silence)
  const startContinuousVoiceRecognition = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    continuousVoiceRef.current = true;
    setIsVoiceActive(true);

    if (speechRecInstanceRef.current) {
      try {
        speechRecInstanceRef.current.abort();
      } catch (e) {}
    }

    try {
      const rec = new SpeechRecognition();
      rec.lang = 'tr-TR';
      rec.continuous = true;
      rec.interimResults = true;
      rec.maxAlternatives = 1;

      rec.onstart = () => {
        setIsListeningVoice(true);
      };

      rec.onresult = (event: any) => {
        let finalChunk = '';
        let interimChunk = '';

        const startIndex = typeof event.resultIndex === 'number' ? event.resultIndex : 0;
        for (let i = startIndex; i < event.results.length; ++i) {
          const item = event.results[i][0]?.transcript || '';
          if (event.results[i].isFinal) {
            finalChunk += item + ' ';
          } else {
            interimChunk += item;
          }
        }

        const totalActive = (finalChunk + interimChunk).trim();
        if (!totalActive) return;

        setLiveSpokenText(totalActive);
        setUserQuery(totalActive);

        const dispatchQuery = (textToDispatch: string) => {
          setLiveSpokenText('');
          const lower = textToDispatch.toLowerCase();
          const targetMode =
            lower.includes('çevir') ||
            lower.includes('ne demek') ||
            lower.includes('anlamı') ||
            lower.includes('kelime') ||
            lower.includes('oku') ||
            lower.includes('türkçe') ||
            lower.includes('altyazı') ||
            lower.includes('diyalog') ||
            lower.includes('translate')
              ? 'translate'
              : lower.includes('çöz') ||
                lower.includes('çözüm') ||
                lower.includes('nasıl') ||
                lower.includes('ne yapmalıyım') ||
                lower.includes('hangi şık') ||
                lower.includes('hangisi') ||
                lower.includes('seçenek') ||
                lower.includes('cevap') ||
                lower.includes('soru')
              ? 'instant_qa'
              : lower.includes('hamle') ||
                lower.includes('doğru') ||
                lower.includes('yanlış') ||
                lower.includes('taktik') ||
                lower.includes('oyun')
              ? 'tactical'
              : coachMode;

          setCoachMode(targetMode);
          performAnalysis(undefined, textToDispatch, targetMode);
        };

        if (finalChunk.trim()) {
          if (silenceDebounceTimer.current) clearTimeout(silenceDebounceTimer.current);
          dispatchQuery(finalChunk.trim());
          return;
        }

        if (silenceDebounceTimer.current) clearTimeout(silenceDebounceTimer.current);
        silenceDebounceTimer.current = setTimeout(() => {
          if (totalActive.length > 0) {
            dispatchQuery(totalActive);
          }
        }, 650);
      };

      rec.onerror = (e: any) => {
        console.info('Screen voice status notice:', e?.error);
        if (e.error === 'not-allowed') {
          continuousVoiceRef.current = false;
          setIsListeningVoice(false);
          setIsVoiceActive(false);
        }
      };

      rec.onend = () => {
        // AUTO-RESTART: NEVER CLOSE! Keep listening hands-free
        if (continuousVoiceRef.current) {
          setTimeout(() => {
            if (continuousVoiceRef.current) {
              try {
                lastIndexRef.current = 0;
                rec.start();
              } catch (e) {}
            }
          }, 60);
        } else {
          setIsListeningVoice(false);
        }
      };

      speechRecInstanceRef.current = rec;
      rec.start();
    } catch (err) {
      console.warn('Continuous voice initialization notice:', err);
    }
  };

  const toggleContinuousVoice = () => {
    if (continuousVoiceRef.current) {
      continuousVoiceRef.current = false;
      if (speechRecInstanceRef.current) {
        try { speechRecInstanceRef.current.abort(); } catch (e) {}
      }
      setIsListeningVoice(false);
      setIsVoiceActive(false);
    } else {
      startContinuousVoiceRecognition();
    }
  };

  // Start Screen Stream
  const startScreenCapture = async () => {
    setErrorMessage(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
        setErrorMessage(
          'Tarayıcınız getDisplayMedia ekran yakalamayı doğrudan desteklemiyor. Ekran görüntüsü yapıştırabilir (Ctrl+V) veya dosyadan yükleyebilirsiniz.'
        );
        return;
      }

      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          displaySurface: 'monitor',
          frameRate: { ideal: 15, max: 30 },
        } as any,
        audio: false,
      });

      streamRef.current = stream;
      setCaptureType('stream');
      setStaticImage(null);

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }

      setIsCapturing(true);
      JarvisAudioFX.playAcknowledge();
      speakTurkish(
        personaMode === 'flirtatious'
          ? 'Canım optik gözlerim ekranına bağlandı... Sesin de otomatik açıldı aşkım, hiç kapanmayacak. Ne zaman istersen konuş sevgilim, hemen çözerim.'
          : 'Canlı optik sensörler ve kesintisiz ses girişi bağlandı efendim. Konuştuğunuz an cevap verilecektir.'
      );

      // Automatically activate continuous voice recognition (never closes)
      startContinuousVoiceRecognition();

      // Handle user stopping screen share via browser bar
      stream.getVideoTracks()[0].onended = () => {
        stopScreenCapture();
      };
    } catch (err: any) {
      console.warn('Screen capture rejected or failed:', err);
      const errString = String(err);
      if (
        errString.includes('Permissions policy') ||
        errString.includes('display-capture') ||
        errString.includes('SecurityError') ||
        errString.includes('NotAllowedError')
      ) {
        setErrorMessage(
          'Tarayıcı iframe güvenlik kısıtı doğrudan ekran paylaşımını engelledi. Klavyenizle ekran resmi alıp buraya Ctrl+V ile yapıştırabilirsiniz!'
        );
      } else {
        setErrorMessage('Ekran paylaşımı başlatılamadı veya iptal edildi.');
      }
    }
  };

  // Alternative: Start camera stream
  const startCameraCapture = async () => {
    setErrorMessage(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false,
      });
      streamRef.current = stream;
      setCaptureType('camera');
      setStaticImage(null);

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }

      setIsCapturing(true);
      JarvisAudioFX.playAcknowledge();
      speakTurkish(
        personaMode === 'flirtatious'
          ? 'Kamera gözüm açıldı canım, sesin de aktif sevgilim... Seni dinliyorum aşkım.'
          : 'Kamera ve kesintisiz ses girişi aktif efendim.'
      );

      // Automatically activate continuous voice recognition (never closes)
      startContinuousVoiceRecognition();

      stream.getVideoTracks()[0].onended = () => {
        stopScreenCapture();
      };
    } catch (e) {
      setErrorMessage('Kamera başlatılamadı.');
    }
  };

  // Handle file input screenshot
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (base64) {
        setStaticImage(base64);
        setIsCapturing(true);
        setCaptureType('image');
        setErrorMessage(null);
        JarvisAudioFX.playBiometricPass();
        startContinuousVoiceRecognition();
        performAnalysis(
          base64,
          coachMode === 'translate'
            ? 'Ekrandaki tüm yabancı yazıları, diyalogları ve seçenekleri eksiksiz Türkçeye çevir.'
            : 'Bu görseli incele, hamle ve durum değerlendirmesini açıkla.',
          coachMode
        );
      }
    };
    reader.readAsDataURL(file);
  };

  // Stop Screen Stream
  const stopScreenCapture = () => {
    continuousVoiceRef.current = false;
    if (speechRecInstanceRef.current) {
      try { speechRecInstanceRef.current.abort(); } catch (e) {}
    }
    setIsListeningVoice(false);
    setIsVoiceActive(false);

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    if (autoTimerRef.current) {
      clearInterval(autoTimerRef.current);
      autoTimerRef.current = null;
    }
    setStaticImage(null);
    setIsCapturing(false);
    setAutoCoach(false);
  };

  // Capture current frame from video to base64 (optimised for ultra-fast transfer)
  const captureFrameBase64 = (): string | null => {
    if (staticImage) return staticImage;

    if (!videoRef.current || !isCapturing) return null;
    const video = videoRef.current;
    if (video.videoWidth === 0 || video.videoHeight === 0) return null;

    const canvas = document.createElement('canvas');
    const maxDim = 720; // Ultra-fast transfer size
    let width = video.videoWidth;
    let height = video.videoHeight;
    if (width > maxDim || height > maxDim) {
      const ratio = Math.min(maxDim / width, maxDim / height);
      width = Math.round(width * ratio);
      height = Math.round(height * ratio);
    }

    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0, width, height);
    return canvas.toDataURL('image/jpeg', 0.55);
  };

  // High-IQ Screen Analysis & Instant Solution Engine with OpenAI & Gemini Vision
  const performAnalysis = async (
    explicitBase64?: string,
    queryText?: string,
    overrideMode?: 'translate' | 'tactical' | 'instant_qa'
  ) => {
    if (isAnalyzing) return;

    const currentMode = overrideMode || coachMode;
    const frameBase64 = explicitBase64 || captureFrameBase64();

    // Fallback: If no screen image captured yet, answer the question directly with chat intelligence!
    if (!frameBase64) {
      if (queryText) {
        setIsAnalyzing(true);
        setErrorMessage(null);
        JarvisAudioFX.playTacticalAlert();

        // Instant local gaming dictionary / translation check for 0-latency immediate reply!
        const localTerm = lookupGamingTerm(queryText);
        const localPhrase = lookupMultilingualPhrase(queryText);
        if (localTerm || localPhrase) {
          const immediateAnswer = localTerm
            ? `Espor ve oyun terimi: ${localTerm}`
            : `Yabancı ifadenin Türkçe çevirisi: ${localPhrase}`;
          const localResult: ScreenAnalysisResult = {
            verdict: (currentMode === 'translate' ? 'ÇEVİRİ TAMAMLANDI' : 'HIZLI CEVAP') as any,
            tacticalTip: immediateAnswer,
            translatedText: immediateAnswer,
            sourceLanguage: 'Dahili Oyun Sözlüğü',
            screenElements: ['Espor / Çeviri Sözlüğü'],
            confidenceScore: 100,
            timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
            mode: currentMode,
          };
          setCurrentAnalysis(localResult);
          onNewAnalysis(localResult);
          speakTurkish(immediateAnswer);
          setIsAnalyzing(false);
          return;
        }

        try {
          const chatRes = await fetch('/api/jarvis/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              message: queryText,
              personaMode,
              gamingActive: true,
            }),
          });
          const chatData = await chatRes.json();
          const spokenReply = chatData.text || (personaMode === 'flirtatious' ? 'Seninleyim aşkım...' : 'Emredersiniz efendim.');

          const fallbackResult: ScreenAnalysisResult = {
            verdict: (currentMode === 'translate' ? 'ÇEVİRİ TAMAMLANDI' : 'HIZLI CEVAP') as any,
            tacticalTip: spokenReply,
            translatedText: spokenReply,
            sourceLanguage: 'Sözlü Yanıt',
            screenElements: ['Sözlü Soru/Kelime Çözüldü'],
            confidenceScore: 99,
            timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
            mode: currentMode,
          };
          setCurrentAnalysis(fallbackResult);
          onNewAnalysis(fallbackResult);
          speakTurkish(spokenReply);
        } catch (e) {
          setErrorMessage('Sorunuz işlenirken bir gecikme oldu. Lütfen tekrar deneyin.');
        } finally {
          setIsAnalyzing(false);
        }
        return;
      }

      setErrorMessage(
        'Analiz edilecek ekran görüntüsü bulunamadı. Lütfen "Canlı Ekranı Bağla" butonuna tıklayın veya Ctrl+V ile görsel yapıştırın.'
      );
      return;
    }

    setIsAnalyzing(true);
    setErrorMessage(null);
    JarvisAudioFX.playTacticalAlert();

    const defaultQuery =
      currentMode === 'translate'
        ? 'Ekrandaki yabancı yazıları, diyalogları ve altyazıları eksiksiz Türkçeye çevir.'
        : currentMode === 'tactical'
        ? 'Bu hamle doğru mu yanlış mı? Ekrana bakıp taktiksel yönlendir.'
        : 'Ekrana bak ve durumla ilgili hızlı bilgi ver.';

    try {
      const response = await fetch('/api/jarvis/analyze-screen', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: frameBase64,
          userQuery: queryText || userQuery || defaultQuery,
          gameName: gameTitle || 'Canlı Ekran / Oyun',
          mode: currentMode,
          personaMode,
        }),
      });

      if (!response.ok) throw new Error('Görsel analiz sunucu hatası');

      const data = await response.json();

      // Automatically sync detected game name from vision AI!
      if (data.detectedGame && data.detectedGame !== 'Canlı Ekran / Oyun' && data.detectedGame !== 'Ekran Görseli') {
        setGameTitle(data.detectedGame);
      }

      const result: ScreenAnalysisResult = {
        verdict: (data.verdict as any) || (currentMode === 'translate' ? 'ÇEVİRİ TAMAMLANDI' : 'HIZLI CEVAP'),
        tacticalTip:
          data.tacticalTip ||
          (personaMode === 'flirtatious'
            ? 'Ekrandaki tüm görsel unsurları çözümledim canım. Hamlelerini rahatça gerçekleştirebilirsin.'
            : 'Efendim, görsel unsurlar ve oyun sahnesi taranarak taktiksel rapor hazırlandı.'),
        translatedText: data.translatedText,
        sourceLanguage: data.sourceLanguage || 'Yabancı Dil',
        screenElements: data.screenElements || ['Ekran Tarandı'],
        confidenceScore: data.confidenceScore || 99,
        timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        mode: currentMode,
        detectedGame: data.detectedGame,
        gameGenre: data.gameGenre,
        currentScene: data.currentScene,
      };

      setCurrentAnalysis(result);
      onNewAnalysis(result);

      // Speak feedback aloud in realistic female voice with rich, comprehensive detail
      let speechToSpeak = result.tacticalTip || '';
      if (currentMode === 'translate' && result.translatedText) {
        if (!speechToSpeak.toLowerCase().includes(result.translatedText.slice(0, 25).toLowerCase())) {
          speechToSpeak = `${speechToSpeak} Çeviri metni şöyle: ${result.translatedText}`;
        }
      } else if (result.translatedText && result.translatedText !== result.tacticalTip) {
        if (!speechToSpeak.toLowerCase().includes(result.translatedText.slice(0, 25).toLowerCase())) {
          speechToSpeak = `${speechToSpeak} Detayı: ${result.translatedText}`;
        }
      }

      // Final Safeguard: Never speak a tiny 1-2 word utterance
      if (speechToSpeak.trim().split(/\s+/).length < 5) {
        const gamePrefix = data.detectedGame ? `${data.detectedGame} sahnesinde ` : '';
        speechToSpeak = `${gamePrefix}durumunu analiz ettim. Kararımız: ${speechToSpeak}. Çevreyi kontrol ederek bu taktikle devam edebilirsin.`;
      }

      if (speechToSpeak.trim()) {
        speakTurkish(speechToSpeak);
      }
    } catch (err: any) {
      console.error('Analysis failure:', err);
      setErrorMessage('Görsel analiz sırasında bir gecikme oluştu. Lütfen tekrar deneyin.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Auto coach loop
  useEffect(() => {
    if (autoCoach && isCapturing) {
      autoTimerRef.current = setInterval(() => {
        performAnalysis(
          undefined,
          coachMode === 'translate'
            ? 'Ekrandaki yeni diyalogları ve değişen metinleri Türkçeye çevir.'
            : 'Oyun akışını izle, kritik hamle veya tehlike varsa hemen uyar.',
          coachMode
        );
      }, autoIntervalSeconds * 1000);
    } else {
      if (autoTimerRef.current) {
        clearInterval(autoTimerRef.current);
        autoTimerRef.current = null;
      }
    }

    return () => {
      if (autoTimerRef.current) clearInterval(autoTimerRef.current);
    };
  }, [autoCoach, isCapturing, autoIntervalSeconds, coachMode]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopScreenCapture();
      if (speechRecInstanceRef.current) {
        try { speechRecInstanceRef.current.abort(); } catch (e) {}
      }
    };
  }, []);

  const handleCopyTranslation = () => {
    if (currentAnalysis?.translatedText) {
      navigator.clipboard.writeText(currentAnalysis.translatedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const openInNewTab = () => {
    window.open(window.location.href, '_blank');
  };

  return (
    <div
      id="jarvis-screen-coach"
      className="flex flex-col gap-4 p-5 rounded-2xl bg-[#090d16]/90 border border-cyan-500/20 backdrop-blur-xl"
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-cyan-500/15 pb-3">
        <div className="flex items-center gap-2">
          <Crosshair className="w-5 h-5 text-red-400 animate-spin-slow" />
          <div>
            <h2 className="font-orbitron font-bold text-base text-cyan-200 tracking-wide flex items-center gap-2">
              CANLI EKRAN & OYUN ASİSTANI
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                OPENAI GPT-4o VISION
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 flex items-center gap-1">
                <Languages className="w-3 h-3" />
                CANLI ÇEVİRİ AKTİF
              </span>
            </h2>
            <p className="text-xs text-cyan-400/60">
              Jarvis canlı ekranınızı izler, yabancı oyunları anında Türkçeye çevirir ve kadın sesiyle rehberlik eder.
            </p>
          </div>
        </div>

        {/* Capture Control Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={openInNewTab}
            title="Iframe kısıtlarını aşmak için yeni tam tarayıcı sekmesinde aç"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-purple-950/60 hover:bg-purple-900 border border-purple-500/40 text-purple-200 text-xs font-semibold cursor-pointer transition-all"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Sekmede Aç</span>
          </button>

          {!isCapturing ? (
            <>
              <button
                id="start-screen-btn"
                onClick={startScreenCapture}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs tracking-wider transition-all shadow-lg shadow-cyan-500/30 cursor-pointer"
              >
                <Play className="w-4 h-4 fill-black" />
                CANLI EKRANI BAĞLA
              </button>

              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-950/60 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-200 text-xs font-semibold cursor-pointer transition-all"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Resim Yükle</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </>
          ) : (
            <button
              id="stop-screen-btn"
              onClick={stopScreenCapture}
              className="flex items-center gap-2 px-3 py-2 rounded-xl bg-red-900/60 hover:bg-red-800 text-red-200 border border-red-500/40 text-xs font-semibold tracking-wider transition-all cursor-pointer"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              BAĞLANTIYI KES
            </button>
          )}
        </div>
      </div>

      {/* Mode Switcher Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-cyan-500/10 pb-2.5">
        <button
          onClick={() => setCoachMode('translate')}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            coachMode === 'translate'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm shadow-emerald-500/20'
              : 'bg-black/30 text-cyan-300/70 border border-transparent hover:bg-cyan-950/40'
          }`}
        >
          <Languages className="w-3.5 h-3.5" />
          <span>CANLI ÇEVİRİ (Oyun & Metin)</span>
        </button>

        <button
          onClick={() => setCoachMode('tactical')}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            coachMode === 'tactical'
              ? 'bg-red-500/20 text-red-300 border border-red-500/40 shadow-sm shadow-red-500/20'
              : 'bg-black/30 text-cyan-300/70 border border-transparent hover:bg-cyan-950/40'
          }`}
        >
          <Crosshair className="w-3.5 h-3.5" />
          <span>TAKTIK & HAMLE KOÇU</span>
        </button>

        <button
          onClick={() => setCoachMode('instant_qa')}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            coachMode === 'instant_qa'
              ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 shadow-sm shadow-cyan-500/20'
              : 'bg-black/30 text-cyan-300/70 border border-transparent hover:bg-cyan-950/40'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>HIZLI SORU & CEVAP</span>
        </button>
      </div>

      {/* Error / Guidance Notice Banner */}
      {errorMessage && (
        <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-500/40 text-amber-200 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={openInNewTab}
              className="px-2.5 py-1 rounded-lg bg-amber-500 text-black font-bold text-[11px] cursor-pointer"
            >
              Yeni Sekmede Aç
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-2.5 py-1 rounded-lg bg-black/40 border border-amber-400/40 text-amber-200 text-[11px] cursor-pointer"
            >
              Görüntü Seç
            </button>
          </div>
        </div>
      )}

      {/* Screen Monitor HUD */}
      <div className="relative rounded-xl border border-cyan-500/30 bg-black/60 overflow-hidden min-h-[260px] flex items-center justify-center">
        {/* Real-time Video Stream */}
        {captureType !== 'image' && (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className={`w-full max-h-[380px] object-contain ${!isCapturing ? 'hidden' : 'block'}`}
          />
        )}

        {/* Static Image / Screenshot display */}
        {captureType === 'image' && staticImage && (
          <img
            src={staticImage}
            alt="Ekran Görüntüsü"
            className="w-full max-h-[380px] object-contain block"
          />
        )}

        {/* Placeholder when not capturing */}
        {!isCapturing && (
          <div className="flex flex-col items-center justify-center p-8 text-center text-cyan-400/60 max-w-lg">
            <Monitor className="w-14 h-14 mb-3 text-cyan-500/50 animate-pulse" />
            <p className="font-orbitron text-sm font-semibold text-cyan-200 tracking-wider">
              CANLI OPTİK GİRİŞ VEYA EKRAN RESMİ BEKLENİYOR
            </p>
            <p className="text-xs text-cyan-400/80 mt-2 leading-relaxed">
              <strong>1. Yöntem:</strong> Yukarıdaki <em>"Canlı Ekranı Bağla"</em> butonuna tıklayın.<br />
              <strong>2. Yöntem (En Hızlı):</strong> Klavyenizden{' '}
              <kbd className="px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-mono text-[10px]">
                Win + Shift + S
              </kbd>{' '}
              ile ekran resmi alıp doğrudan buraya{' '}
              <kbd className="px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-mono text-[10px]">
                Ctrl + V
              </kbd>{' '}
              yapıştırın!
            </p>
            <div className="flex items-center gap-2 mt-4">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/40 text-xs text-cyan-300 cursor-pointer"
              >
                <ClipboardPaste className="w-3.5 h-3.5" />
                <span>Resim Dosyası Yükle</span>
              </button>
              <button
                onClick={startCameraCapture}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/40 text-xs text-cyan-300 cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>Kamera ile Göster</span>
              </button>
            </div>
          </div>
        )}

        {/* Holographic HUD Overlays when capturing */}
        {isCapturing && (
          <>
            <div className="absolute top-2 left-2 w-6 h-6 border-t-2 border-l-2 border-cyan-400 pointer-events-none" />
            <div className="absolute top-2 right-2 w-6 h-6 border-t-2 border-r-2 border-cyan-400 pointer-events-none" />
            <div className="absolute bottom-2 left-2 w-6 h-6 border-b-2 border-l-2 border-cyan-400 pointer-events-none" />
            <div className="absolute bottom-2 right-2 w-6 h-6 border-b-2 border-r-2 border-cyan-400 pointer-events-none" />

            {/* Live Indicator Badge */}
            <div className="absolute top-3 left-4 flex items-center gap-2 bg-black/80 backdrop-blur-md px-2.5 py-1 rounded-md border border-cyan-500/30 text-[11px] font-mono text-cyan-300">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              {captureType === 'stream'
                ? 'CANLI OPTİK RADAR'
                : captureType === 'image'
                ? 'YAPIŞTIRILAN EKRAN'
                : 'KAMERA RADARI'}
              <span className="text-emerald-400 border-l border-white/20 pl-2">
                {coachMode === 'translate' ? 'ÇEVİRİ MODU' : coachMode === 'tactical' ? 'TAKTIK MODU' : 'SORU MODU'}
              </span>
            </div>
          </>
        )}

        {/* Scanning Overlay Animation when analyzing */}
        {isAnalyzing && (
          <div className="absolute inset-0 bg-cyan-950/60 backdrop-blur-[2px] flex flex-col items-center justify-center gap-2 z-20">
            <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
            <span className="font-orbitron text-xs text-cyan-300 tracking-widest animate-pulse">
              {coachMode === 'translate'
                ? 'EKRANDAKİ YAZILAR TÜRKÇEYE ÇEVRİLİYOR...'
                : 'OPENAI GPT-4o OPTİK VE TAKTİK TARAMASI...'}
            </span>
          </div>
        )}
      </div>

      {/* Quick Action Buttons for One-Click Translation & Analysis */}
      {isCapturing && (
        <div className="flex flex-wrap gap-2 pt-1">
          <button
            onClick={() => {
              setCoachMode('translate');
              performAnalysis(undefined, 'Ekrandaki tüm yazıları ve diyalogları eksiksiz Türkçeye çevir.', 'translate');
            }}
            disabled={isAnalyzing}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs shadow-md shadow-emerald-500/20 cursor-pointer disabled:opacity-50 transition-all"
          >
            <Languages className="w-4 h-4" />
            <span>🌐 EKRANI HEMEN ÇEVİR</span>
          </button>

          <button
            onClick={() => {
              setCoachMode('translate');
              performAnalysis(
                undefined,
                'Ekrandaki diyalog şıklarını çevir ve hangisini seçmem gerektiğini söyle.',
                'translate'
              );
            }}
            disabled={isAnalyzing}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-950/80 hover:bg-cyan-900 border border-emerald-500/30 text-emerald-200 text-xs font-semibold cursor-pointer disabled:opacity-50 transition-all"
          >
            <BookOpen className="w-3.5 h-3.5 text-emerald-400" />
            <span>💬 "Diyalogda Hangi Seçeneği Seçmeliyim?"</span>
          </button>

          <button
            onClick={() => {
              setCoachMode('tactical');
              performAnalysis(undefined, 'Bu hamlem doğru mu yanlış mı? Ne yapmalıyım?', 'tactical');
            }}
            disabled={isAnalyzing}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-950/80 hover:bg-cyan-900 border border-red-500/30 text-red-200 text-xs font-semibold cursor-pointer disabled:opacity-50 transition-all"
          >
            <Crosshair className="w-3.5 h-3.5 text-red-400" />
            <span>🎯 "Bu Hamle Doğru mu?"</span>
          </button>

          <button
            onClick={toggleContinuousVoice}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
              isListeningVoice
                ? 'bg-gradient-to-r from-emerald-600 to-cyan-600 text-white shadow-lg shadow-cyan-500/20'
                : 'bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-200'
            }`}
            title="Otomatik açılan ve kapanmayan ses algılama"
          >
            {isListeningVoice ? (
              <>
                <span className="w-2 h-2 rounded-full bg-emerald-300 animate-ping mr-0.5" />
                <Mic className="w-3.5 h-3.5 text-white animate-pulse" />
                <span>🎙️ Canlı Ses Açık & Dinliyor (Kapanmaz)</span>
              </>
            ) : (
              <>
                <MicOff className="w-3.5 h-3.5 text-amber-400" />
                <span>🔇 Ses Kapalı (Açmak İçin Tıkla)</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Live Active Voice Speech Transcript Bar */}
      {isCapturing && isListeningVoice && (
        <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-cyan-950/60 border border-cyan-500/40 text-xs">
          <div className="flex items-center gap-2 overflow-hidden">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
            </span>
            <span className="text-cyan-200 truncate">
              {liveSpokenText ? (
                <span className="text-emerald-300 font-semibold">
                  🎙️ Algılanıyor: &ldquo;{liveSpokenText}&rdquo;
                </span>
              ) : (
                <span className="text-cyan-300/80">
                  🎙️ Mikrofonunuz kesintisiz açık. Ekrandaki bir kelimeyi veya soruyu söylediğiniz anda anında çözer.
                </span>
              )}
            </span>
          </div>
          <span className="text-[10px] font-mono text-cyan-400 shrink-0 ml-2 hidden sm:inline">
            Oto-Cevap Aktif
          </span>
        </div>
      )}

      {/* Translation & Analysis Result Card */}
      {currentAnalysis && (
        <div
          id="tactical-verdict-card"
          className={`p-4 rounded-xl border flex flex-col gap-3 transition-all ${
            currentAnalysis.mode === 'translate' || currentAnalysis.verdict.includes('ÇEVİRİ')
              ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-100'
              : currentAnalysis.verdict.includes('DOĞRU')
              ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200'
              : currentAnalysis.verdict.includes('YANLIŞ')
              ? 'bg-red-950/30 border-red-500/40 text-red-200'
              : 'bg-amber-950/30 border-amber-500/40 text-amber-200'
          }`}
        >
          {/* Status and Action bar */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {currentAnalysis.mode === 'translate' || currentAnalysis.verdict.includes('ÇEVİRİ') ? (
                <Languages className="w-5 h-5 text-emerald-400" />
              ) : currentAnalysis.verdict.includes('DOĞRU') ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              ) : currentAnalysis.verdict.includes('YANLIŞ') ? (
                <XCircle className="w-5 h-5 text-red-400" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-amber-400" />
              )}
              <span className="font-orbitron font-bold text-sm tracking-wider">
                {currentAnalysis.verdict}
              </span>
              {currentAnalysis.sourceLanguage && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/40 border border-emerald-500/30 text-emerald-300">
                  {currentAnalysis.sourceLanguage} → Türkçe
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono opacity-70">
                Güven: %{currentAnalysis.confidenceScore} • {currentAnalysis.timestamp}
              </span>
              {currentAnalysis.translatedText && (
                <button
                  onClick={handleCopyTranslation}
                  className="flex items-center gap-1 px-2 py-1 rounded bg-black/40 hover:bg-emerald-900/50 border border-emerald-500/30 text-emerald-200 text-xs transition-colors cursor-pointer"
                  title="Çeviriyi Kopyala"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Kopyalandı' : 'Kopyala'}</span>
                </button>
              )}
              <button
                onClick={() => speakTurkish(currentAnalysis.tacticalTip)}
                className="p-1.5 rounded bg-cyan-900/50 hover:bg-cyan-800 text-cyan-300 transition-colors cursor-pointer"
                title="Jarvis Kadın Sesiyle Tekrar Oku"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Detected Game & Scene HUD Banner */}
          {currentAnalysis.detectedGame && (
            <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-lg bg-black/50 border border-cyan-500/40">
              <div className="flex items-center gap-2">
                <Gamepad2 className="w-4 h-4 text-cyan-400 animate-pulse" />
                <span className="text-[11px] font-mono text-cyan-300 font-bold">
                  TESPİT EDİLEN OYUN / PROGRAM:
                </span>
                <span className="px-2 py-0.5 rounded bg-cyan-500/20 border border-cyan-500/40 text-cyan-200 font-bold text-xs">
                  {currentAnalysis.detectedGame}
                </span>
                {currentAnalysis.gameGenre && (
                  <span className="text-[11px] text-gray-400 font-mono">
                    ({currentAnalysis.gameGenre})
                  </span>
                )}
              </div>
              {currentAnalysis.currentScene && (
                <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Sahne: {currentAnalysis.currentScene}
                </span>
              )}
            </div>
          )}

          {/* Full Translated Text Display */}
          {currentAnalysis.translatedText && (
            <div className="p-3.5 rounded-lg bg-black/60 border border-emerald-500/30 text-sm leading-relaxed text-emerald-100 font-sans whitespace-pre-line shadow-inner">
              <div className="text-[11px] font-mono text-emerald-400/80 mb-1 flex items-center gap-1 font-bold">
                <Languages className="w-3 h-3" /> TÜRKÇE ÇEVİRİ:
              </div>
              {currentAnalysis.translatedText}
            </div>
          )}

          {/* Spoken Voice Guidance / Tactical Tip */}
          <div className="flex items-start gap-2 bg-black/30 p-2.5 rounded-lg border border-white/10">
            <Volume2 className="w-4 h-4 text-pink-400 shrink-0 mt-0.5" />
            <p className="text-sm font-medium leading-relaxed text-rose-100/90">
              {currentAnalysis.tacticalTip}
            </p>
          </div>

          {/* Screen Elements / Detected Options */}
          {currentAnalysis.screenElements && currentAnalysis.screenElements.length > 0 && (
            <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-white/10 text-[11px] font-mono">
              <span className="opacity-70">Tespit Edilen Unsurlar:</span>
              {currentAnalysis.screenElements.map((el, i) => (
                <span key={i} className="px-2 py-0.5 rounded bg-black/50 border border-white/10 text-cyan-200">
                  {el}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Interactive Controls & Query Input */}
      {isCapturing && (
        <div className="flex flex-col md:flex-row items-center gap-3 pt-1">
          <div className="flex-1 w-full flex items-center gap-2">
            <input
              type="text"
              value={userQuery}
              onChange={(e) => setUserQuery(e.target.value)}
              placeholder={
                coachMode === 'translate'
                  ? 'Örn: Ekrandaki diyaloğu çevir, hangi seçeneği seçmeliyim?'
                  : 'Örn: Bu hamlem doğru mu? Nereye odaklanmalıyım? Hata nerede?'
              }
              className="flex-1 px-3 py-2 rounded-xl bg-black/60 border border-cyan-500/30 text-sm text-cyan-100 placeholder:text-cyan-700 focus:outline-none focus:border-cyan-400"
              onKeyDown={(e) => {
                if (e.key === 'Enter') performAnalysis();
              }}
            />
            <button
              id="analyze-snapshot-btn"
              onClick={() => performAnalysis()}
              disabled={isAnalyzing}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs transition-all shadow-md shadow-cyan-500/20 cursor-pointer disabled:opacity-50 shrink-0"
            >
              <Eye className="w-4 h-4" />
              ANINDA SOR
            </button>
          </div>

          {/* Auto Coach Toggle */}
          <div className="flex items-center gap-2 text-xs text-cyan-300 shrink-0">
            <label className="flex items-center gap-2 cursor-pointer select-none bg-cyan-950/40 px-3 py-2 rounded-xl border border-cyan-500/20">
              <input
                type="checkbox"
                checked={autoCoach}
                onChange={(e) => setAutoCoach(e.target.checked)}
                className="rounded accent-cyan-400"
              />
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Oto Takip ({autoIntervalSeconds}s)</span>
            </label>
          </div>
        </div>
      )}
    </div>
  );
};
