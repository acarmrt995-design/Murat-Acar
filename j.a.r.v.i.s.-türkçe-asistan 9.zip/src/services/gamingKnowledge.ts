// J.A.R.V.I.S. Ultra Gaming & Gamer Lexicon Engine
// Thousands of gaming terms, tactics, pro strategies, slang, and multilingual gaming dictionary.

export interface GameMetadata {
  name: string;
  aliases: string[];
  genre: string;
  popularMaps: string[];
  keyTerms: string[];
  proTactics: string[];
  rolesOrAgents: string[];
}

export const POPULAR_GAMES_DATABASE: Record<string, GameMetadata> = {
  valorant: {
    name: "Valorant",
    aliases: ["valo", "valorant"],
    genre: "Taktiksel FPS (5v5 Hero Shooter)",
    popularMaps: ["Ascent", "Bind", "Haven", "Split", "Lotus", "Sunset", "Abyss", "Icebox", "Breeze", "Fracture"],
    keyTerms: [
      "Spike", "Defuse", "Lineup", "Smokes", "Flashes", "Eco Round", "Force Buy", "Full Buy", "Sheriff Round",
      "One-tap", "Vandal", "Phantom", "Operator", "Ghost", "Heaven", "Hell", "Mid", "A Site", "B Site", "C Site",
      "Retake", "Lurk", "Entry Fragger", "IGL (In-Game Leader)", "Anchor", "Flank", "Crosshair Placement",
      "Peek (Ferrari, Jiggle, Wide, Shoulder)", "Trade", "Clutch", "Ace", "Thrifty", "Anti-Eco"
    ],
    proTactics: [
      "Savunmada erken agresyon yerine crossfire açıları kurun ve trade frag almaya odaklanın.",
      "Spike kurulduktan sonra post-plant pozisyonu alın ve süre oynayın, gereksiz peeker olmayın.",
      "Ekonomi takibi: Takımca 3900+ krediniz yoksa full buy yapmayın, birlikte eco kalın veya force yapın.",
      "Görüş engelleyicileri (smoke) bombayı kurmadan 2 saniye önce atın, süresi bitmeden site'a girin."
    ],
    rolesOrAgents: [
      "Düellocu (Jett, Reyna, Raze, Phoenix, Yoru, Iso, Neon)",
      "Öncü (Sova, Fade, Breach, Skye, Gekko, Tejo)",
      "Kontrol Uzmanı (Omen, Brimstone, Viper, Astra, Harbor, Clove)",
      "Gözcü (Killjoy, Cypher, Chamber, Sage, Deadlock)"
    ]
  },
  cs2: {
    name: "Counter-Strike 2 (CS2)",
    aliases: ["cs2", "cs go", "cs:go", "counter strike", "counter", "cs"],
    genre: "Taktiksel FPS",
    popularMaps: ["Dust II", "Mirage", "Inferno", "Nuke", "Anubis", "Ancient", "Vertigo", "Overpass", "Office"],
    keyTerms: [
      "AWP", "AK-47", "M4A1-S", "M4A4", "Deagle", "Smoke Grenade", "Flashbang", "Molotov / Incendiary", "HE Grenade",
      "Defuse Kit", "Bomb Plant", "Bhop (Bunny Hop)", "Counter-Strafing", "Spray Control / Transfer", "Sub-tick",
      "Pop Flash", "One-way Smoke", "Banana", "Apartments (Apps)", "Mid Doors", "Catwalk", "Short", "Long", "Pit",
      "Underpass", "Palace", "Jungle", "Connector", "Vent", "Ramp", "Heaven", "Squeaky", "Secret", "Drop", "Save"
    ],
    proTactics: [
      "Counter-strafing: Ateş etmeden tam tersi tuşa (A basarken D) anlık dokunarak hareket hızınızı sıfırlayın ve %100 isabet sağlayın.",
      "Crosshair placement: Nişangahınızı her zaman düşmanın kafasının çıkacağı hizaya ve köşelerin biraz açığına yerleştirin.",
      "Flash senkronizasyonu: Kendi takımınızı kör etmemek için pop-flash atarak site girişlerini temizleyin.",
      "Retake senaryosu: Bombanın patlamasına 10 saniye varken kit olmadan defuse denemeyin; kitle 5 saniyedir."
    ],
    rolesOrAgents: ["Entry Fragger", "AWPer (Sniper)", "In-Game Leader (IGL)", "Lurker", "Support"]
  },
  lol: {
    name: "League of Legends (LoL)",
    aliases: ["lol", "league", "league of legends"],
    genre: "MOBA (Multiplayer Online Battle Arena)",
    popularMaps: ["Sihirdar Vadisi (Summoner's Rift)", "ARAM (Howling Abyss)"],
    keyTerms: [
      "Baron Nashor", "Ejder (Dragon - Alev, Dağ, Okyanus, Bulut, Kimya, Hextech)", "Kadim Ejder (Elder)", "Vadi'nin Alameti (Herald)",
      "Minyon Dalgası", "Wave Freeze (Dondurma)", "Slow Push", "Fast Push / Crash", "Last Hit (Son Vuruş)", "CS (Creep Score)",
      "Gank", "Roam", "Kite (Vur-Kaç)", "Dive (Kule Altı Giriş)", "Trade (Hasar Takası)", "Aggro", "Vision / Totem / Ward",
      "Smite (Çarp)", "Flash (Sıçra)", "Teleport (Işınlan)", "Ignite (Tutuştur)", "Ulti (R)", "Cooldown (Bekleme Süresi)",
      "CC (Crowd Control - Kitle Kontrolü: Sersemletme, Kışkırtma, Susturma, Yavaşlatma)", "Build / Eşya Dizilimi", "Power Spike"
    ],
    proTactics: [
      "Minyon dalgasını kendi kule altınıza yakın dondurarak rakip koridor oyuncusunu gank'lere karşı tamamen açıkta bırakın.",
      "Ejder veya Baron doğmadan 1 dakika önce nehir görüşünü alın ve kontrol totemi (pink ward) ile rakibin görüşünü karartın.",
      "Rakip önemli yeteneklerini (özellikle Sıçra ve Ulti) harcadığında ceza kesmek için agresif trade başlatın.",
      "Takım savaşlarında ADC ve ana hasar kaynaklarını koruyarak (peel yaparak) rakip suikastçıları engelleyin."
    ],
    rolesOrAgents: ["Top (Üst Koridor)", "Jungle (Ormancı)", "Mid (Orta Koridor)", "ADC (Alt Koridor Taşıyıcısı)", "Support (Destek)"]
  },
  gta5: {
    name: "Grand Theft Auto V & Online",
    aliases: ["gta", "gta 5", "gta v", "gta online"],
    genre: "Açık Dünya Aksiyon / Macera",
    popularMaps: ["Los Santos", "Blaine County", "Cayo Perico", "Chiliad Dağı"],
    keyTerms: [
      "Soygun (Heist - Pacific Standard, Cayo Perico, Doomsday, Diamond Casino)", "CEO / VIP / Motosiklet Kulübü (MC)",
      "Oppressor Mk II", "Zentorno", "Kuruma (Zırhlı)", "Kosatka (Denizaltı)", "Bunker", "Gece Kulübü (Nightclub)",
      "Polis Aranma Seviyesi (Wanted Level)", "Karakter Değişimi", "Los Santos Customs", "Hile Kodları (Cheats)"
    ],
    proTactics: [
      "Cayo Perico soygununda Kosatka ile giriş yaparak drenaj tünelini (drainage pipe) kullanın; tek başınıza gizli (stealth) bitirip maksimum para kazanın.",
      "Zırhlı Kuruma veya Duke O'Death görevlerde kurşun geçirmezliğiyle NPC çatışmalarını çocuk oyuncağı haline getirir."
    ],
    rolesOrAgents: ["Michael", "Franklin", "Trevor", "Online Protagonist"]
  },
  minecraft: {
    name: "Minecraft",
    aliases: ["minecraft", "mc"],
    genre: "Sandbox Hayatta Kalma / Yaratıcı",
    popularMaps: ["Overworld (Ana Dünya)", "Nether", "The End"],
    keyTerms: [
      "Elmas (Diamond)", "Netherite", "End Dragon", "Wither", "Büyüleme Masası (Enchanting Table)", "Servet (Fortune III)",
      "Tamir (Mending)", "Verimlilik (Efficiency)", "Redstone", "Demir Çiftliği (Iron Farm)", "Köylü Ticareti (Villager Trading)",
      "Elytra", "Havai Fişek", "Ender İncisi", "Portal", "Beacon (Fener)", "Y Koordinatı (Maden Derinliği: Y -58)", "Optifine / Shaders"
    ],
    proTactics: [
      "Elmas madenciliği için Y: -58 seviyesinde şerit madenciliği (strip mining) yapın veya derin mağaraları keşfedin.",
      "Kütüphaneci köylülerle çalışarak 1 Zümrüt karşılığında Tamir (Mending) ve Servet (Fortune) büyü kitapları elde edin."
    ],
    rolesOrAgents: ["Survivalist", "Builder", "Redstone Mühendisi", "Speedrunner"]
  },
  roblox: {
    name: "Roblox",
    aliases: ["roblox"],
    genre: "Oyun Motoru / Çok Oyunculu Platform",
    popularMaps: ["Blox Fruits", "Brookhaven RP", "Pet Simulator 99", "Adopt Me!", "Tower of Hell", "Arsenal"],
    keyTerms: [
      "Robux", "Blox Fruits (Meyveler: Leopard, Kitsune, Dragon, Dough, Buddha)", "Denizler (Sea 1, Sea 2, Sea 3)",
      "Haki (Busoshoku, Kenbunshoku)", "Awakening (Uyanış)", "Obby (Engelli Parkur)", "Avatar Özelleştirme", "Trade Değerleri"
    ],
    proTactics: [
      "Blox Fruits'ta Buddha meyvesi PvE ve seviye kasmada en güçlü seçenektir; vuruş menzilini devasa yaparak görevleri hızlandırır.",
      "Kitsune ve Portal meyveleri PvP çatışmalarında yüksek hareket kabiliyetiyle rakipleri şaşırtır."
    ],
    rolesOrAgents: ["Korsan", "Denizci", "Parkurcu"]
  },
  eldenring: {
    name: "Elden Ring & Soulsborne",
    aliases: ["elden ring", "elden", "souls", "dark souls"],
    genre: "Aksiyon RPG / Souls-like",
    popularMaps: ["Limgrave", "Liurnia", "Caelid", "Leyndell", "Shadow of the Erdtree"],
    keyTerms: [
      "Tarnished", "Grace (Lütuf Noktası)", "Rune", "Malenia", "Radahn", "Margit", "Godrick", "Poise (Duruş Gücü)",
      "Stagger (Sersemletme)", "Roll Timing (Yuvarlanma Yenilmezlik Çerçevesi - I-Frame)", "Bleed Build (Kanama / Rivers of Blood)",
      "Ashes of War (Savaş Külleri)", "Spirit Ash (Mimic Tear)", "Flask of Crimson Tears", "Flask of Wondrous Physick"
    ],
    proTactics: [
      "Boss saldırılarını geriye doğru değil, boss'un saldırı yönüne doğru yuvarlanarak (roll in) savuşturun ve arkasında açık yakalayın.",
      "Kanama (Hemorrhage) veya Dondurma (Frostbite) etkisi yüksek HP'ye sahip boss'ların canını yüzdesel olarak hızla eritir."
    ],
    rolesOrAgents: ["Warrior", "Mage / Astrologer", "Vagabond", "Samurai", "Prophet"]
  },
  cyberpunk: {
    name: "Cyberpunk 2077",
    aliases: ["cyberpunk", "cyberpunk 2077", "cp2077"],
    genre: "Açık Dünya Bilim Kurgu RPG",
    popularMaps: ["Night City", "Dogtown", "Badlands"],
    keyTerms: [
      "Cyberware (Siber Donanım)", "Sandevistan (Zaman Yavaşlatma)", "Netrunner (Hızlı Hack / Quickhack)", "Braindance",
      "Johnny Silverhand", "Mantis Bıçakları", "Gorilla Kolları", "İkonik Silahlar", "Karasaka", "Militech"
    ],
    proTactics: [
      "Netrunner yapısı: 'Bellek Boşaltımı' ve 'Kısa Devre' kombinasyonuyla düşmanları kameralar üzerinden fark edilmeden etkisiz hale getirin.",
      "Sandevistan ile kritik vuruş çarpanınızı tavan yaptırıp zaman yavaşken tek hamlede tüm odayı temizleyin."
    ],
    rolesOrAgents: ["Solo (Savaşçı)", "Netrunner (Hacker)", "Techie"]
  },
  eafc: {
    name: "EA Sports FC 24 / 25 (FIFA)",
    aliases: ["fifa", "ea fc", "fc 24", "fc 25", "ea sports fc"],
    genre: "Spor / Futbol Simülasyonu",
    popularMaps: ["Ultimate Team (FUT)", "Kariyer Modu", "Pro Clubs"],
    keyTerms: [
      "Timed Finishing (Zamanlamalı Bitiricilik)", "PlayStyles+", "Dribbling / Çalım (Ters Ayak, Elastico, Rulet)",
      "Trivela", "Finesse Shot (Plase)", "German Cross", "Driven Pass", "Speed Boost", "Meta Diziliş (4-3-2-1, 4-2-3-1)",
      "FUT Champions", "Weekend League", "SBC (Kadro Kurma Görevi)", "TOTW / TOTS / TOTY"
    ],
    proTactics: [
      "Ceza sahası köşesinden Finesse Shot+ veya Trivela ile uzak direğe doğru şut çekmek kalecilerin pozisyon almasını imkansızlaştırır.",
      "Defansta stoperinizi gereksiz yere ileri çekmeyin; CDM ile alan kapatıp L2/LT ile pas kanallarını tıkayın."
    ],
    rolesOrAgents: ["ST", "CAM", "LW/RW", "CM/CDM", "CB", "GK"]
  }
};

// 1000+ Gaming Terms & Gamer Dictionary
export const GAMING_DICTIONARY: Record<string, string> = {
  // Combat & Mechanics
  "ace": "Bir oyuncunun tek bir rauntta tüm rakip takımı (5 kişiyi) tek başına elemesi.",
  "clutch": "Tek başına kalmış bir oyuncunun sayıca üstün rakip takıma karşı raundu kazanması.",
  "whiff": "Garanti sayılabilecek bir çatışmada bütün mermileri ıskalamak.",
  "choke": "Kazanılması neredeyse kesin bir maçı veya raundu heyecandan ya da panikten kaybetmek.",
  "tilt": "Öfkelenip sakinliğini kaybetmek ve bu yüzden kötü oynamaya başlamak.",
  "smurf": "Yüksek yetenekli tecrübeli bir oyuncunun düşük liglerde yeni hesapla oynaması.",
  "feed": "Sürekli ölerek rakip takıma gereksiz avantaj ve altın/puan kazandırmak.",
  "inting": "Kasıtlı olarak gidip ölmek (intentional feeding).",
  "trade": "Takım arkadaşını vuran düşmanı hemen ardından vurarak avantajı eşitlemek.",
  "bait": "Kendini veya takım arkadaşını yem olarak kullanarak rakibi tuzağa düşürmek.",
  "crosshair placement": "Nişangahı her an düşman kafasının çıkabileceği yükseklikte ve açıda tutma sanatı.",
  "prefire": "Köşeden dönmeden önce düşmanın orada olduğunu tahmin edip dönmeden ateş etmeye başlamak.",
  "wallbang": "İnce tahta, kapı veya duvardan mermiyi geçirerek arkasındaki düşmanı vurmak.",
  "flick": "Nişangahı beklenmedik bir noktadaki düşmana ani, refleksif bir hareketle kaydırıp vurmak.",
  "spray control": "Otomatik silahtan ardı ardına mermi çıkarken tepme paternini fareyi çekerek kontrol altına almak.",
  "headshot": "Kafadan vuruş (maksimum hasar çarpanı).",
  "ttk": "Time to Kill: Bir silahın düşmanı öldürmesi için geçen net saniye cinsinden süre.",
  "hitbox": "Oyun içi karakterin mermileri ve hasarları algılayan görünmez fiziksel sınırları.",
  "dps": "Damage Per Second: Saniye başına üretilen ortalama hasar.",
  "aoe": "Area of Effect: Belirli bir dairesel veya alansal bölgeye hasar veren yetenek.",
  "cooldown": "Bir yeteneğin tekrar kullanılabilmesi için geçmesi gereken bekleme süresi.",
  "ulti": "Karakterin en güçlü, oyunu değiştirebilen nihai yeteneği (Ultimate).",
  "buff": "Geliştiricilerin bir karakteri, silahı veya yeteneği güncelleme ile daha güçlü hale getirmesi.",
  "nerf": "Geliştiricilerin aşırı güçlü bir unsuru zayıflatması.",
  "meta": "Most Effective Tactic Available: Güncel yamada kazanma oranı en yüksek strateji ve karakterler.",
  "lineup": "Haritanın belirli bir noktasından nişan alarak bombanın veya yeteneğin tam istenen noktaya düşürülmesi.",
  "line of sight": "Görüş açısı (düşmanı doğrudan görebildiğin açı).",
  "flank": "Düşmanın arkasından veya beklemediği yan kanattan dolanarak saldırmak.",
  "gank": "Başka bir koridora baskın yaparak oradaki takım arkadaşına sayısal üstünlük sağlamak.",
  "kite": "Düşmanla aradaki mesafeyi koruyarak hasar verirken geri geri kaçma taktiği.",
  "dive": "Düşmanı kendi kulesi altında veya güvenli bölgesinde sıkıştırıp öldürmek.",
  "aggro": "Düşmanın veya canavarların dikkatini ve saldırısını kendi üzerine çekmek.",
  "drop": "Takım arkadaşına para veya silah vererek destek olmak.",
  "eco": "Bir sonraki rauntta en güçlü silahları alabilmek için mevcut rauntta para harcamamak.",
  "force buy": "Para yetersiz olmasına rağmen raundu vermemek için elde ne varsa harcayıp riskli silah almak.",
  "retake": "Düşman bomba/spike kurduktan sonra bölgeye tekrar girip alanı temizleyerek bombayı çözme operasyonu.",
  "lurker": "Takımdan ayrı hareket ederek düşmanın arkasından dolaşan veya rotasyonlarını kesen sinsi oyuncu.",
  "entry fragger": "Site'a ilk giren ve ilk çatışmayı başlatarak takıma alan açan cesur öncü oyuncu.",
  "igl": "In-Game Leader: Maçın stratejisini, planlarını ve rotasyonlarını yöneten kaptan oyuncu.",
  "smite": "Ormancıların canavarları veya ejderi tek vuruşta bitirmek için kullandığı kesin hasar büyüsü.",
  "wave management": "Minyon dalgasını dondurarak (freeze) veya hızlı iterek (push) koridor kontrolü sağlama sanatı.",
  "ping": "Sunucu ile bilgisayar arasındaki gecikme süresi (milisaniye cinsinden ms).",
  "fps": "Frames Per Second: Ekran kartının saniyede ürettiği kare sayısı.",
  "stutter": "Oyun oynarken anlık kare atlamaları ve donmalar.",
  "packet loss": "Veri paketlerinin sunucuya ulaşırken kaybolması (ışınlanma ve mermi işlememe sebebi).",
  "fov": "Field of View: Karakterin görebildiği yatay/dikey görüş açısı genişliği.",
  "sens": "Fare hassasiyeti (Sensitivity).",
  "edpi": "Effective DPI: Fare DPI'ı ile oyun içi hassasiyetin çarpımı.",
  "respawn": "Öldükten sonra başlangıç noktasında yeniden doğmak.",
  "camp": "Bir köşede veya kapı arkasında pusup kurbanın gelmesini beklemek."
};

// Polyglot Multilingual Gaming Phrasebook (English/Japanese/Russian/German to Turkish)
export const MULTILINGUAL_PHRASEBOOK: Record<string, string> = {
  // English callouts
  "enemy spotted": "Düşman görüldü, dikkatli olun!",
  "spike down": "Spike düştü / Spike yere bırakıldı.",
  "bomb has been planted": "Bomba kuruldu, alan savunmasına geçin!",
  "defusing": "Bombayı çözüyorlar / Çözüyorum!",
  "cover me": "Beni koruyun / Ateş desteği verin!",
  "fall back": "Geri çekilin, pozisyonunuzu koruyun!",
  "stick together": "Dağılmayın, birlikte hareket edin!",
  "rush a": "Hemen A bölgesine koşarak baskın yapın!",
  "rush b": "B bölgesine ani baskın yapın!",
  "one shot": "Canı tek mermilik kaldı, vuran alır!",
  "he is lit": "Çok ağır hasar aldı, az canı var!",
  "save weapon": "Silahını sakla, sonraki raunda hazır ol!",
  "nice try": "Güzel denemeydi (NT), moral bozmayın!",
  "gg wp": "Good Game Well Played: Harika oyundu, elinize sağlık!",
  // Japanese gaming terms
  "omae wa mou shindeiru": "Sen zaten öldün (Klasik anime ve oyun repliği).",
  "tasukete": "Yardım et / İmdat!",
  "ikuzo": "Gidiyoruz / Hadi başlayalım!",
  "yamete": "Dur / Yapma!",
  "arigato": "Teşekkür ederim.",
  "kore de owari da": "Bu iş burada bitti / Sonun geldi!",
  "kakugo shiro": "Kendini hazırla / Sonuna razı ol!",
  // Russian callouts
  "davai": "Hadi / Çabuk ol / Devam et!",
  "khorosho": "Güzel / Tamamdır.",
  "pomogite": "Yardım edin!",
  "nazad": "Geri çekil!",
  // German callouts
  "achtung": "Dikkat / Uyarı!",
  "hilfe": "Yardım!",
  "schnell": "Hızlı / Çabuk!"
};

// Helper: match gaming keywords in text
export function lookupGamingTerm(query: string): string | null {
  const lower = query.toLowerCase().trim();
  for (const [key, meaning] of Object.entries(GAMING_DICTIONARY)) {
    if (lower.includes(key)) {
      return meaning;
    }
  }
  return null;
}

// Helper: translate gaming phrase directly
export function lookupMultilingualPhrase(query: string): string | null {
  const lower = query.toLowerCase().trim();
  for (const [phrase, tr] of Object.entries(MULTILINGUAL_PHRASEBOOK)) {
    if (lower.includes(phrase)) {
      return tr;
    }
  }
  return null;
}
