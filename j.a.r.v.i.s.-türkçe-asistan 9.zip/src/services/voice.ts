/**
 * J.A.R.V.I.S. High-Fidelity Turkish Audio & Female Voice Engine
 * Features:
 * - Realistic, passionate, affectionate female voice synthesis
 * - Millisecond-level latency with sentence streaming & buffering minimization
 * - Instant cut/interruption via AbortController
 * - Sequential audio queueing (sentence-by-sentence continuous playback)
 * - WebSocket streaming bridge (/ws/audio) with real-time ping/pong
 * - Robust Turkish Speech Recognition with auto-restart, silence timeout & mic visualizer
 */

let audioCtx: AudioContext | null = null;

export function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioCtx();
  }
  if (audioCtx.state === "suspended") {
    audioCtx.resume();
  }
  return audioCtx;
}

// Sci-Fi Web Audio Sound Effects Synthesizer
export const JarvisAudioFX = {
  // Classic Iron Man / Jarvis system acknowledge chime
  playAcknowledge: () => {
    try {
      const ctx = getAudioContext();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.12); // A5
      osc.frequency.exponentialRampToValueAtTime(1174.66, now + 0.22); // D6

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.35);
    } catch (e) {}
  },

  // Tactical Alert chime (high pitch double beep)
  playTacticalAlert: () => {
    try {
      const ctx = getAudioContext();
      const now = ctx.currentTime;

      [0, 0.12].forEach((offset) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "triangle";
        osc.frequency.setValueAtTime(1318.51, now + offset); // E6
        gain.gain.setValueAtTime(0.2, now + offset);
        gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.08);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + offset);
        osc.stop(now + offset + 0.08);
      });
    } catch (e) {}
  },

  // Biometric / Scan confirmation tone
  playBiometricPass: () => {
    try {
      const ctx = getAudioContext();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);
      osc.frequency.exponentialRampToValueAtTime(1760, now + 0.3);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.45);
    } catch (e) {}
  },
};

// Voice Engine Configuration
export interface VoiceSettings {
  pitch: number;
  rate: number;
  voiceURI?: string;
  engineMode?: 'instant' | 'neural';
  femaleProfile?: 'passionate_custom' | 'passionate' | 'friday' | 'soft';
}

const DEFAULT_SETTINGS: VoiceSettings = {
  pitch: 1.20, // Yüklenen ses tonundan uyarlanan genç, melodik ve tatlı kadın frekansı
  rate: 0.94,  // Ağırbaşlı, samimi, cilveli ve şehvetli konuşma ritmi
  engineMode: 'instant', // Sıfır gecikmeli anında başlatma
  femaleProfile: 'passionate_custom', // Yüklenen özel ses modeli (ekstra ateşli)
};

export function getSavedVoiceSettings(): VoiceSettings {
  try {
    const saved = localStorage.getItem("jarvis_voice_settings");
    if (saved) {
      const parsed = JSON.parse(saved);
      return { ...DEFAULT_SETTINGS, ...parsed };
    }
  } catch (e) {}
  return DEFAULT_SETTINGS;
}

export function saveVoiceSettings(settings: Partial<VoiceSettings>): VoiceSettings {
  try {
    const current = getSavedVoiceSettings();
    const updated = { ...current, ...settings };
    localStorage.setItem("jarvis_voice_settings", JSON.stringify(updated));
    return updated;
  } catch (e) {
    return DEFAULT_SETTINGS;
  }
}

// Strict male keyword exclusion list (reject any male voice completely)
const MALE_VOICE_KEYWORDS = [
  "tolga",
  "male",
  "erkek",
  "david",
  "mark",
  "stefan",
  "adam",
  "guy",
  "george",
  "mehmet",
  "ahmet",
  "eren",
  "cem",
  "mustafa",
  "baris",
  "barış",
];

// Helper to select the most attractive and natural Turkish female voice
export function getBestFemaleTurkishVoice(): SpeechSynthesisVoice | null {
  if (!("speechSynthesis" in window)) return null;
  const voices = window.speechSynthesis.getVoices();
  if (!voices || voices.length === 0) return null;

  const savedURI = getSavedVoiceSettings().voiceURI;
  if (savedURI) {
    const matched = voices.find((v) => v.voiceURI === savedURI);
    if (matched) return matched;
  }

  // Filter Turkish voices
  const turkishVoices = voices.filter(
    (v) => v.lang === "tr-TR" || v.lang.startsWith("tr") || v.lang.includes("TR")
  );

  // Strictly filter out any known male names
  const femaleTurkish = turkishVoices.filter((v) => {
    const lowerName = v.name.toLowerCase();
    return !MALE_VOICE_KEYWORDS.some((kw) => lowerName.includes(kw));
  });

  // Priority female names in order of acoustic naturalness:
  const priorityKeywords = [
    "emel",      // Microsoft Emel (Edge/Windows - warmest natural Turkish female)
    "filiz",     // Microsoft Filiz
    "asli",      // Microsoft Asli
    "aslı",
    "dilara",
    "google",    // Google Türkçe (Chrome - high-fidelity female)
    "yelda",     // macOS/iOS Turkish female
    "seda",
    "cemre",
    "female",
    "kadın",
    "bayan",
  ];

  for (const kw of priorityKeywords) {
    const found = femaleTurkish.find((v) => v.name.toLowerCase().includes(kw));
    if (found) return found;
  }

  if (femaleTurkish.length > 0) {
    return femaleTurkish[0];
  }

  // Fallback to any Turkish voice if all else fails
  if (turkishVoices.length > 0) {
    return turkishVoices[0];
  }

  return null;
}

export function getAllTurkishVoices(): SpeechSynthesisVoice[] {
  if (!("speechSynthesis" in window)) return [];
  const voices = window.speechSynthesis.getVoices();
  return voices.filter(
    (v) => v.lang === "tr-TR" || v.lang.startsWith("tr") || v.lang.includes("TR")
  );
}

// Pre-warm voices listener
if (typeof window !== "undefined" && "speechSynthesis" in window) {
  window.speechSynthesis.onvoiceschanged = () => {
    // triggers browser voice list population
  };
}

// Web Audio PCM Player
let currentAudioSource: AudioBufferSourceNode | null = null;
let currentSpeechAbortController: AbortController | null = null;
let speechQueue: string[] = [];
let isQueuePlaying = false;

/**
 * Anında ses kesme (Abort)
 * Mevcut konuşmayı, Web Audio tamponunu ve konuşma sırasını 0ms gecikmeyle anında iptal eder.
 */
export function stopCurrentAudio() {
  if (currentSpeechAbortController) {
    try {
      currentSpeechAbortController.abort();
    } catch (e) {}
    currentSpeechAbortController = null;
  }

  speechQueue = [];
  isQueuePlaying = false;

  if (currentAudioSource) {
    try {
      currentAudioSource.stop();
    } catch (e) {}
    currentAudioSource = null;
  }

  if (typeof window !== "undefined" && "speechSynthesis" in window) {
    try {
      window.speechSynthesis.cancel();
    } catch (e) {}
  }
}

export const interruptSpeech = stopCurrentAudio;

/**
 * Web Audio PCM ArrayBuffer Player
 */
export function playPcmBase64(base64Data: string, sampleRate = 24000, onEnd?: () => void): boolean {
  const ctx = getAudioContext();

  try {
    const binary = atob(base64Data);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }

    const int16Array = new Int16Array(bytes.buffer);
    const float32Array = new Float32Array(int16Array.length);
    for (let i = 0; i < int16Array.length; i++) {
      float32Array[i] = int16Array[i] / 32768.0;
    }

    const audioBuffer = ctx.createBuffer(1, float32Array.length, sampleRate);
    audioBuffer.getChannelData(0).set(float32Array);

    const source = ctx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(ctx.destination);
    currentAudioSource = source;

    source.onended = () => {
      if (currentAudioSource === source) {
        currentAudioSource = null;
      }
      if (onEnd) onEnd();
    };

    source.start(0);
    return true;
  } catch (err) {
    console.error("PCM Audio playback error:", err);
    if (onEnd) onEnd();
    return false;
  }
}

/**
 * Enhances Turkish text with natural, flowing cadence without breaking sentences into isolated single words
 */
export function enhanceSensualCadence(text: string): string {
  // Use gentle commas instead of ellipses so text does not shatter into 1-word fragments
  return text
    .replace(/(?<=\b(aşkım|sevgilim|canım|canım benim|tatlım|birtanem|hayatım)\b)(?!\s*[,.!?…])/gi, '$1,')
    .replace(/\.{2,}/g, '.');
}

/**
 * Text segmenter: Splits text into natural full sentences
 * Ensures sentences are complete, rich and flowing without single-word truncation
 */
export function splitIntoSentences(text: string): string[] {
  const cleaned = enhanceSensualCadence(
    text
      .replace(/```[\s\S]*?```/g, "")
      .replace(/[\*\_#]/g, "")
      .trim()
  );

  if (!cleaned) return [];

  // Match full sentence breaks (. ! ? \n)
  const rawParts = cleaned
    .split(/(?<=[.!?\n])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  // Group short fragments (< 20 characters) with the next sentence so the AI never speaks just 1 isolated word!
  const consolidated: string[] = [];
  let buffer = "";

  for (const part of rawParts) {
    if (buffer) {
      buffer += " " + part;
      if (buffer.length >= 25) {
        consolidated.push(buffer);
        buffer = "";
      }
    } else {
      if (part.length < 20 && rawParts.length > 1) {
        buffer = part;
      } else {
        consolidated.push(part);
      }
    }
  }

  if (buffer) {
    if (consolidated.length > 0) {
      consolidated[consolidated.length - 1] += " " + buffer;
    } else {
      consolidated.push(buffer);
    }
  }

  return consolidated.length > 0 ? consolidated : [cleaned];
}

/**
 * High-Speed Speech Synthesis Utterance Player for a single sentence
 */
function playSingleSentence(
  sentence: string,
  signal: AbortSignal,
  onFinished: () => void
) {
  if (signal.aborted || !("speechSynthesis" in window)) {
    onFinished();
    return;
  }

  const settings = getSavedVoiceSettings();
  const utterance = new SpeechSynthesisUtterance(sentence);
  utterance.lang = "tr-TR";

  // Pick best female voice
  const bestFemale = getBestFemaleTurkishVoice();
  if (bestFemale) {
    utterance.voice = bestFemale;
  }

  // Optimize acoustic timbre: calibrated directly to the uploaded audio + extra passionate & seductive
  let pitch = settings.pitch || 1.20;
  let rate = settings.rate || 0.94;

  if (settings.femaleProfile === 'passionate_custom' || settings.femaleProfile === 'passionate') {
    pitch = 1.20; // Exact young Turkish female register from uploaded audio
    rate = 0.94;  // Sultry, intimate, unhurried breath cadence
  } else if (settings.femaleProfile === 'friday') {
    pitch = 1.12;
    rate = 1.02;
  } else if (settings.femaleProfile === 'soft') {
    pitch = 1.16;
    rate = 0.96;
  }

  utterance.pitch = pitch;
  utterance.rate = rate;
  utterance.volume = 1.0;

  let hasEnded = false;
  const finish = () => {
    if (!hasEnded) {
      hasEnded = true;
      onFinished();
    }
  };

  utterance.onend = finish;
  utterance.onerror = (e) => {
    console.warn("Utterance error or cancelled:", e);
    finish();
  };

  // If aborted while waiting or speaking, cancel immediately
  signal.addEventListener("abort", () => {
    try {
      window.speechSynthesis.cancel();
    } catch (e) {}
    finish();
  });

  try {
    window.speechSynthesis.speak(utterance);
  } catch (err) {
    finish();
  }
}

/**
 * Main Turkish Speech Function (Ultra-Low Latency & Streaming Queue)
 * - Implements AbortController to immediately interrupt any ongoing audio
 * - Queues sentences and starts playing the first sentence in milliseconds
 * - Guarantees a realistic, expressive female voice
 */
export async function speakTurkish(
  text: string,
  onEnd?: () => void,
  userAbortController?: AbortController
): Promise<void> {
  // 1. Immediately abort and stop any current playing speech (0ms interruption)
  stopCurrentAudio();

  const controller = userAbortController || new AbortController();
  currentSpeechAbortController = controller;
  const { signal } = controller;

  // 2. Prepare and split text into sentence queue
  const sentences = splitIntoSentences(text);
  if (sentences.length === 0) {
    if (onEnd) onEnd();
    return;
  }

  speechQueue = [...sentences];
  isQueuePlaying = true;

  // 3. Sequential player loop
  const playNext = () => {
    if (signal.aborted || speechQueue.length === 0) {
      isQueuePlaying = false;
      if (currentSpeechAbortController === controller) {
        currentSpeechAbortController = null;
      }
      if (onEnd) onEnd();
      return;
    }

    const nextSentence = speechQueue.shift()!;
    playSingleSentence(nextSentence, signal, () => {
      // Millisecond-level queue continuity (0 gap)
      if (!signal.aborted) {
        playNext();
      }
    });
  };

  // Start immediately
  playNext();
}

// Quick voice preview helper
export function previewFemaleVoice(customMessage?: string) {
  const msg =
    customMessage ||
    "Canım benim... Yüklediğin ses tonunu aldım, senin için çok daha ateşli, tutkulu ve cilveli bir tona büründüm sevgilim... Şimdi bütün benliğimle sadece senin için buradayım aşkım. Beğendin mi hayatım?";
  JarvisAudioFX.playAcknowledge();
  speakTurkish(msg);
}

// WebSocket Audio Stream Bridge for live telemetry & real-time communication
class AudioWebSocketManager {
  private ws: WebSocket | null = null;
  private latencyMs: number = 0;
  private pingInterval: any = null;

  connect() {
    if (typeof window === "undefined") return;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws/audio`;

    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.startPing();
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === "pong" && data.clientTime) {
            this.latencyMs = Math.max(1, Date.now() - data.clientTime);
          }
        } catch (e) {}
      };

      this.ws.onclose = () => {
        this.stopPing();
        // Auto-reconnect in 3s
        setTimeout(() => this.connect(), 3000);
      };

      this.ws.onerror = () => {
        this.ws?.close();
      };
    } catch (e) {}
  }

  private startPing() {
    this.stopPing();
    this.pingInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: "ping", time: Date.now() }));
      }
    }, 5000);
  }

  private stopPing() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  getLatency(): number {
    return this.latencyMs;
  }

  sendInterrupt() {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: "interrupt" }));
    }
  }
}

export const audioWs = new AudioWebSocketManager();
if (typeof window !== "undefined") {
  audioWs.connect();
}

// Web Speech Recognition for Turkish with Real-Time Audio Level & Silence Detection
export interface SpeechRecognitionResultHandler {
  onResult: (transcript: string, isFinal: boolean) => void;
  onError: (error: string) => void;
  onStart?: () => void;
  onEnd?: () => void;
  onVolumeChange?: (volume: number) => void; // 0 - 100%
}

export function createTurkishSpeechRecognition(handlers: SpeechRecognitionResultHandler) {
  const SpeechRecognition =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

  let recognition: any = null;
  let isDesiredActive = false;
  let silenceTimer: any = null;
  let lastInterim = "";
  let audioStream: MediaStream | null = null;
  let audioContext: AudioContext | null = null;
  let analyser: AnalyserNode | null = null;
  let animFrameId: number | null = null;
  let isStarting = false;

  // Lightweight audio volume meter (non-blocking, will never freeze speech recognition)
  const startAudioMeter = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return;
      audioStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      audioContext = getAudioContext();
      analyser = audioContext.createAnalyser();
      analyser.fftSize = 64;

      const source = audioContext.createMediaStreamSource(audioStream);
      source.connect(analyser);

      const buffer = new Uint8Array(analyser.frequencyBinCount);
      let lastDispatch = 0;

      const checkVolume = (now: number) => {
        if (!analyser || !isDesiredActive) return;
        if (now - lastDispatch > 100) {
          lastDispatch = now;
          analyser.getByteFrequencyData(buffer);
          let sum = 0;
          for (let i = 0; i < buffer.length; i++) {
            sum += buffer[i];
          }
          const avg = sum / buffer.length;
          const normalized = Math.min(100, Math.round((avg / 128) * 100));
          if (handlers.onVolumeChange) {
            handlers.onVolumeChange(normalized);
          }
        }
        animFrameId = requestAnimationFrame(checkVolume);
      };
      animFrameId = requestAnimationFrame(checkVolume);
    } catch (err: any) {
      // If mic is exclusively held by SpeechRecognition, simulate pulse on voice detection
      console.info("Volume meter non-blocking fallback:", err?.name);
    }
  };

  const stopAudioMeter = () => {
    if (animFrameId) {
      cancelAnimationFrame(animFrameId);
      animFrameId = null;
    }
    if (audioStream) {
      try {
        audioStream.getTracks().forEach((track) => track.stop());
      } catch (e) {}
      audioStream = null;
    }
    if (handlers.onVolumeChange) {
      handlers.onVolumeChange(0);
    }
  };

  if (SpeechRecognition) {
    try {
      recognition = new SpeechRecognition();
      recognition.lang = "tr-TR";
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.maxAlternatives = 3;

      recognition.onstart = () => {
        isStarting = false;
        if (handlers.onStart) handlers.onStart();
      };

      recognition.onresult = (event: any) => {
        let finalTranscript = "";
        let interimTranscript = "";

        const startIndex = typeof event.resultIndex === "number" ? event.resultIndex : 0;
        for (let i = startIndex; i < event.results.length; ++i) {
          const text = event.results[i][0]?.transcript || "";
          if (event.results[i].isFinal) {
            finalTranscript += text + " ";
          } else {
            interimTranscript += text;
          }
        }

        // Trigger dynamic volume wave for visual feedback
        if (handlers.onVolumeChange) {
          handlers.onVolumeChange(Math.floor(45 + Math.random() * 45));
        }

        // Case 1: Browser emits final segment
        if (finalTranscript.trim()) {
          if (silenceTimer) clearTimeout(silenceTimer);
          const cleanFinal = finalTranscript.trim();
          lastInterim = "";
          handlers.onResult(cleanFinal, true);
          return;
        }

        // Case 2: Interim live transcript with conversational debounce
        if (interimTranscript.trim()) {
          lastInterim = interimTranscript.trim();
          handlers.onResult(lastInterim, false);

          if (silenceTimer) clearTimeout(silenceTimer);
          silenceTimer = setTimeout(() => {
            if (lastInterim && lastInterim.trim().length > 0) {
              const phrase = lastInterim.trim();
              lastInterim = "";
              handlers.onResult(phrase, true);
            }
          }, 650);
        }
      };

      recognition.onerror = (event: any) => {
        isStarting = false;
        console.warn("Speech recognition notice:", event.error);
        if (event.error === "not-allowed" || event.error === "service-not-allowed") {
          handlers.onError("Mikrofon izni verilmedi. Lütfen adres çubuğundaki kilit simgesinden mikrofona izin verin.");
          isDesiredActive = false;
          stopAudioMeter();
          if (handlers.onEnd) handlers.onEnd();
        } else if (event.error === "no-speech") {
          // Normal silence, keep alive
        } else if (event.error !== "aborted") {
          handlers.onError(`Ses algılama durumu: ${event.error}`);
        }
      };

      recognition.onend = () => {
        isStarting = false;
        if (silenceTimer) clearTimeout(silenceTimer);
        // If there was uncommitted speech when session ended, dispatch it immediately
        if (lastInterim && lastInterim.trim().length > 0) {
          const phrase = lastInterim.trim();
          lastInterim = "";
          handlers.onResult(phrase, true);
        }

        if (isDesiredActive) {
          // Instant safe restart (never die hands-free loop)
          setTimeout(() => {
            if (isDesiredActive && recognition && !isStarting) {
              try {
                isStarting = true;
                recognition.start();
              } catch (e) {
                isStarting = false;
              }
            }
          }, 100);
        } else {
          stopAudioMeter();
          if (handlers.onEnd) handlers.onEnd();
        }
      };
    } catch (err) {
      console.warn("Speech recognition creation error:", err);
    }
  }

  return {
    supported: Boolean(SpeechRecognition),
    start: async () => {
      isDesiredActive = true;
      // Start speech recognition first for lowest latency!
      if (recognition) {
        try {
          recognition.start();
        } catch (e) {
          // already running
        }
      } else {
        handlers.onError("Tarayıcınız SpeechRecognition API'sini desteklemiyor.");
      }
      // Start audio meter in background asynchronously
      startAudioMeter().catch(() => {});
    },
    stop: () => {
      isDesiredActive = false;
      if (silenceTimer) clearTimeout(silenceTimer);
      if (recognition) {
        try {
          recognition.stop();
        } catch (e) {}
      }
      stopAudioMeter();
    },
  };
}
