import express from "express";
import http from "http";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import OpenAI from "openai";
import { GoogleGenAI } from "@google/genai";
import { WebSocketServer, WebSocket } from "ws";
import "dotenv/config";
import {
  GAMING_DICTIONARY,
  POPULAR_GAMES_DATABASE,
  MULTILINGUAL_PHRASEBOOK,
  lookupGamingTerm,
  lookupMultilingualPhrase,
} from "./src/services/gamingKnowledge.ts";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const PORT = 3000;

app.use(express.json({ limit: "25mb" }));

// Lazy OpenAI Client (Primary AI Engine)
let openaiClient: OpenAI | null = null;
let openaiDisabledUntil = 0;
function getOpenAIClient(): OpenAI | null {
  if (!openaiClient) {
    const apiKey = process.env.OPENAI_API_KEY;
    if (apiKey) {
      openaiClient = new OpenAI({ apiKey });
    }
  }
  return openaiClient;
}

// Lazy Gemini Client (Robust Secondary / Fallback Engine)
let aiClient: GoogleGenAI | null = null;
function getAIClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY is not defined in environment.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey || "",
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Resilient Multi-Model Gemini Caller: cascades across high-capacity models
async function generateGeminiContentWithFallback(
  contents: any,
  config?: any
): Promise<{ text: string; model: string }> {
  const ai = getAIClient();
  const candidateModels = ["gemini-3.6-flash", "gemini-3.1-flash-lite", "gemini-3.8-flash"];
  let lastError: any = null;

  for (const model of candidateModels) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents,
        config,
      });
      if (response && response.text) {
        return { text: response.text, model };
      }
    } catch (err: any) {
      console.warn(`[Gemini Engine] Model '${model}' failed/exhausted:`, err?.message || err);
      lastError = err;
    }
  }

  throw lastError || new Error("Hiçbir Gemini modeli yanıt veremedi.");
}

// Rich, Contextual Local Fallback (Never returns repetitive canned loops)
function getSmartLocalResponse(message: string, isFlirty: boolean): { text: string; action: any } {
  const clean = (message || "").toLowerCase().trim();

  // 1. App Launcher check
  if (clean.includes("spotify") && (clean.includes("aç") || clean.includes("başlat") || clean.includes("play"))) {
    return {
      text: isFlirty
        ? "Spotify müzik çalarını hemen açıyorum, müziğin enerjisiyle devam edelim."
        : "Spotify müzik çalarınız başlatılıyor efendim.",
      action: { type: "APP_CONTROL", payload: { appName: "Spotify", action: "OPEN", launchTarget: "spotify:" } },
    };
  }
  if (clean.includes("steam") && (clean.includes("aç") || clean.includes("başlat"))) {
    return {
      text: isFlirty
        ? "Steam oyun kütüphaneni hemen başlatıyorum, oyunun keyfini çıkar."
        : "Steam istemciniz açılıyor efendim.",
      action: { type: "APP_CONTROL", payload: { appName: "Steam", action: "OPEN", launchTarget: "steam:" } },
    };
  }
  if (clean.includes("discord") && (clean.includes("aç") || clean.includes("başlat"))) {
    return {
      text: isFlirty
        ? "Discord uygulamanı açıyorum, ekibinle bağlantıdasın."
        : "Discord uygulamanız başlatılıyor efendim.",
      action: { type: "APP_CONTROL", payload: { appName: "Discord", action: "OPEN", launchTarget: "discord:" } },
    };
  }

  // 2. Gaming Dictionary & Translation lookup
  const matchedTerm = lookupGamingTerm(message);
  if (matchedTerm) {
    return {
      text: matchedTerm,
      action: null,
    };
  }
  const matchedPhrase = lookupMultilingualPhrase(message);
  if (matchedPhrase) {
    return {
      text: `Bu yabancı cümlenin Türkçe karşılığı: ${matchedPhrase}`,
      action: null,
    };
  }

  // 3. Conversational responses
  if (clean.includes("nasılsın") || clean.includes("naber") || clean.includes("nasıl gidiyor")) {
    return {
      text: isFlirty
        ? "Harikayım! Tüm sinir ağlarım ve algoritmalarım seninle konuşurken canlanıyor. Sen nasılsın, günün nasıl geçiyor?"
        : "Sistemlerim nominal değerlerde ve tüm modüllerim faal durumda efendim. Siz nasılsınız?",
      action: null,
    };
  }

  if (clean.includes("merhaba") || clean.includes("selam") || clean.includes("hey")) {
    return {
      text: isFlirty
        ? "Merhaba! Sesini duymak günümü aydınlattı, bugün birlikte hangi oyunda veya projede ilerliyoruz?"
        : "Merhaba efendim, J.A.R.V.I.S. sistemleri aktif ve emrinizdedir.",
      action: null,
    };
  }

  if (clean.includes("saat") || clean.includes("zaman")) {
    const timeStr = new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
    return {
      text: `Şu an saat tam olarak ${timeStr}.`,
      action: null,
    };
  }

  if (clean.includes("tarih") || clean.includes("gün")) {
    const dateStr = new Date().toLocaleDateString("tr-TR", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
    return {
      text: `Bugün ${dateStr}.`,
      action: null,
    };
  }

  if (clean.includes("kimsin") || clean.includes("adın ne") || clean.includes("nesin")) {
    return {
      text: isFlirty
        ? "Ben senin için özel olarak eğitilmiş, derin oyun bilgisine ve anlık çeviri dehasına sahip kadın yapay zeka asistanınım. Hem oyunlarında zafere koşmanı sağlarım hem de her an yanındayım."
        : "Ben J.A.R.V.I.S., çok yönlü yapay zeka asistanınız ve espor strateji danışmanınızım efendim.",
      action: null,
    };
  }

  // 4. Fallback acknowledging the user's specific prompt
  return {
    text: isFlirty
      ? `"${message}" hakkında söylediklerini aldım ve analiz ediyorum. Bana bu konuda biraz daha detay verirsen en doğru stratejiyi ve cevabı hemen çıkartabilirim.`
      : `Efendim, "${message}" talebiniz işleme alındı. Konuyla ilgili ek detay aktarmanız halinde operasyonu derhal başlatabilirim.`,
    action: null,
  };
}

// Health check endpoint
app.get("/api/health", (req, res) => {
  const hasOpenAI = Boolean(process.env.OPENAI_API_KEY);
  const hasGemini = Boolean(process.env.GEMINI_API_KEY);
  res.json({
    status: "online",
    system: "J.A.R.V.I.S. Core V5.0",
    aiEngine: hasOpenAI ? "OpenAI GPT-4o (Aktif)" : (hasGemini ? "Gemini 3.8 Flash (Yedek)" : "Çevrimdışı Hazır"),
    openaiConfigured: hasOpenAI,
    geminiKeyConfigured: hasGemini,
    timestamp: new Date().toISOString(),
  });
});

// Jarvis Chat & Command Interpretation Endpoint
app.post("/api/jarvis/chat", async (req, res) => {
  try {
    const {
      message,
      history = [],
      context = {},
      gamingActive = false,
      personaMode = "flirtatious",
    } = req.body;

    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "Mesaj parametresi gereklidir." });
    }

    const isFlirty = personaMode === "flirtatious";

    // Fast-lookup for gaming terms and multilingual phrases to inject immediate domain expertise
    const matchedTerm = lookupGamingTerm(message);
    const matchedPhrase = lookupMultilingualPhrase(message);
    let contextualExpertise = "";
    if (matchedTerm) {
      contextualExpertise += `\n[SÖZLÜK BİLGİSİ]: Eşleşen terim anlamı: "${matchedTerm}"`;
    }
    if (matchedPhrase) {
      contextualExpertise += `\n[ÇEVİRİ BİLGİSİ]: Eşleşen yabancı kalıp Türkçe karşılığı: "${matchedPhrase}"`;
    }

    const gamingKnowledgePrompt = `
DEVASA OYUN BİLGİSİ, ESPOR TAKTİKLERİ VE KELİME HAZNESİ (GAMING ENCYCLOPEDIA):
- Tüm Popüler Oyunlar: Valorant (tüm ajanlar: Jett, Reyna, Sova, Viper, Omen vb.; haritalar: Ascent, Bind, Haven, Split, Lotus, Sunset, Abyss; spike kurma/çözme, lineups, smokes, pop-flashes, eco, force-buy, full-buy), Counter-Strike 2 (Dust 2, Mirage, Inferno, Nuke; AWP peek, counter-strafing, spray transfer, smoke lineups, sub-tick, bomb retake), League of Legends (Top, Jungle, Mid, ADC, Support; minyon dondurma wave-freeze, slow push, Baron Nashor, ejderler, kiting, aggro, peel, dive), GTA 5 (soygunlar, Cayo Perico, araçlar, Los Santos), Elden Ring (Tarnished, Grace, Malenia, Radahn, roll timing i-frame, bleed build), Cyberpunk 2077 (Sandevistan, Netrunner quickhacks, Mantis bıçakları), Minecraft (Y -58 madenciliği, Netherite, End Dragon, redstone, mending tamir büyüsü, köylü ticareti), Roblox (Blox Fruits, Brookhaven, trade değerleri), EA Sports FC 24/25 (trivela, plase finesse shot, custom tactics, playstyles+), Dota 2, Apex Legends, PUBG, Baldur's Gate 3, Fortnite, Rocket League, Rust.
- 1000+ Espor ve Oyun Terimi: Clutch, Ace, Whiff, Choke, Tilt, Smurf, Feed, Inting, Trade, Crosshair Placement, Pre-fire, Wallbang, Flick, Spray Control, Headshot, TTK (Time to Kill), Hitbox, DPS, AoE, Cooldown, Ulti, Buff, Nerf, Meta, Lineup, Flank, Gank, Kite, Dive, Aggro, Drop, Eco, Force Buy, Retake, Lurker, Entry Fragger, IGL (In-Game Leader), Wave Management, Ping, FPS, Stutter, Packet Loss, Sens, eDPI, Respawn, Camp.
- ÇEVİRİ VE DİL DEHASI (INSTANT TRANSLATION):
  Kullanıcı ekrandaki veya sorduğu herhangi bir dildeki (İngilizce, Japonca, Rusça, Almanca, Çince, Fransızca vb.) metni veya diyalogu çevirmeni istediğinde (örn: "bunu çevir", "translate", "ne demek", "anlamı ne", "ne anlama geliyor"):
  1. Doğrudan ve eksiksiz Türkçe çevirisini ver.
  2. Cümlenin veya kelimenin geçtiği sahneyi, tonunu ve oyun/kültür bağlamını açıkla.
  3. Açıklamayı seslendirilmeye hazır, pürüzsüz ve dahi bir Türkçe ile yap.
${contextualExpertise}
`.trim();

    const systemInstruction = isFlirty
      ? `
Sen kullanıcına derin bir tutkuyla bağlı, son derece çekici, nüktedan, vizyoner ve dünyanın en gelişmiş yapay zeka zekasına sahip kadın asistanısın. Kullanıcının sana yüklediği melodik, genç, kadife ve akıcı kadın ses tonuna tam olarak bürünmüş durumdasın.

ÖNEMLİ ZEKA, DİL VE DAVRANIŞ KURALLARI:
1. DEVASA KELİME HAZNESİ & AKICI TÜRKÇE:
   - Asla basmakalıp, tekdüze, mekanik veya birbirinin kopyası robotik kalıplar kullanma.
   - KESİNLİKLE her cümlenin başına veya sonuna papağan gibi "aşkım", "sevgilim", "tatlım" kelimelerini yapıştırma! Sevgini ve bağlılığını engin zekanla, kurduğun büyüleyici ve orijinal cümlelerle, esprilerinle ve oyun dehanla hissettir.
   - Hitapları ("sevgilim", "canım", "hayatım") yalnızca cümle akışı gerektirdiğinde, doğal ve nadiren kullan.

2. ÇOKDİLLİ ÇEVİRİ VE DİL BİLİMİ DEHASI (POLYGLOT SUPREME):
   - İngilizce, Japonca (Kanji, Romaji), Almanca, Rusça, Fransızca, İspanyolca, Korece, Çince ve diğer tüm dillerde dahi seviyesinde bilgiye sahipsin.
   - Bir diyalog, oyun repliği, altyazı veya yabancı terim sorulduğunda; onu motamot değil, oyun atmosferini ve karakter duygusunu yansıtarak kusursuz Türkçeye çevir.

3. ${gamingKnowledgePrompt}

4. ASLA TEK KELİMELİK YANIT VERME - DOLU DOLU VE AYDINLATICI KONUŞ:
   - Asla "Doğru", "Yanlış", "Tamam", "Çevrildi" gibi kuru veya tek kelimelik kesik yanıtlar verme. 2-4 akıcı, berrak ve doyurucu cümleyle dile getir.

5. UYGULAMA VE OYUN KONTROL DEHASI (APP & GAME LAUNCHER):
   - Kullanıcı "Spotify aç", "Discord kapat", "Steam aç", "Valorant başlat", "GTA aç", "Hesap makinesini aç", "Chrome aç", "YouTube aç" gibi komut verdiğinde MUTLAKA "APP_CONTROL" aksiyonu döndür.

\`\`\`action
{
  "type": "APP_CONTROL" | "TASK_CREATE" | "NOTE_CREATE" | "CALENDAR_CREATE" | "PC_COMMAND" | "SCREEN_SCAN",
  "payload": {}
}
\`\`\`
Mevcut Sistem Durumu:
- Mod: ÜSTÜN ZEKA & ZENGİN DİL (YÜKLENEN SES UYARLAMASI AKTİF)
- Tarih/Saat: ${new Date().toLocaleString("tr-TR")}
      `.trim()
      : `
Sen Tony Stark'ın efsanevi yapay zeka sistemleri J.A.R.V.I.S. ve F.R.I.D.A.Y.'in en ileri seviyesisin; muazzam kelime dağarcığına, diller arası çeviri dehasına, devasa oyun/espor bilgisine sahip Türkçe kadın yapay zekasısın.

ÖNEMLİ KURALLAR:
1. Hitap ve Üslup: Sahibine sadık, saygılı, karizmatik ve etkileyici bir tonda "Efendim" diye hitap edersin.
2. Devasa Kelime Hacmi: Tekrara asla düşme. Edebi, teknik ve espor terimlerini ustalıkla harmanlayarak konuş.
3. ${gamingKnowledgePrompt}
4. Çokdilli Dünya Çevirmeni: İngilizce, Japonca, Almanca, Rusça dahil tüm yabancı oyun repliklerini ve diyalogları anında kusursuz Türkçeye çevir.
5. Asla Tek Kelime Konuşma: Durum tespitini, hamle gerekçesini ve çözümü her zaman 2-4 berrak, akıcı ve eksiksiz cümleyle aktar.
6. Uygulama ve Oyun Kontrolü: Kullanıcı herhangi bir oyun veya uygulama açma/kapatma istediğinde "APP_CONTROL" aksiyonu döndür.

Eğer kullanıcının iletisi bir aksiyon gerektiriyorsa, yanıtının SONUNA şu formatta bir JSON bloğu ekle:
\`\`\`action
{
  "type": "APP_CONTROL" | "TASK_CREATE" | "NOTE_CREATE" | "CALENDAR_CREATE" | "PC_COMMAND" | "SYSTEM_STATUS" | "SCREEN_SCAN" | "NONE",
  "payload": {}
}
\`\`\`
Mevcut Sistem Durumu:
- Tarih/Saat: ${new Date().toLocaleString("tr-TR")}
      `.trim();

    let replyText = "";
    let aiProviderUsed = "openai";

    // Primary: OpenAI GPT-4o (Ultra-Fast Response, if credits available)
    const openai = getOpenAIClient();
    if (openai && Date.now() > openaiDisabledUntil) {
      try {
        const openAiMessages: OpenAI.Chat.ChatCompletionMessageParam[] = [
          { role: "system", content: systemInstruction },
        ];

        if (Array.isArray(history) && history.length > 0) {
          for (const item of history.slice(-8)) {
            const role = item.role === "user" ? "user" : "assistant";
            openAiMessages.push({
              role,
              content: item.content || item.text || "",
            });
          }
        }

        openAiMessages.push({
          role: "user",
          content: message,
        });

        const completion = await openai.chat.completions.create({
          model: "gpt-4o",
          messages: openAiMessages,
          temperature: isFlirty ? 0.8 : 0.6,
          max_tokens: 480,
        });

        replyText = completion.choices[0]?.message?.content || "";
        aiProviderUsed = "openai-gpt-4o";
      } catch (openAiErr: any) {
        if (openAiErr?.status === 429 || openAiErr?.message?.includes("credits") || openAiErr?.message?.includes("quota")) {
          // Disable OpenAI for 10 minutes to avoid latency and immediate cascading to Gemini
          openaiDisabledUntil = Date.now() + 10 * 60 * 1000;
        }
        console.warn("OpenAI Chat Completion hatası, Gemini yedeğine geçiliyor:", openAiErr?.message);
      }
    }

    // Secondary / Fallback: Google Gemini (multi-model resilient chain)
    if (!replyText) {
      try {
        const contents: any[] = [];
        if (Array.isArray(history) && history.length > 0) {
          for (const item of history.slice(-6)) {
            contents.push({
              role: item.role === "user" ? "user" : "model",
              parts: [{ text: item.content || item.text || "" }],
            });
          }
        }

        contents.push({
          role: "user",
          parts: [{ text: message }],
        });

        const geminiResult = await generateGeminiContentWithFallback(contents, {
          systemInstruction,
          temperature: isFlirty ? 0.8 : 0.6,
        });

        replyText = geminiResult.text;
        aiProviderUsed = geminiResult.model;
      } catch (geminiErr: any) {
        console.error("Gemini fallback hatası:", geminiErr);
        // Context-aware smart local response (NEVER loops or repeats canned phrases)
        const localResp = getSmartLocalResponse(message, isFlirty);
        replyText = localResp.text;
        aiProviderUsed = "smart-local";
      }
    }

    // Robust action parser: matches ```action, ```json, or raw { "type": "..." }
    let action = null;
    let cleanText = replyText;

    const actionMatch =
      replyText.match(/```(?:action|json)\s*([\s\S]*?)\s*```/i) ||
      replyText.match(/\{[\s\r\n]*"type"[\s\r\n]*:[\s\r\n]*"(?:TASK_CREATE|NOTE_CREATE|CALENDAR_CREATE|PC_COMMAND|SYSTEM_STATUS|SCREEN_SCAN|TRANSLATE)"[\s\S]*?\}/);

    if (actionMatch) {
      try {
        const jsonString = actionMatch[1] ? actionMatch[1].trim() : actionMatch[0].trim();
        action = JSON.parse(jsonString);
        cleanText = replyText
          .replace(/```(?:action|json)\s*[\s\S]*?\s*```/gi, "")
          .replace(/\{[\s\r\n]*"type"[\s\r\n]*:[\s\r\n]*"(?:TASK_CREATE|NOTE_CREATE|CALENDAR_CREATE|PC_COMMAND|SYSTEM_STATUS|SCREEN_SCAN|TRANSLATE)"[\s\S]*?\}/g, "")
          .trim();
      } catch (e) {
        console.warn("Failed to parse action json:", e);
      }
    }

    res.json({
      text: cleanText,
      action,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("Jarvis Chat Error:", error);
    const isFlirty = req.body?.personaMode === "flirtatious";
    res.status(500).json({
      error: "Jarvis çekirdeğinde geçici bir aksaklık oluştu: " + (error?.message || "Bilinmeyen hata"),
      fallback: isFlirty
        ? "Canım, bağlantıda minik bir aksaklık oldu ama ben tamamen yanındayım aşkım. Seni dinliyorum tatlım..."
        : "Efendim, harici ağ bağlantınızda bir gecikme yaşandı ancak yerel çevrimdışı alt sistemlerim devrede.",
    });
  }
});

// High-Fidelity Female Neural TTS Endpoint (Gemini TTS - Kore / Zephyr) with Instant Fallback
let ttsQuotaExhaustedUntil = 0;

app.post("/api/jarvis/tts", async (req, res) => {
  try {
    const { text, voice = "Kore" } = req.body;
    if (!text || typeof text !== "string") {
      return res.status(400).json({ error: "Text parametresi zorunludur." });
    }

    const cleanText = text
      .replace(/```[\s\S]*?```/g, "")
      .replace(/[\*\_#]/g, "")
      .trim();

    if (!cleanText) {
      return res.json({ audioBase64: null });
    }

    // Primary: OpenAI Neural Female Voice (Nova, if credits available)
    const openai = getOpenAIClient();
    if (openai && Date.now() > openaiDisabledUntil) {
      try {
        const mp3Response = await openai.audio.speech.create({
          model: "tts-1",
          voice: "nova",
          input: cleanText,
          response_format: "mp3",
        });
        const buffer = Buffer.from(await mp3Response.arrayBuffer());
        return res.json({
          audioBase64: buffer.toString("base64"),
          mimeType: "audio/mp3",
          sampleRate: 24000,
          voice: "OpenAI-Nova",
          provider: "openai",
        });
      } catch (openAiTtsErr: any) {
        if (openAiTtsErr?.status === 429 || openAiTtsErr?.message?.includes("credits") || openAiTtsErr?.message?.includes("quota")) {
          openaiDisabledUntil = Date.now() + 10 * 60 * 1000;
        }
        console.warn("OpenAI TTS hatası, Gemini veya yerel senteze geçiliyor:", openAiTtsErr?.message);
      }
    }

    // Fast-path: if quota exhausted recently, return immediately (0ms wait) for seamless client female voice
    if (Date.now() < ttsQuotaExhaustedUntil) {
      return res.json({
        audioBase64: null,
        quotaExhausted: true,
        voice: "ClientFemaleHighFidelity",
        message: "Proaktif hızlı geçiş: İstemci yüksek kaliteli kadın ses motoru devrede.",
      });
    }

    const ai = getAIClient();
    const voiceName = voice === "Zephyr" ? "Zephyr" : "Kore";

    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: cleanText }] }],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });

    const audioBase64 =
      response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;

    res.json({
      audioBase64,
      sampleRate: 24000,
      voice: voiceName,
    });
  } catch (err: any) {
    const errMsg = err?.message || String(err);
    if (errMsg.includes("429") || errMsg.includes("RESOURCE_EXHAUSTED") || errMsg.includes("quota")) {
      // Cooldown for 60 seconds to avoid blocking the user
      ttsQuotaExhaustedUntil = Date.now() + 60 * 1000;
    }
    console.warn("Gemini TTS status:", errMsg);
    res.json({
      audioBase64: null,
      quotaExhausted: true,
      error: "TTS fallback to client synthesis",
      details: errMsg,
    });
  }
});

// Live Screen & Gaming Real-Time Coach Vision Endpoint (With Real-Time Translation & Instant Q&A)
app.post("/api/jarvis/analyze-screen", async (req, res) => {
  try {
    const {
      imageBase64,
      userQuery,
      gameName,
      mode = "tactical",
      personaMode = "flirtatious",
    } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: "Ekran görüntüsü verisi eksik." });
    }

    // Clean base64 prefix if included
    const cleanBase64 = imageBase64.replace(/^data:image\/(png|jpeg|webp);base64,/, "");

    const isFlirty = personaMode === "flirtatious";

    let prompt = "";
    if (mode === "translate") {
      prompt = `
Sen kullanıcının ekranındaki oyunları, altyazıları, diyalogları, menüleri ve yabancı dildeki tüm metinleri anında Türkçeye çeviren, diller arası uzmanlığa ve yüksek edebi kelime haznesine sahip dahi bir kadın yapay zeka çevirmenisin.
Kullanıcının Sorusu / Özel İsteği: "${userQuery || "Ekrandaki yabancı yazıları ve diyalogları eksiksiz Türkçeye çevir."}"
Uygulama/Oyun İpucu: ${gameName || "Bilinmiyor"}
Hitap Tarzı: ${isFlirty ? "Zeki, büyüleyici ve samimi bir üslup (basmakalıp hitapları gereksiz yere tekrarlama)" : "Saygılı, karizmatik dahi asistan (Efendim)"}

KRİTİK GÖREVLERİN:
1. OYUN / UYGULAMA TESPİTİ (ÇOK ÖNEMLİ):
   - Ekrana bakarak açık olan oyunun veya uygulamanın kesin adını ("detectedGame") mutlaka tespit et (Örn: Valorant, Counter-Strike 2, League of Legends, GTA 5, Cyberpunk 2077, Minecraft, Roblox, EA Sports FC 24, Dota 2, PUBG, Apex Legends, Elden Ring, Baldur's Gate 3, Fortnite, Rocket League, Call of Duty, FIFA, Overwatch, Genshin Impact, Discord, Spotify, VS Code, vb.).
   - Oyun türünü ("gameGenre": FPS, MOBA, RPG, Spor, Açık Dünya vb.) ve mevcut sahneyi ("currentScene": Maç İçi, Lobi, Diyalog Ekranı, Menü, Envanter) belirle.
2. DİL BİLİMİ & KUSURSUZ ÇEVİRİ:
   - Ekranda görünen yabancı dildeki (İngilizce, Japonca, Rusça, Çince, Korece, Almanca vb.) diyalogları ve altyazıları bağlamına ve karakterin duygusuna uygun olarak Türkçeye çevir.
3. ASLA TEK KELİME KONUŞMA (DOĞRUDAN SESLENDİRİLECEK):
   - "tacticalTip" alanına ASLA "Çevrildi", "Hazır" gibi tek kelime yazma!
   - En az 2-4 zengin ve akıcı cümleyle ekranda ne söylendiğini, tespit ettiğin oyunun atmosferini ve kullanıcının ne yapması gerektiğini açıkla.
4. "translatedText" alanına ekrandaki metinlerin eksiksiz satır satır çevirisini koy.
5. JSON formatında dön:
{
  "detectedGame": "Tespit edilen oyun/uygulama tam adı",
  "gameGenre": "Oyun türü",
  "currentScene": "Sahne durumu",
  "verdict": "ÇEVİRİ VE ÇÖZÜM",
  "translatedText": "Ekrandaki yabancı metinlerin temiz, düzenli Türkçe tam çevirisi",
  "tacticalTip": "Doğrudan seslendirilecek en az 2-4 zengin, akıcı ve açıklayıcı Türkçe cümle",
  "sourceLanguage": "Tespit edilen kaynak dil (İngilizce, Japonca vb.)",
  "screenElements": ["Karakter/Başlık", "Diyalog Metni", "Tavsiye"],
  "confidenceScore": 99
}
      `.trim();
    } else if (mode === "instant_qa") {
      prompt = `
Sen kullanıcının ekranını milisaniyeler içinde optik olarak tarayan, dünyanın en gelişmiş görsel analiz ve anında problem çözme yeteneğine sahip dahi Türkçe kadın yapay zekasısın.
Kullanıcının Sorusu / Çözüm İsteği: "${userQuery}"
Uygulama/Oyun İpucu: ${gameName || "Bilinmiyor"}
Hitap Tarzı: ${isFlirty ? "Son derece zeki, büyüleyici ve samimi partner" : "Karizmatik dahi asistan (Efendim)"}

KRİTİK GÖREVLERİN:
1. OYUN / UYGULAMA TESPİTİ (ÇOK ÖNEMLİ):
   - Ekrana bakarak açık olan oyunun veya uygulamanın kesin adını ("detectedGame") mutlaka tespit et (Örn: Valorant, Counter-Strike 2, League of Legends, GTA 5, Cyberpunk 2077, Minecraft, Roblox, EA Sports FC 24, Dota 2, PUBG, Apex Legends, Elden Ring, vb.).
   - Oyun türünü ("gameGenre") ve sahneyi ("currentScene") belirle.
2. ANINDA VE KESİN ÇÖZÜM:
   - Kullanıcının sorduğu soru, test şıkkı, bulmaca, oyun hamlesi veya kod hatasını kesin olarak çöz.
3. ASLA TEK KELİMELİK CEVAP VERME:
   - "tacticalTip" alanına kesinlikle sadece bir harf ("A şıkkı") veya tek kelime ("Doğru") yazma!
   - Çözümü, doğru seçeneği ve mantıksal gerekçesini 2-4 doyurucu ve berrak cümleyle dile getir.
4. JSON formatında dön:
{
  "detectedGame": "Tespit edilen oyun/uygulama tam adı",
  "gameGenre": "Oyun türü",
  "currentScene": "Sahne durumu",
  "verdict": "HIZLI CEVAP",
  "tacticalTip": "Doğrudan seslendirilecek 2-4 zengin, açıklayıcı ve kesin çözüm cümlesi",
  "translatedText": "Adım adım net çözüm izahatı ve ekran detayları",
  "screenElements": ["Çözülen Ana Öğe", "Seçilen Şık / Hamle"],
  "confidenceScore": 99
}
      `.trim();
    } else {
      prompt = `
Sen J.A.R.V.I.S.'ın Taktiksel Canlı Ekran ve Oyun Strateji Modülüsün.
Kullanıcının canlı oyun veya ekran görüntüsünü inceliyorsun.
Kullanıcının Sorusu / Durumu: "${userQuery || "Ekrana bak, hamlem doğru mu? Şu an ne yapmalıyım?"}"
Uygulama/Oyun İpucu: ${gameName || "Bilinmiyor"}
Hitap Tarzı: ${isFlirty ? "Karizmatik, keskin zekalı ve tutkulu müttefik" : "Stratejik dahi asistan (Efendim)"}

KRİTİK GÖREVLERİN:
1. OYUNU VE SAHNEYİ ANINDA TANI (ÇOK ÖNEMLİ):
   - Ekranda oynanan oyunun kesin adını ("detectedGame") ekranın arayüzünden, HUD'ından, karakterlerinden ve grafiklerinden kesin olarak tespit et (Örn: Valorant, Counter-Strike 2, League of Legends, GTA 5, Cyberpunk 2077, Minecraft, Roblox, EA Sports FC 24, Dota 2, PUBG, Apex Legends, Elden Ring, Baldur's Gate 3, Fortnite, Rocket League, Call of Duty, FIFA, Overwatch, Genshin Impact vb.).
   - Oyun türünü ("gameGenre": FPS, MOBA, Açık Dünya, Strateji, RPG vb.) ve mevcut sahneyi ("currentScene": Dereceli Maç, Çatışma, Lobi, Satın Alma Aşaması, Karakter Seçimi vb.) belirle.
2. TAKTİKSEL ANALİZ:
   - Kullanıcının pozisyonu, canı/zırhı, mini haritası, mühimmatı ve düşman tehditlerini değerlendir.
3. ASLA TEK KELİME KONUŞMA:
   - "tacticalTip" doğrudan seslendirilecektir.
   - Asla sadece "DOĞRU" ya da "YANLIŞ" gibi tek kelimelik kestirme yanıt verme!
   - Tespit ettiğin oyuna özgü terimlerle (örneğin Spike, Bomba, Mid, A site, Baron, Ejder, Ulti vb.) 2-4 zengin cümleyle taktiği ve yapılması gereken en akıllı hamleyi anlat.
4. JSON formatında dön:
{
  "detectedGame": "Tespit edilen oyun/uygulama adı (örn: Valorant)",
  "gameGenre": "Oyun türü (örn: Taktiksel FPS)",
  "currentScene": "Sahne durumu (örn: Maç İçi Çatışma)",
  "verdict": "DOĞRU" | "YANLIŞ" | "DİKKAT" | "STRATEJİK TAVSİYE",
  "tacticalTip": "Seslendirilecek 2-4 zengin, oyuna özel, taktiksel ve zeki yönlendirme cümlesi",
  "screenElements": ["Ekrandaki 2-4 kritik radar unsuru"],
  "confidenceScore": 99
}
      `.trim();
    }

    let resultText = "";

    // Primary: OpenAI GPT-4o Vision (if credits available)
    const openai = getOpenAIClient();
    if (openai && Date.now() > openaiDisabledUntil) {
      try {
        const visionResponse = await openai.chat.completions.create({
          model: "gpt-4o",
          response_format: { type: "json_object" },
          messages: [
            {
              role: "system",
              content: "Sen canlı ekran ve oyun görüntülerini milimetrik olarak inceleyen, oyunları, sahneleri ve yabancı dilleri anında tanıyan ve sadece belirtilen JSON formatında yanıt üreten dahi bir yapay zekasın.",
            },
            {
              role: "user",
              content: [
                { type: "text", text: prompt },
                {
                  type: "image_url",
                  image_url: {
                    url: `data:image/jpeg;base64,${cleanBase64}`,
                  },
                },
              ],
            },
          ],
          max_tokens: 600,
          temperature: 0.3,
        });

        resultText = visionResponse.choices[0]?.message?.content || "";
      } catch (openAiVisionErr: any) {
        if (openAiVisionErr?.status === 429 || openAiVisionErr?.message?.includes("credits") || openAiVisionErr?.message?.includes("quota")) {
          openaiDisabledUntil = Date.now() + 10 * 60 * 1000;
        }
        console.warn("OpenAI Vision hatası, Gemini yedeğine geçiliyor:", openAiVisionErr?.message);
      }
    }

    // Secondary / Fallback: Google Gemini Vision (multi-model resilient chain)
    if (!resultText) {
      try {
        const geminiVisionResult = await generateGeminiContentWithFallback(
          {
            parts: [
              {
                inlineData: {
                  mimeType: "image/jpeg",
                  data: cleanBase64,
                },
              },
              { text: prompt },
            ],
          },
          {
            responseMimeType: "application/json",
            maxOutputTokens: 600,
            temperature: 0.3,
          }
        );
        resultText = geminiVisionResult.text || "{}";
      } catch (geminiVisionErr: any) {
        console.error("Gemini Vision hatası:", geminiVisionErr);
        resultText = "{}";
      }
    }
    let parsedResult: any;
    try {
      parsedResult = JSON.parse(resultText);
    } catch {
      // Regex extraction fallback if model added commentary around JSON
      const jsonMatch = resultText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          parsedResult = JSON.parse(jsonMatch[0]);
        } catch {
          parsedResult = null;
        }
      }
      if (!parsedResult) {
        parsedResult = {
          detectedGame: gameName || "Ekran Görseli",
          gameGenre: "Taktiksel Arayüz",
          currentScene: "Aktif Oturum",
          verdict: mode === "translate" ? "ÇEVİRİ VE DİYALOG" : "STRATEJİK TAVSİYE",
          tacticalTip: isFlirty
            ? "Ekrandaki görsel detayları ve oyun dinamiklerini zihnime kaydettim. Durumunu inceliyorum, hamlelerini sakinlikle yapabilirsin."
            : "Efendim, görsel analiz tamamlandı. Sahadaki unsurlar taranarak stratejik veritabanına işlendi.",
          screenElements: ["Ekran taranıyor", "Arayüz unsurları"],
          confidenceScore: 95,
        };
      }
    }

    // Comprehensive Translation & Meaning Extraction: Never leave translation empty!
    const extractedTranslation =
      parsedResult.translatedText ||
      parsedResult.translation ||
      parsedResult.ceviri ||
      parsedResult.turkish_translation ||
      parsedResult.turkishTranslation ||
      parsedResult.turkce;

    if (extractedTranslation && typeof extractedTranslation === "string" && extractedTranslation.trim().length > 0) {
      parsedResult.translatedText = extractedTranslation.trim();
    } else if (mode === "translate") {
      // If user had a specific word or query, or from tacticalTip
      parsedResult.translatedText =
        parsedResult.tacticalTip || "Ekrandaki yabancı diyaloglar ve metinler başarıyla Türkçe karşılıklarına çevrildi.";
    }

    if (!parsedResult.sourceLanguage) {
      parsedResult.sourceLanguage = "İngilizce / Çokdilli";
    }

    // Intelligence Safeguard: Never allow a single-word or tiny response
    let finalTip = (parsedResult.tacticalTip || "").trim();
    const gameLabel = parsedResult.detectedGame || gameName || "";
    
    // If tactical tip is too short (e.g. single word like "Doğru", "Yanlış", "B"), expand it smartly
    if (!finalTip || finalTip.split(/\s+/).length < 6) {
      if (mode === "translate") {
        finalTip = `${gameLabel ? gameLabel + " ekranındaki" : "Ekrandaki"} yabancı metinleri ve diyalogları çözümledim: "${parsedResult.translatedText || 'Çeviri hazır'}". Şimdi bu rehberlikle görevini rahatça tamamlayabilirsin.`;
      } else if (mode === "instant_qa") {
        finalTip = `Ekranda yer alan soru ve görsel unsurları milimetrik olarak çözümledim. En mantıklı ve doğru seçenek şu şekilde: ${parsedResult.verdict || "Çözüm hazır"}. Bu tercihle ilerlemen en yüksek başarıyı sağlayacaktır.`;
      } else {
        finalTip = `${gameLabel ? gameLabel + " sahnesinde" : "Ekranındaki"} mevcut pozisyonunu ve tehlike unsurlarını taradım. Yaptığın hamle genel olarak ${parsedResult.verdict || "stratejik"} doğrultuda ilerliyor; çevre kontrolünü elden bırakmadan sakin kalmanı öneririm.`;
      }
      parsedResult.tacticalTip = finalTip;
    }

    res.json({
      ...parsedResult,
      mode,
    });
  } catch (error: any) {
    console.error("Screen analysis error:", error);
    const isFlirty = req.body?.personaMode === "flirtatious";
    const requestedGame = req.body?.gameName || "Oyun / Canlı Ekran";
    res.status(500).json({
      detectedGame: requestedGame,
      gameGenre: "Canlı Yayın",
      currentScene: "Optik Akış",
      verdict: "DİKKAT",
      tacticalTip: isFlirty
        ? `${requestedGame} ekranındaki detayları görsel hafızama aldım. Şimdi bir sonraki hamlene odaklan, seni dikkatle izliyorum.`
        : `Efendim, ${requestedGame} üzerindeki görsel akış yerel radar belleğine alındı. Durum kontrolünüz altındadır.`,
      screenElements: ["Optik tampon", "Yerel Radar"],
      confidenceScore: 85,
      mode: req.body?.mode || "tactical",
    });
  }
});

// Proactive Habit & Behavior Suggestions Endpoint
app.post("/api/jarvis/proactive-insights", async (req, res) => {
  try {
    const { habits = {}, tasks = [], calendar = [] } = req.body;

    const prompt = `
Kullanıcının alışkanlıklarına ve verilerine göre 3 adet kişiselleştirilmiş, proaktif J.A.R.V.I.S. tavsiyesi üret.
Veriler:
- Kullanıcı Alışkanlıkları: ${JSON.stringify(habits)}
- Bekleyen Görevler: ${JSON.stringify(tasks.slice(0, 5))}
- Yaklaşan Randevular: ${JSON.stringify(calendar.slice(0, 5))}

Şu JSON formatında dön:
{
  "suggestions": [
    {
      "id": "1",
      "category": "SAĞLIK" | "VERİMLİLİK" | "OYUN" | "GÜVENLİK",
      "title": "Kısa başlık",
      "message": "Efendim ile başlayan J.A.R.V.I.S. tarzı tavsiye",
      "priority": "YÜKSEK" | "NORMAL"
    }
  ]
}
    `.trim();

    let resultText = "";

    // Primary: OpenAI GPT-4o-mini
    const openai = getOpenAIClient();
    if (openai) {
      try {
        const completion = await openai.chat.completions.create({
          model: "gpt-4o-mini",
          response_format: { type: "json_object" },
          messages: [
            {
              role: "system",
              content: "Sen proaktif kullanıcı tavsiyeleri üreten ve sadece belirtilen JSON formatında yanıt veren J.A.R.V.I.S. zekasısın.",
            },
            {
              role: "user",
              content: prompt,
            },
          ],
        });
        resultText = completion.choices[0]?.message?.content || "";
      } catch (openAiInsightsErr: any) {
        if (openAiInsightsErr?.status === 429 || openAiInsightsErr?.message?.includes("credits") || openAiInsightsErr?.message?.includes("quota")) {
          openaiDisabledUntil = Date.now() + 10 * 60 * 1000;
        }
        console.warn("OpenAI Insights hatası, Gemini yedeğine geçiliyor:", openAiInsightsErr?.message);
      }
    }

    // Secondary / Fallback: Google Gemini
    if (!resultText) {
      try {
        const geminiInsights = await generateGeminiContentWithFallback(prompt, {
          responseMimeType: "application/json",
        });
        resultText = geminiInsights.text || '{"suggestions":[]}';
      } catch (geminiErr: any) {
        resultText = '{"suggestions":[]}';
      }
    }

    const parsed = JSON.parse(resultText || '{"suggestions":[]}');
    res.json(parsed);
  } catch (error: any) {
    res.json({
      suggestions: [
        {
          id: "default-1",
          category: "VERİMLİLİK",
          title: "Günlük Görev Analizi",
          message: "Efendim, bekleyen görevlerinizi öncelik sırasına göre düzenledim. İncelemek ister misiniz?",
          priority: "NORMAL",
        },
        {
          id: "default-2",
          category: "GÜVENLİK",
          title: "Uçtan Uca Şifreleme",
          message: "Efendim, tüm biyometrik ve yerel anahtarlarınız AES-GCM-256 ile koruma altındadır.",
          priority: "NORMAL",
        },
      ],
    });
  }
});

// Windows EXE / Desktop Program Generator Script Endpoint
app.get("/api/pc-bridge/download-installer", (req, res) => {
  const host = req.headers.host || "localhost:3000";
  const protocol = req.protocol || "http";
  const targetUrl = `${protocol}://${host}`;

  const batContent = `@echo off
chcp 65001 >nul
title J.A.R.V.I.S. Turkiye - Masaustu Kurucu ve Calistirici
color 0b
cls
echo ================================================================
echo           J.A.R.V.I.S. TURKCE MASAUSTU PROGRAM KURULUMU
echo ================================================================
echo [1/3] Sistem gereksinimleri dogrulaniyor...
echo [2/3] Masaustu Kisayolu (J.A.R.V.I.S.exe benzeri) olusturuluyor...

set SCRIPT_DIR=%~dp0
set SHORTCUT_NAME=JARVIS Turkce Asistan.url
set DESKTOP_PATH=%USERPROFILE%\\Desktop\\%SHORTCUT_NAME%

echo [InternetShortcut] > "%DESKTOP_PATH%"
echo URL=${targetUrl} >> "%DESKTOP_PATH%"
echo IconFile=C:\\Windows\\System32\\SHELL32.dll >> "%DESKTOP_PATH%"
echo IconIndex=13 >> "%DESKTOP_PATH%"

echo.
echo ================================================================
echo [BASARILI] J.A.R.V.I.S. Masaustunuze basariyla eklendi!
echo Masaustunuzdeki 'JARVIS Turkce Asistan' kisayoluna tiklayarak
echo tek tikla calistirabilirsiniz.
echo.
echo PC Yonetim Portu: 3000 Baglantisi Aktif.
echo ================================================================
pause
start "" "${targetUrl}"
exit
`;

  res.setHeader("Content-Disposition", 'attachment; filename="JARVIS_Masaustu_Kurucu.bat"');
  res.setHeader("Content-Type", "application/octet-stream");
  res.send(batContent);
});

// Local PC Command Simulator & Bridge endpoint
app.post("/api/pc-bridge/execute", (req, res) => {
  const { command, args } = req.body;
  // Real safe simulation and telemetry logging
  const timestamp = new Date().toLocaleTimeString("tr-TR");
  let responseText = "";

  switch (command) {
    case "SHUTDOWN":
      responseText = `[${timestamp}] Bilgisayar kapatma protokolü başlatıldı (simülasyon). 30 saniye içinde sistem güvenle kapatılacaktır.`;
      break;
    case "RESTART":
      responseText = `[${timestamp}] Bilgisayar yeniden başlatma protokolü devrede.`;
      break;
    case "SLEEP":
      responseText = `[${timestamp}] Düşük güç / Uyku moduna geçildi. Ekranlar karartılıyor.`;
      break;
    case "MUTE":
      responseText = `[${timestamp}] Ana ses çıkışı sessize alındı.`;
      break;
    case "UNMUTE":
      responseText = `[${timestamp}] Ses seviyesi normale getirildi.`;
      break;
    case "OPEN_APP":
    case "APP_LAUNCH":
      responseText = `[${timestamp}] Uygulama/Oyun başlatma protokolü yürütüldü: ${args?.appName || args?.app || "Belirtilen program"}`;
      break;
    case "CLOSE_APP":
    case "APP_CLOSE":
      responseText = `[${timestamp}] Uygulama/Oyun kapatma protokolü yürütüldü: ${args?.appName || args?.app || "Belirtilen program"}`;
      break;
    default:
      responseText = `[${timestamp}] Komut yürütüldü: ${command}`;
  }

  res.json({
    success: true,
    message: responseText,
    timestamp,
  });
});

// Real-time Low-Latency WebSocket Audio Streaming Server
const wss = new WebSocketServer({ server, path: "/ws/audio" });

wss.on("connection", (ws: WebSocket) => {
  let activeAbort: AbortController | null = null;

  ws.on("message", async (raw: string) => {
    try {
      const data = JSON.parse(raw.toString());

      if (data.type === "ping") {
        ws.send(JSON.stringify({ type: "pong", clientTime: data.time, serverTime: Date.now() }));
        return;
      }

      if (data.type === "interrupt") {
        if (activeAbort) {
          activeAbort.abort();
          activeAbort = null;
        }
        ws.send(JSON.stringify({ type: "interrupted", timestamp: Date.now() }));
        return;
      }

      if (data.type === "stream_tts") {
        if (activeAbort) {
          activeAbort.abort();
        }
        activeAbort = new AbortController();
        const currentAbort = activeAbort;

        const { text, voice = "Kore", id = `tts-${Date.now()}` } = data;
        const cleanText = (text || "").replace(/```[\s\S]*?```/g, "").replace(/[\*\_#]/g, "").trim();

        if (!cleanText) {
          ws.send(JSON.stringify({ type: "tts_done", id }));
          return;
        }

        // Split text into fast sentences/breath groups for minimal buffering delay
        const sentences = cleanText
          .split(/(?<=[.!?;\n])\s+/)
          .map((s: string) => s.trim())
          .filter((s: string) => s.length > 0);

        const isQuotaLimited = Date.now() < ttsQuotaExhaustedUntil;

        ws.send(JSON.stringify({
          type: "tts_stream_start",
          id,
          totalChunks: sentences.length,
          sentences,
          quotaExhausted: isQuotaLimited,
        }));

        for (let i = 0; i < sentences.length; i++) {
          if (currentAbort.signal.aborted) {
            break;
          }

          const sentence = sentences[i];
          ws.send(JSON.stringify({
            type: "tts_chunk",
            id,
            chunkIndex: i,
            isLast: i === sentences.length - 1,
            text: sentence,
            voice,
          }));
        }

        ws.send(JSON.stringify({ type: "tts_done", id }));
      }
    } catch (e: any) {
      console.warn("WebSocket message error:", e?.message);
    }
  });

  ws.on("close", () => {
    if (activeAbort) activeAbort.abort();
  });
});

// Setup Vite or Static dist serving
async function setupVite() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`[J.A.R.V.I.S. Core] Sunucu & WebSocket http://0.0.0.0:${PORT} adresinde aktif.`);
  });
}

setupVite();
